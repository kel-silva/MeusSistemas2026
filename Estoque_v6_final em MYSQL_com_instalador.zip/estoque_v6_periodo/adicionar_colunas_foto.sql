-- ============================================================
-- MIGRAÇÃO: Adicionar coluna 'foto' nas tabelas
-- Execute este script no seu banco de dados MySQL/MariaDB
-- para habilitar o recurso de fotos no sistema.
--
-- Como executar:
-- 1. Abra o HeidiSQL, phpMyAdmin ou MySQL Workbench
-- 2. Selecione o banco de dados do estoque
-- 3. Execute este script SQL
-- ============================================================

-- Adiciona coluna foto na tabela fornecedores (se não existir)
ALTER TABLE fornecedores 
    ADD COLUMN IF NOT EXISTS foto VARCHAR(500) DEFAULT NULL 
    COMMENT 'Caminho da foto do fornecedor';

-- Adiciona coluna foto na tabela produtos (se não existir)
ALTER TABLE produtos 
    ADD COLUMN IF NOT EXISTS foto VARCHAR(500) DEFAULT NULL 
    COMMENT 'Caminho da foto do produto';

-- Adiciona coluna foto na tabela clientes (se não existir)
ALTER TABLE clientes 
    ADD COLUMN IF NOT EXISTS foto VARCHAR(500) DEFAULT NULL 
    COMMENT 'Caminho da foto do cliente';

-- Verificação: mostra as colunas das tabelas após a migração
SHOW COLUMNS FROM fornecedores;
SHOW COLUMNS FROM produtos;
SHOW COLUMNS FROM clientes;
