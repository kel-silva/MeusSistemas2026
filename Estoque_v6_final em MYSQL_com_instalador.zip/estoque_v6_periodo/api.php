<?php
ob_start();
error_reporting(0);
ini_set('display_errors', 0);
// Configurar timezone para horário de Brasília (GMT-3)
date_default_timezone_set('America/Sao_Paulo');

session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'database.php';

// Verificar se usuário está logado
$endpoint = isset($_GET['endpoint']) ? $_GET['endpoint'] : '';
if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Usuário não autenticado', 'redirect' => 'login.php']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

try {
    $db = new Database();
    $conn = $db->getConnection();
    switch ($endpoint) {
        // ADMINISTRAÇÃO - USUÁRIOS
        case 'usuarios':
            // Verificar se é admin
            if ($_SESSION['usuario_tipo'] !== 'admin') {
                http_response_code(403);
                echo json_encode(['error' => 'Acesso negado']);
                break;
            }

            if ($method === 'GET') {
                if (isset($_GET['id'])) {
                    $stmt = $conn->prepare("SELECT u.id, u.nome, u.username, u.tipo, u.nivel_admin, u.ativo, u.data_cadastro,
                                           p.dashboard, p.produtos, p.movimentacoes, p.clientes,
                                           p.fornecedores, p.alertas, p.administracao
                                           FROM usuarios u
                                           LEFT JOIN permissoes p ON u.id = p.usuario_id
                                           WHERE u.id = ?");
                    $stmt->execute([$_GET['id']]);
                    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
                    echo json_encode($usuario);
                } else {
                    $stmt = $conn->query("SELECT u.id, u.nome, u.username, u.tipo, u.nivel_admin, u.ativo, u.data_cadastro,
                                         p.dashboard, p.produtos, p.movimentacoes, p.clientes,
                                         p.fornecedores, p.alertas, p.administracao
                                         FROM usuarios u
                                         LEFT JOIN permissoes p ON u.id = p.usuario_id
                                         ORDER BY u.nome");
                    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
                }
            } elseif ($method === 'POST') {
                $data = json_decode(file_get_contents('php://input'), true);

                // Verificar limite de usuários — vale para TODOS, incluindo super admin
                $stmtLim = $conn->query("SELECT valor FROM configuracoes WHERE chave = 'limite_usuarios'");
                $limRow  = $stmtLim->fetch();
                $limiteMax = $limRow ? (int)$limRow['valor'] : 0;
                if ($limiteMax > 0) {
                    // Conta todos exceto o super admin (id=1), que não entra no limite
                    $stmtCnt = $conn->query("SELECT COUNT(*) FROM usuarios WHERE id != 1");
                    $totalAtual = (int)$stmtCnt->fetchColumn();
                    if ($totalAtual >= $limiteMax) {
                        echo json_encode([
                            'error'   => 'limite_atingido',
                            'message' => 'Limite de ' . $limiteMax . ' usuário(s) atingido. Para cadastrar mais usuários, aumente o limite em Administração ou entre em contato com o Administrador principal.'
                        ]);
                        break;
                    }
                }

                // Verificar se username já existe
                $stmt = $conn->prepare("SELECT COUNT(*) FROM usuarios WHERE username = ?");
                $stmt->execute([$data['username']]);
                if ($stmt->fetchColumn() > 0) {
                    echo json_encode(['error' => 'Nome de usuário já existe']);
                    break;
                }

                $senhaHash = password_hash($data['senha'], PASSWORD_DEFAULT);

                $stmt = $conn->prepare("INSERT INTO usuarios (nome, username, senha, tipo, nivel_admin, ativo) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$data['nome'], $data['username'], $senhaHash, $data['tipo'], $data['nivel_admin'] ?? null, $data['ativo']]);
                $novoId = $conn->lastInsertId();

                // Criar permissões
                $stmt = $conn->prepare("INSERT INTO permissoes (usuario_id, dashboard, produtos, movimentacoes, clientes, fornecedores, alertas, administracao)
                                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $novoId,
                    $data['permissoes']['dashboard'] ?? 1,
                    $data['permissoes']['produtos'] ?? 1,
                    $data['permissoes']['movimentacoes'] ?? 1,
                    $data['permissoes']['clientes'] ?? 1,
                    $data['permissoes']['fornecedores'] ?? 1,
                    $data['permissoes']['alertas'] ?? 1,
                    $data['permissoes']['administracao'] ?? 0
                ]);

                echo json_encode(['success' => true, 'id' => $novoId]);
            } elseif ($method === 'PUT') {
                $data = json_decode(file_get_contents('php://input'), true);

                // Verificar se username já existe (exceto o próprio usuário)
                $stmt = $conn->prepare("SELECT COUNT(*) FROM usuarios WHERE username = ? AND id != ?");
                $stmt->execute([$data['username'], $data['id']]);
                if ($stmt->fetchColumn() > 0) {
                    echo json_encode(['error' => 'Nome de usuário já existe']);
                    break;
                }

                if (!empty($data['senha'])) {
                    $senhaHash = password_hash($data['senha'], PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("UPDATE usuarios SET nome=?, username=?, senha=?, tipo=?, nivel_admin=?, ativo=? WHERE id=?");
                    $stmt->execute([$data['nome'], $data['username'], $senhaHash, $data['tipo'], $data['nivel_admin'] ?? null, $data['ativo'], $data['id']]);
                } else {
                    $stmt = $conn->prepare("UPDATE usuarios SET nome=?, username=?, tipo=?, nivel_admin=?, ativo=? WHERE id=?");
                    $stmt->execute([$data['nome'], $data['username'], $data['tipo'], $data['nivel_admin'] ?? null, $data['ativo'], $data['id']]);
                }

                // Atualizar permissões
                $stmt = $conn->prepare("UPDATE permissoes SET dashboard=?, produtos=?, movimentacoes=?, clientes=?, fornecedores=?, alertas=?, administracao=? WHERE usuario_id=?");
                $stmt->execute([
                    $data['permissoes']['dashboard'],
                    $data['permissoes']['produtos'],
                    $data['permissoes']['movimentacoes'],
                    $data['permissoes']['clientes'],
                    $data['permissoes']['fornecedores'],
                    $data['permissoes']['alertas'],
                    $data['permissoes']['administracao'],
                    $data['id']
                ]);

                echo json_encode(['success' => true]);
            } elseif ($method === 'DELETE') {
                $id = $_GET['id'];
                if ($id == 1) {
                    echo json_encode(['error' => 'Não é possível excluir o administrador principal']);
                    break;
                }
                $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
                $stmt->execute([$id]);
                echo json_encode(['success' => true]);
            }
            break;

        // PRODUTOS
        case 'produtos':
            if ($method === 'GET') {
                if (isset($_GET['id'])) {
                    $stmt = $conn->prepare("SELECT p.*, c.nome as categoria_nome, f.nome as fornecedor_nome
                                           FROM produtos p
                                           LEFT JOIN categorias c ON p.categoria_id = c.id
                                           LEFT JOIN fornecedores f ON p.fornecedor_id = f.id
                                           WHERE p.id = ?");
                    $stmt->execute([$_GET['id']]);
                    $produto = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($produto) {
                        echo json_encode($produto);
                    } else {
                        http_response_code(404);
                        echo json_encode(['error' => 'Produto não encontrado']);
                    }
                } else {
                    $stmt = $conn->query("SELECT p.*, c.nome as categoria_nome, f.nome as fornecedor_nome
                                         FROM produtos p
                                         LEFT JOIN categorias c ON p.categoria_id = c.id
                                         LEFT JOIN fornecedores f ON p.fornecedor_id = f.id
                                         ORDER BY p.nome");
                    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
                }
            } elseif ($method === 'POST') {
                $data = json_decode(file_get_contents('php://input'), true);
                $colFotoProd = $conn->query("SHOW COLUMNS FROM produtos LIKE 'foto'")->fetchAll();
                $temFotoProd = count($colFotoProd) > 0;
                if ($temFotoProd) {
                    $stmt = $conn->prepare("INSERT INTO produtos (codigo_barras, nome, descricao, categoria_id, fornecedor_id, preco_custo, preco_venda, estoque_atual, estoque_minimo, foto) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$data['codigo_barras'] ?? null, $data['nome'], $data['descricao'] ?? null, $data['categoria_id'] ?? null, $data['fornecedor_id'] ?? null, $data['preco_custo'], $data['preco_venda'], $data['estoque_atual'] ?? 0, $data['estoque_minimo'] ?? 0, $data['foto'] ?? null]);
                } else {
                    $stmt = $conn->prepare("INSERT INTO produtos (codigo_barras, nome, descricao, categoria_id, fornecedor_id, preco_custo, preco_venda, estoque_atual, estoque_minimo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$data['codigo_barras'] ?? null, $data['nome'], $data['descricao'] ?? null, $data['categoria_id'] ?? null, $data['fornecedor_id'] ?? null, $data['preco_custo'], $data['preco_venda'], $data['estoque_atual'] ?? 0, $data['estoque_minimo'] ?? 0]);
                }
                $newId = $conn->lastInsertId();
                // Registrar preço inicial no histórico
                try {
                    $conn->exec("CREATE TABLE IF NOT EXISTS historico_precos (id INTEGER PRIMARY KEY AUTOINCREMENT, produto_id INTEGER NOT NULL, preco_custo REAL NOT NULL, preco_venda REAL NOT NULL, data_registro DATETIME)");
                    $dataHP0 = (new DateTime('now', new DateTimeZone('America/Sao_Paulo')))->format('Y-m-d H:i:s');
                    $stmtHist = $conn->prepare("INSERT INTO historico_precos (produto_id, preco_custo, preco_venda, data_registro) VALUES (?, ?, ?, ?)");
                    $stmtHist->execute([$newId, $data['preco_custo'], $data['preco_venda'], $dataHP0]);
                } catch (Exception $eHist0) { /* não crítico */ }
                echo json_encode(['success' => true, 'id' => $newId]);
            } elseif ($method === 'PUT') {
                $data = json_decode(file_get_contents('php://input'), true);
                // Buscar preço anterior para verificar se mudou
                $stmtOld = $conn->prepare("SELECT preco_custo, preco_venda FROM produtos WHERE id=?");
                $stmtOld->execute([$data['id']]);
                $oldPrices = $stmtOld->fetch(PDO::FETCH_ASSOC);

                // Verifica se coluna foto existe para produtos
                $colFotoProdU = $conn->query("SHOW COLUMNS FROM produtos LIKE 'foto'")->fetchAll();
                if (count($colFotoProdU) > 0) {
                    $stmt = $conn->prepare("UPDATE produtos SET codigo_barras=?, nome=?, descricao=?, categoria_id=?, fornecedor_id=?, preco_custo=?, preco_venda=?, estoque_atual=?, estoque_minimo=?, foto=? WHERE id=?");
                    $stmt->execute([$data['codigo_barras'] ?? null, $data['nome'], $data['descricao'] ?? null, $data['categoria_id'] ?? null, $data['fornecedor_id'] ?? null, $data['preco_custo'], $data['preco_venda'], isset($data['estoque_atual']) ? intval($data['estoque_atual']) : 0, $data['estoque_minimo'] ?? 0, $data['foto'] ?? null, $data['id']]);
                } else {
                    $stmt = $conn->prepare("UPDATE produtos SET codigo_barras=?, nome=?, descricao=?, categoria_id=?, fornecedor_id=?, preco_custo=?, preco_venda=?, estoque_atual=?, estoque_minimo=? WHERE id=?");
                    $stmt->execute([$data['codigo_barras'] ?? null, $data['nome'], $data['descricao'] ?? null, $data['categoria_id'] ?? null, $data['fornecedor_id'] ?? null, $data['preco_custo'], $data['preco_venda'], isset($data['estoque_atual']) ? intval($data['estoque_atual']) : 0, $data['estoque_minimo'] ?? 0, $data['id']]);
                }

                // Registrar histórico se preço mudou (ou se ainda não tem registro)
                $stmtCount = $conn->prepare("SELECT COUNT(*) FROM historico_precos WHERE produto_id=?");
                $stmtCount->execute([$data['id']]);
                $hasHistory = $stmtCount->fetchColumn() > 0;

                if (!$hasHistory || !$oldPrices ||
                    floatval($oldPrices['preco_custo']) != floatval($data['preco_custo']) ||
                    floatval($oldPrices['preco_venda']) != floatval($data['preco_venda'])) {
                    try {
                        $conn->exec("CREATE TABLE IF NOT EXISTS historico_precos (id INTEGER PRIMARY KEY AUTOINCREMENT, produto_id INTEGER NOT NULL, preco_custo REAL NOT NULL, preco_venda REAL NOT NULL, data_registro DATETIME)");
                        $dataHP = (new DateTime('now', new DateTimeZone('America/Sao_Paulo')))->format('Y-m-d H:i:s');
                        $stmtHist = $conn->prepare("INSERT INTO historico_precos (produto_id, preco_custo, preco_venda, data_registro) VALUES (?, ?, ?, ?)");
                        $stmtHist->execute([$data['id'], $data['preco_custo'], $data['preco_venda'], $dataHP]);
                    } catch (Exception $eHist) { /* não crítico */ }
                }

                echo json_encode(['success' => true]);
            } elseif ($method === 'DELETE') {
                while (ob_get_level() > 0) { ob_end_clean(); }
                header('Content-Type: application/json; charset=utf-8');
                try {
                    $prodId = intval($_GET['id']);
                    $conn->beginTransaction();
                    $conn->prepare("DELETE FROM historico_compras WHERE produto_id = ?")->execute([$prodId]);
                    $conn->prepare("DELETE FROM historico_precos  WHERE produto_id = ?")->execute([$prodId]);
                    $conn->prepare("DELETE FROM movimentacoes     WHERE produto_id = ?")->execute([$prodId]);
                    $conn->prepare("DELETE FROM produtos          WHERE id = ?")->execute([$prodId]);
                    $conn->commit();
                    echo json_encode(['success' => true]);
                } catch (Exception $eDel) {
                    if ($conn->inTransaction()) $conn->rollBack();
                    http_response_code(500);
                    echo json_encode(['error' => 'Erro ao excluir: ' . $eDel->getMessage()]);
                }
            }
            break;

        // MOVIMENTAÇÕES
        case 'movimentacoes':
            if ($method === 'GET') {
                // Buscar movimentação específica
                if (isset($_GET['id'])) {
                    $stmt = $conn->prepare("SELECT * FROM movimentacoes WHERE id = ?");
                    $stmt->execute([$_GET['id']]);
                    $movimentacao = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($movimentacao) {
                        echo json_encode($movimentacao);
                    } else {
                        http_response_code(404);
                        echo json_encode(['error' => 'Movimentação não encontrada']);
                    }
                } else {
                    // Listar movimentações com filtros
                    $sql = "SELECT m.*, p.nome as produto_nome, c.nome as cliente_nome, f.nome as fornecedor_nome
                            FROM movimentacoes m
                            LEFT JOIN produtos p ON m.produto_id = p.id
                            LEFT JOIN clientes c ON m.cliente_id = c.id
                            LEFT JOIN fornecedores f ON m.fornecedor_id = f.id";

                    $params = [];
                    if (isset($_GET['data_inicio']) && isset($_GET['data_fim'])) {
                        $sql .= " WHERE DATE(m.data_movimentacao) BETWEEN ? AND ?";
                        $params[] = $_GET['data_inicio'];
                        $params[] = $_GET['data_fim'];
                    }

                    $sql .= " ORDER BY m.data_movimentacao DESC";

                    $stmt = $conn->prepare($sql);
                    $stmt->execute($params);
                    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
                }
            } elseif ($method === 'POST') {
                $data = json_decode(file_get_contents('php://input'), true);

                $conn->beginTransaction();

                try {
                    // Inserir movimentação
                    $stmt = $conn->prepare("INSERT INTO movimentacoes (produto_id, tipo, quantidade, valor_unitario, valor_total, cliente_id, fornecedor_id, observacao)
                                           VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([
                        $data['produto_id'],
                        $data['tipo'],
                        $data['quantidade'],
                        $data['valor_unitario'],
                        $data['valor_total'],
                        $data['cliente_id'] ?? null,
                        $data['fornecedor_id'] ?? null,
                        $data['observacao']
                    ]);

                    // Atualizar estoque
                    if ($data['tipo'] === 'entrada') {
                        $stmt = $conn->prepare("UPDATE produtos SET estoque_atual = estoque_atual + ? WHERE id = ?");
                    } else {
                        $stmt = $conn->prepare("UPDATE produtos SET estoque_atual = estoque_atual - ? WHERE id = ?");
                    }
                    $stmt->execute([$data['quantidade'], $data['produto_id']]);

                    $conn->commit();
                    echo json_encode(['success' => true]);
                } catch (Exception $e) {
                    $conn->rollBack();
                    throw $e;
                }
            } elseif ($method === 'PUT') {
                $data = json_decode(file_get_contents('php://input'), true);
                $id = $_GET['id'];

                $conn->beginTransaction();

                try {
                    // Buscar movimentação antiga para reverter o estoque
                    $stmt = $conn->prepare("SELECT * FROM movimentacoes WHERE id = ?");
                    $stmt->execute([$id]);
                    $movimentacaoAntiga = $stmt->fetch(PDO::FETCH_ASSOC);

                    if (!$movimentacaoAntiga) {
                        throw new Exception('Movimentação não encontrada');
                    }

                    // Reverter estoque da movimentação antiga
                    if ($movimentacaoAntiga['tipo'] === 'entrada') {
                        $stmt = $conn->prepare("UPDATE produtos SET estoque_atual = estoque_atual - ? WHERE id = ?");
                    } else {
                        $stmt = $conn->prepare("UPDATE produtos SET estoque_atual = estoque_atual + ? WHERE id = ?");
                    }
                    $stmt->execute([$movimentacaoAntiga['quantidade'], $movimentacaoAntiga['produto_id']]);

                    // Atualizar movimentação
                    $stmt = $conn->prepare("UPDATE movimentacoes SET produto_id = ?, tipo = ?, quantidade = ?, valor_unitario = ?, valor_total = ?, cliente_id = ?, fornecedor_id = ?, observacao = ? WHERE id = ?");
                    $stmt->execute([
                        $data['produto_id'],
                        $data['tipo'],
                        $data['quantidade'],
                        $data['valor_unitario'],
                        $data['valor_total'],
                        $data['cliente_id'] ?? null,
                        $data['fornecedor_id'] ?? null,
                        $data['observacao'],
                        $id
                    ]);

                    // Aplicar estoque da nova movimentação
                    if ($data['tipo'] === 'entrada') {
                        $stmt = $conn->prepare("UPDATE produtos SET estoque_atual = estoque_atual + ? WHERE id = ?");
                    } else {
                        $stmt = $conn->prepare("UPDATE produtos SET estoque_atual = estoque_atual - ? WHERE id = ?");
                    }
                    $stmt->execute([$data['quantidade'], $data['produto_id']]);

                    $conn->commit();
                    echo json_encode(['success' => true]);
                } catch (Exception $e) {
                    $conn->rollBack();
                    throw $e;
                }
            } elseif ($method === 'DELETE') {
                $id = $_GET['id'];

                $conn->beginTransaction();

                try {
                    // Buscar movimentação para reverter o estoque
                    $stmt = $conn->prepare("SELECT * FROM movimentacoes WHERE id = ?");
                    $stmt->execute([$id]);
                    $movimentacao = $stmt->fetch(PDO::FETCH_ASSOC);

                    if (!$movimentacao) {
                        throw new Exception('Movimentação não encontrada');
                    }

                    // Reverter estoque
                    if ($movimentacao['tipo'] === 'entrada') {
                        $stmt = $conn->prepare("UPDATE produtos SET estoque_atual = estoque_atual - ? WHERE id = ?");
                    } else {
                        $stmt = $conn->prepare("UPDATE produtos SET estoque_atual = estoque_atual + ? WHERE id = ?");
                    }
                    $stmt->execute([$movimentacao['quantidade'], $movimentacao['produto_id']]);

                    // Excluir movimentação
                    $stmt = $conn->prepare("DELETE FROM movimentacoes WHERE id = ?");
                    $stmt->execute([$id]);

                    $conn->commit();
                    echo json_encode(['success' => true]);
                } catch (Exception $e) {
                    $conn->rollBack();
                    throw $e;
                }
            }
            break;

        // CLIENTES
        case 'clientes':
            if ($method === 'GET') {
                if (isset($_GET['id'])) {
                    $stmt = $conn->prepare("SELECT * FROM clientes WHERE id = ?");
                    $stmt->execute([$_GET['id']]);
                    $cliente = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($cliente) {
                        echo json_encode($cliente);
                    } else {
                        http_response_code(404);
                        echo json_encode(['error' => 'Cliente não encontrado']);
                    }
                } else {
                    $stmt = $conn->query("SELECT * FROM clientes ORDER BY nome");
                    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
                }
            } elseif ($method === 'POST') {
                $data = json_decode(file_get_contents('php://input'), true);
                if (!$data || empty($data['nome'])) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Nome do cliente é obrigatório']);
                    break;
                }
                $stmt = $conn->prepare("INSERT INTO clientes (nome, cpf_cnpj, telefone, email, endereco, cidade, estado, cep)
                                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $data['nome'],
                    $data['cpf_cnpj'] ?? null,
                    $data['telefone'] ?? null,
                    $data['email'] ?? null,
                    $data['endereco'] ?? null,
                    $data['cidade'] ?? null,
                    $data['estado'] ?? null,
                    $data['cep'] ?? null
                ]);
                echo json_encode(['success' => true, 'id' => $conn->lastInsertId()]);
            } elseif ($method === 'PUT') {
                $data = json_decode(file_get_contents('php://input'), true);
                if (!$data || empty($data['nome']) || empty($data['id'])) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Dados inválidos para atualização']);
                    break;
                }
                $stmt = $conn->prepare("UPDATE clientes SET nome=?, cpf_cnpj=?, telefone=?, email=?, endereco=?, cidade=?, estado=?, cep=? WHERE id=?");
                $stmt->execute([
                    $data['nome'],
                    $data['cpf_cnpj'] ?? null,
                    $data['telefone'] ?? null,
                    $data['email'] ?? null,
                    $data['endereco'] ?? null,
                    $data['cidade'] ?? null,
                    $data['estado'] ?? null,
                    $data['cep'],
                    $data['id']
                ]);
                echo json_encode(['success' => true]);
            } elseif ($method === 'DELETE') {
                $stmt = $conn->prepare("DELETE FROM clientes WHERE id = ?");
                $stmt->execute([$_GET['id']]);
                echo json_encode(['success' => true]);
            }
            break;

        // FORNECEDORES
        case 'fornecedores':
            if ($method === 'GET') {
                if (isset($_GET['id'])) {
                    $stmt = $conn->prepare("SELECT * FROM fornecedores WHERE id = ?");
                    $stmt->execute([$_GET['id']]);
                    $fornecedor = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($fornecedor) {
                        echo json_encode($fornecedor);
                    } else {
                        http_response_code(404);
                        echo json_encode(['error' => 'Fornecedor não encontrado']);
                    }
                } else {
                    $stmt = $conn->query("SELECT * FROM fornecedores ORDER BY nome");
                    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
                }
            } elseif ($method === 'POST') {
                $data = json_decode(file_get_contents('php://input'), true);
                if (!$data || empty($data['nome'])) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Nome do fornecedor é obrigatório']);
                    break;
                }
                // Verifica se coluna foto existe na tabela
                $colunas = $conn->query("SHOW COLUMNS FROM fornecedores LIKE 'foto'")->fetchAll();
                $temFoto = count($colunas) > 0;

                if ($temFoto) {
                    $stmt = $conn->prepare("INSERT INTO fornecedores (nome, cnpj, telefone, email, endereco, cidade, estado, cep, contato_responsavel, foto) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$data['nome'], $data['cnpj'] ?? null, $data['telefone'] ?? null, $data['email'] ?? null, $data['endereco'] ?? null, $data['cidade'] ?? null, $data['estado'] ?? null, $data['cep'] ?? null, $data['contato_responsavel'] ?? null, $data['foto'] ?? null]);
                } else {
                    $stmt = $conn->prepare("INSERT INTO fornecedores (nome, cnpj, telefone, email, endereco, cidade, estado, cep, contato_responsavel) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$data['nome'], $data['cnpj'] ?? null, $data['telefone'] ?? null, $data['email'] ?? null, $data['endereco'] ?? null, $data['cidade'] ?? null, $data['estado'] ?? null, $data['cep'] ?? null, $data['contato_responsavel'] ?? null]);
                }
                echo json_encode(['success' => true, 'id' => $conn->lastInsertId()]);
            } elseif ($method === 'PUT') {
                $data = json_decode(file_get_contents('php://input'), true);
                if (!$data || empty($data['nome']) || empty($data['id'])) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Dados inválidos para atualização']);
                    break;
                }
                // Verifica se coluna foto existe na tabela
                $colunas = $conn->query("SHOW COLUMNS FROM fornecedores LIKE 'foto'")->fetchAll();
                $temFoto = count($colunas) > 0;

                if ($temFoto) {
                    $stmt = $conn->prepare("UPDATE fornecedores SET nome=?, cnpj=?, telefone=?, email=?, endereco=?, cidade=?, estado=?, cep=?, contato_responsavel=?, foto=? WHERE id=?");
                    $stmt->execute([$data['nome'], $data['cnpj'] ?? null, $data['telefone'] ?? null, $data['email'] ?? null, $data['endereco'] ?? null, $data['cidade'] ?? null, $data['estado'] ?? null, $data['cep'] ?? null, $data['contato_responsavel'] ?? null, $data['foto'] ?? null, $data['id']]);
                } else {
                    $stmt = $conn->prepare("UPDATE fornecedores SET nome=?, cnpj=?, telefone=?, email=?, endereco=?, cidade=?, estado=?, cep=?, contato_responsavel=? WHERE id=?");
                    $stmt->execute([$data['nome'], $data['cnpj'] ?? null, $data['telefone'] ?? null, $data['email'] ?? null, $data['endereco'] ?? null, $data['cidade'] ?? null, $data['estado'] ?? null, $data['cep'] ?? null, $data['contato_responsavel'] ?? null, $data['id']]);
                }
                echo json_encode(['success' => true]);
            } elseif ($method === 'DELETE') {
                $stmt = $conn->prepare("DELETE FROM fornecedores WHERE id = ?");
                $stmt->execute([$_GET['id']]);
                echo json_encode(['success' => true]);
            }
            break;

        // CATEGORIAS
        case 'categorias':
            if ($method === 'GET') {
                $stmt = $conn->query("SELECT * FROM categorias ORDER BY nome");
                echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            }
            break;

        // DASHBOARD STATS
        case 'dashboard-stats':
        case 'dashboard_resumo':
            $stats = [];

            // Total de produtos
            $stmt = $conn->query("SELECT COUNT(*) as total FROM produtos");
            $stats['totalProdutos'] = $stmt->fetchColumn();
            $stats['total_produtos'] = $stats['totalProdutos'];

            // Total de entradas (último mês)
            $stmt = $conn->query("SELECT COUNT(*) as total FROM movimentacoes WHERE tipo='entrada' AND data_movimentacao >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
            $stats['totalEntradas'] = $stmt->fetchColumn();
            $stats['total_entradas'] = $stats['totalEntradas'];

            // Total de saídas (último mês)
            $stmt = $conn->query("SELECT COUNT(*) as total FROM movimentacoes WHERE tipo='saida' AND data_movimentacao >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
            $stats['totalSaidas'] = $stmt->fetchColumn();
            $stats['total_saidas'] = $stats['totalSaidas'];

            // Produtos com estoque baixo
            $stmt = $conn->query("SELECT COUNT(*) as total FROM produtos WHERE estoque_atual <= estoque_minimo");
            $stats['produtosBaixos'] = $stmt->fetchColumn();
            $stats['produtos_estoque_baixo'] = $stats['produtosBaixos'];

            // Produtos com estoque baixo (lista)
            $stmt = $conn->query("SELECT * FROM produtos WHERE estoque_atual <= estoque_minimo ORDER BY estoque_atual ASC");
            $stats['alertasProdutos'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode($stats);
            break;

        // ESTOQUE BAIXO
        case 'estoque_baixo':
            $stmt = $conn->query("SELECT p.*, c.nome as categoria_nome FROM produtos p
                                 LEFT JOIN categorias c ON p.categoria_id = c.id
                                 WHERE p.estoque_atual <= p.estoque_minimo
                                 ORDER BY p.estoque_atual ASC");
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            break;

        // DASHBOARD MOVIMENTAÇÕES DO MÊS
        case 'dashboard_movimentacoes_mes':
            $stmt = $conn->query("SELECT
                                 (SELECT COUNT(*) FROM movimentacoes WHERE tipo='entrada' AND data_movimentacao >= DATE_SUB(NOW(), INTERVAL 30 DAY)) as entradas,
                                 (SELECT COUNT(*) FROM movimentacoes WHERE tipo='saida' AND data_movimentacao >= DATE_SUB(NOW(), INTERVAL 30 DAY)) as saidas");
            echo json_encode($stmt->fetch(PDO::FETCH_ASSOC));
            break;

        // DASHBOARD TOP PRODUTOS
        case 'dashboard_top_produtos':
            $stmt = $conn->query("SELECT p.nome, SUM(m.quantidade) as total_vendido
                                 FROM movimentacoes m
                                 JOIN produtos p ON m.produto_id = p.id
                                 WHERE m.tipo='saida' AND m.data_movimentacao >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                                 GROUP BY p.id
                                 ORDER BY total_vendido DESC
                                 LIMIT 5");
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            break;


        // DASHBOARD LUCRO POR PERÍODO
        case 'dashboard_lucro':
            $data_inicio = isset($_GET['data_inicio']) ? $_GET['data_inicio'] : date('Y-m-d', strtotime('-30 days'));
            $data_fim    = isset($_GET['data_fim'])    ? $_GET['data_fim']    : date('Y-m-d');
            $stmt = $conn->prepare("
                SELECT
                    DATE_FORMAT(m.data_movimentacao, '%Y-%m-%d') as data,
                    SUM(m.valor_total) as vendas,
                    SUM(m.valor_total - (p.preco_custo * m.quantidade)) as lucro
                FROM movimentacoes m
                JOIN produtos p ON m.produto_id = p.id
                WHERE m.tipo = 'saida'
                  AND date(m.data_movimentacao) BETWEEN :di AND :df
                GROUP BY DATE_FORMAT(m.data_movimentacao, '%Y-%m-%d')
                ORDER BY data ASC
            ");
            $stmt->execute([':di' => $data_inicio, ':df' => $data_fim]);
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            break;

        // BACKUP DO BANCO DE DADOS (MySQL - gera SQL dump)
        // BACKUP DO BANCO DE DADOS (dump PHP puro - sem mysqldump)
        case 'backup':
            // Verificar se é admin (master ou gerente)
            if ($_SESSION['usuario_tipo'] !== 'admin') {
                http_response_code(403);
                echo json_encode(['error' => 'Acesso negado. Apenas administradores podem fazer backup.']);
                break;
            }
            $nivelAdmin = $_SESSION['nivel_admin'] ?? null;
            if (!in_array($nivelAdmin, ['master', 'gerente'])) {
                http_response_code(403);
                echo json_encode(['error' => 'Acesso negado. Seu nível de administrador não permite fazer backup.']);
                break;
            }
            if ($method === 'GET') {
                $backupName = 'backup-estoque-' . date('Y-m-d_H-i-s') . '.sql';
                try {
                    $stmt = $conn->prepare("INSERT INTO auditoria_backup (usuario_id, usuario_nome, tipo_acao, nome_arquivo, ip_address) VALUES (?, ?, 'backup', ?, ?)");
                    $stmt->execute([$_SESSION['usuario_id'], $_SESSION['usuario_nome'], $backupName, $_SERVER['REMOTE_ADDR'] ?? 'unknown']);
                } catch (Exception $e) {}

                // Dump via PHP puro (funciona em qualquer servidor sem mysqldump)
                $dump  = "-- Backup do Sistema de Estoque\n";
                $dump .= "-- Gerado em: " . date('Y-m-d H:i:s') . "\n\n";
                $dump .= "SET NAMES utf8mb4;\nSET time_zone = '-03:00';\nSET foreign_key_checks = 0;\n\n";

                $tabelas = ['categorias','usuarios','permissoes','clientes','fornecedores',
                            'produtos','movimentacoes','historico_precos','historico_compras','auditoria_backup'];
                foreach ($tabelas as $tabela) {
                    try {
                        $stmtShow = $conn->query("SHOW CREATE TABLE `$tabela`");
                        $row = $stmtShow->fetch(PDO::FETCH_NUM);
                        $dump .= "\n-- Tabela: $tabela\n";
                        $dump .= "DROP TABLE IF EXISTS `$tabela`;\n";
                        $dump .= $row[1] . ";\n\n";
                        $stmtData = $conn->query("SELECT * FROM `$tabela`");
                        $rows = $stmtData->fetchAll(PDO::FETCH_ASSOC);
                        if (!empty($rows)) {
                            $cols = '`' . implode('`, `', array_keys($rows[0])) . '`';
                            foreach ($rows as $r) {
                                $vals = array_map(function($v) use ($conn) {
                                    return $v === null ? 'NULL' : $conn->quote((string)$v);
                                }, array_values($r));
                                $dump .= "INSERT INTO `$tabela` ($cols) VALUES (" . implode(', ', $vals) . ");\n";
                            }
                            $dump .= "\n";
                        }
                    } catch (Exception $ex) {}
                }
                $dump .= "SET foreign_key_checks = 1;\n";

                ob_end_clean();
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="' . $backupName . '"');
                header('Content-Length: ' . strlen($dump));
                header('Cache-Control: no-cache, must-revalidate');
                header('Pragma: public');
                echo $dump;
                exit;
            }
            break;

        // RESTORE DO BANCO DE DADOS (executa SQL via PHP puro)
        case 'restore':
            if ($_SESSION['usuario_tipo'] !== 'admin') {
                http_response_code(403);
                echo json_encode(['error' => 'Acesso negado. Apenas administradores podem restaurar backup.']);
                break;
            }
            $nivelAdmin = $_SESSION['nivel_admin'] ?? null;
            if ($nivelAdmin !== 'master') {
                http_response_code(403);
                echo json_encode(['error' => 'Acesso negado. Apenas Admin Master pode restaurar backup.']);
                break;
            }
            if ($method === 'POST') {
                if (!isset($_FILES['backup']) || $_FILES['backup']['error'] !== UPLOAD_ERR_OK) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Nenhum arquivo enviado ou erro no upload']);
                    break;
                }
                $uploadedFile = $_FILES['backup']['tmp_name'];
                $uploadedName = $_FILES['backup']['name'];

                $firstBytes = file_get_contents($uploadedFile, false, null, 0, 512);
                if (stripos($firstBytes, 'CREATE') === false && stripos($firstBytes, 'INSERT') === false && stripos($firstBytes, '--') === false) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Arquivo inválido. O backup deve ser um arquivo SQL gerado por este sistema.']);
                    break;
                }
                try {
                    $stmt = $conn->prepare("INSERT INTO auditoria_backup (usuario_id, usuario_nome, tipo_acao, nome_arquivo, ip_address) VALUES (?, ?, 'restore', ?, ?)");
                    $stmt->execute([$_SESSION['usuario_id'], $_SESSION['usuario_nome'], $uploadedName, $_SERVER['REMOTE_ADDR'] ?? 'unknown']);
                } catch (Exception $e) {}

                try {
                    $sqlContent = file_get_contents($uploadedFile);
                    $conn->exec("SET foreign_key_checks = 0");
                    $statements = array_filter(array_map('trim', explode(";\n", $sqlContent)), function($s) { return !empty($s); });
                    foreach ($statements as $statement) {
                        $statement = trim($statement);
                        if (empty($statement) || substr($statement, 0, 2) === '--') continue;
                        try { $conn->exec($statement); } catch (Exception $stmtEx) {}
                    }
                    $conn->exec("SET foreign_key_checks = 1");
                    echo json_encode(['success' => true, 'message' => 'Backup restaurado com sucesso! Por favor, faça login novamente.']);
                } catch (Exception $e) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Erro ao restaurar backup: ' . $e->getMessage()]);
                }
            }
            break;

        // AUDITORIA DE BACKUP/RESTORE
        case 'auditoria_backup':
            // Verificar se é admin
            if ($_SESSION['usuario_tipo'] !== 'admin') {
                http_response_code(403);
                echo json_encode(['error' => 'Acesso negado']);
                break;
            }

            if ($method === 'GET') {
                $stmt = $conn->query("SELECT * FROM auditoria_backup ORDER BY data_hora DESC LIMIT 50");
                echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            }
            break;

        // DADOS DO USUÁRIO LOGADO
        case 'user_data':
            if ($method === 'GET') {
                if (isset($_SESSION['usuario_id'])) {
                    echo json_encode([
                        'logado' => true,
                        'usuario' => [
                            'id' => $_SESSION['usuario_id'],
                            'nome' => $_SESSION['usuario_nome'],
                            'username' => $_SESSION['usuario_username'],
                            'tipo' => $_SESSION['usuario_tipo'],
                            'nivel_admin' => $_SESSION['nivel_admin'] ?? null
                        ],
                        'permissoes' => $_SESSION['permissoes']
                    ]);
                } else {
                    echo json_encode(['logado' => false]);
                }
            }
            break;

        case 'historico_precos':
            // Limpar buffer e garantir JSON limpo
            while (ob_get_level() > 0) { ob_end_clean(); }
            header('Content-Type: application/json; charset=utf-8');

            if ($method === 'GET' && isset($_GET['produto_id'])) {
                try {
                    $produtoId = intval($_GET['produto_id']);
                    $periodoHP = isset($_GET['periodo']) && $_GET['periodo'] === 'dia' ? 'dia' : 'mes';

                    // Apagar registros falsos inseridos por versões anteriores
                    // (datas anteriores ao cadastro do produto)
                    $conn->prepare("
                        DELETE hp FROM historico_precos hp
                        JOIN produtos p ON p.id = hp.produto_id
                        WHERE hp.produto_id = ?
                          AND hp.data_registro < p.data_cadastro
                    ")->execute([$produtoId]);

                    if ($periodoHP === 'dia') {
                        // Agrupado por dia
                        $stmt = $conn->prepare("
                            SELECT
                                DATE(data_registro) AS data_dia,
                                ROUND(AVG(preco_custo), 2) AS preco_custo,
                                ROUND(AVG(preco_venda), 2) AS preco_venda
                            FROM historico_precos
                            WHERE produto_id = ? AND data_registro IS NOT NULL
                            GROUP BY DATE(data_registro)
                            ORDER BY data_dia ASC
                            LIMIT 365
                        ");
                        $stmt->execute([$produtoId]);
                        $historico = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    } else {
                        // Buscar histórico de preços agrupado por mês/ano
                        $stmt = $conn->prepare("
                            SELECT
                                YEAR(data_registro) AS ano,
                                MONTH(data_registro) AS mes,
                                ROUND(AVG(preco_custo), 2) AS preco_custo,
                                ROUND(AVG(preco_venda), 2) AS preco_venda
                            FROM historico_precos
                            WHERE produto_id = ? AND data_registro IS NOT NULL
                            GROUP BY YEAR(data_registro), MONTH(data_registro)
                            ORDER BY YEAR(data_registro) ASC, MONTH(data_registro) ASC
                            LIMIT 24
                        ");
                        $stmt->execute([$produtoId]);
                        $historico = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    }

                    // Se histórico tem menos de 2 pontos, gerar 6 meses simulados baseados no preço atual
                    // Se não há nenhum histórico real, registrar o preço atual do produto como ponto inicial
                    if (empty($historico)) {
                        $stmtProd = $conn->prepare("SELECT preco_custo, preco_venda FROM produtos WHERE id = ?");
                        $stmtProd->execute([$produtoId]);
                        $prodAtual = $stmtProd->fetch(PDO::FETCH_ASSOC);
                        if ($prodAtual) {
                            // Inserir apenas o preço atual com a data de hoje (sem retroagir)
                            $stmtIns = $conn->prepare("INSERT INTO historico_precos (produto_id, preco_custo, preco_venda, data_registro) VALUES (?, ?, ?, NOW())");
                            $stmtIns->execute([$produtoId, $prodAtual['preco_custo'], $prodAtual['preco_venda']]);
                            $historico = [[
                                'ano'         => (int)date('Y'),
                                'mes'         => (int)date('n'),
                                'preco_custo' => round(floatval($prodAtual['preco_custo']), 2),
                                'preco_venda' => round(floatval($prodAtual['preco_venda']), 2)
                            ]];
                        }
                    }

                    // Buscar vendas mensais (saídas)
                    $stmtVendas = $conn->prepare("
                        SELECT
                            YEAR(data_movimentacao) AS ano,
                            MONTH(data_movimentacao) AS mes,
                            SUM(quantidade) AS qtd_vendida,
                            ROUND(SUM(valor_total), 2) AS total_vendido
                        FROM movimentacoes
                        WHERE produto_id = ? AND tipo = 'saida' AND data_movimentacao IS NOT NULL
                        GROUP BY YEAR(data_movimentacao), MONTH(data_movimentacao)
                        ORDER BY YEAR(data_movimentacao) ASC, MONTH(data_movimentacao) ASC
                        LIMIT 24
                    ");
                    $stmtVendas->execute([$produtoId]);
                    $vendas = $stmtVendas->fetchAll(PDO::FETCH_ASSOC);

                    // Se o preco atual do produto difere do ultimo historico, adicionar como ponto atual (somente no modo mensal)
                    $stmtAtual = $conn->prepare("SELECT preco_custo, preco_venda FROM produtos WHERE id = ?");
                    $stmtAtual->execute([$produtoId]);
                    $prodPrecoAtual = $stmtAtual->fetch(PDO::FETCH_ASSOC);
                    if ($periodoHP === 'mes' && $prodPrecoAtual && !empty($historico)) {
                        $ultimo = end($historico);
                        $custoAtual = round(floatval($prodPrecoAtual['preco_custo']), 2);
                        $vendaAtual = round(floatval($prodPrecoAtual['preco_venda']), 2);
                        $mesAtual   = (int)date('n');
                        $anoAtual   = (int)date('Y');
                        // Adiciona ponto do mes atual se preco mudou ou mes atual nao esta no historico
                        $jaTemMesAtual = false;
                        foreach ($historico as $h) {
                            if ((int)$h['mes'] == $mesAtual && (int)$h['ano'] == $anoAtual) {
                                $jaTemMesAtual = true; break;
                            }
                        }
                        if (!$jaTemMesAtual || $custoAtual != round(floatval($ultimo['preco_custo']),2) || $vendaAtual != round(floatval($ultimo['preco_venda']),2)) {
                            if (!$jaTemMesAtual) {
                                $historico[] = ['ano' => $anoAtual, 'mes' => $mesAtual, 'preco_custo' => $custoAtual, 'preco_venda' => $vendaAtual];
                            } else {
                                // Atualizar o ponto do mes atual com o preco corrente
                                foreach ($historico as &$h) {
                                    if ((int)$h['mes'] == $mesAtual && (int)$h['ano'] == $anoAtual) {
                                        $h['preco_custo'] = $custoAtual;
                                        $h['preco_venda'] = $vendaAtual;
                                        break;
                                    }
                                }
                                unset($h);
                            }
                        }
                    }

                    echo json_encode([
                        'historico' => $historico,
                        'vendas'    => $vendas,
                        'periodo'   => $periodoHP,
                        'success'   => true
                    ]);
                } catch (Exception $eHP) {
                    http_response_code(500);
                    echo json_encode(['error' => 'Erro historico_precos: ' . $eHP->getMessage(), 'historico' => [], 'vendas' => []]);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'produto_id obrigatorio', 'historico' => [], 'vendas' => []]);
            }
            break;

        case 'repor_estoque':
            if ($method === 'POST') {
                // Limpar buffer para garantir resposta limpa
                while (ob_get_level() > 0) { ob_end_clean(); }
                header('Content-Type: application/json');

                try {
                    $rawInput = file_get_contents('php://input');
                    $data = json_decode($rawInput, true);

                    if (empty($data['produto_id']) || empty($data['quantidade']) || !isset($data['preco_custo'])) {
                        http_response_code(400);
                        echo json_encode(['error' => 'Dados obrigatórios: produto_id, quantidade, preco_custo']);
                        break;
                    }

                    $produtoId    = intval($data['produto_id']);
                    $quantidade   = intval($data['quantidade']);
                    $precoCusto   = floatval($data['preco_custo']);
                    $precoVenda   = isset($data['preco_venda']) ? floatval($data['preco_venda']) : null;
                    $fornecedorId = !empty($data['fornecedor_id']) ? intval($data['fornecedor_id']) : null;
                    $observacao   = isset($data['observacao']) ? $data['observacao'] : '';

                    // Garantir que as tabelas existem com todas as colunas necessárias
                    $conn->exec("CREATE TABLE IF NOT EXISTS historico_compras (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        produto_id INT NOT NULL,
                        quantidade INT NOT NULL,
                        preco_custo DECIMAL(10,2) NOT NULL,
                        preco_custo_anterior DECIMAL(10,2),
                        fornecedor_id INT,
                        observacao TEXT,
                        data_compra DATETIME
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                    $conn->exec("CREATE TABLE IF NOT EXISTS historico_precos (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        produto_id INT NOT NULL,
                        preco_custo DECIMAL(10,2) NOT NULL,
                        preco_venda DECIMAL(10,2) NOT NULL,
                        data_registro DATETIME
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                    $conn->exec("CREATE TABLE IF NOT EXISTS movimentacoes (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        produto_id INT NOT NULL,
                        tipo VARCHAR(20) NOT NULL,
                        quantidade INT NOT NULL,
                        valor_unitario DECIMAL(10,2),
                        valor_total DECIMAL(10,2),
                        cliente_id INT,
                        fornecedor_id INT,
                        observacao TEXT,
                        data_movimentacao DATETIME DEFAULT CURRENT_TIMESTAMP
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                    // Adicionar colunas que podem faltar em bancos antigos
                    try { $conn->exec("ALTER TABLE movimentacoes ADD COLUMN fornecedor_id INTEGER"); } catch(Exception $ex) {}
                    try { $conn->exec("ALTER TABLE movimentacoes ADD COLUMN observacao TEXT"); } catch(Exception $ex) {}

                    // Busca dados atuais do produto
                    $stmtP = $conn->prepare("SELECT preco_custo, preco_venda, estoque_atual FROM produtos WHERE id=?");
                    $stmtP->execute([$produtoId]);
                    $produtoAtual = $stmtP->fetch(PDO::FETCH_ASSOC);
                    if (!$produtoAtual) {
                        http_response_code(404);
                        echo json_encode(['error' => 'Produto não encontrado (id=' . $produtoId . ')']);
                        break;
                    }

                    $precoCustoAnterior = floatval($produtoAtual['preco_custo']);
                    $precoVendaAtual    = $precoVenda !== null ? $precoVenda : floatval($produtoAtual['preco_venda']);

                    // Data/hora no timezone de Brasília
                    $dataAgora = date('Y-m-d H:i:s');

                    // Atualiza estoque e preço no produto
                    $stmtU = $conn->prepare("UPDATE produtos SET estoque_atual = estoque_atual + ?, preco_custo = ?, preco_venda = ? WHERE id = ?");
                    $stmtU->execute([$quantidade, $precoCusto, $precoVendaAtual, $produtoId]);

                    // Salva em historico_compras
                    try {
                        $stmtHC = $conn->prepare("INSERT INTO historico_compras (produto_id, quantidade, preco_custo, preco_custo_anterior, fornecedor_id, observacao, data_compra) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmtHC->execute([$produtoId, $quantidade, $precoCusto, $precoCustoAnterior, $fornecedorId, $observacao, $dataAgora]);
                    } catch (Exception $eHC) { /* não crítico */ }

                    // Salva em historico_precos se o preço mudou
                    if (abs($precoCusto - $precoCustoAnterior) > 0.001 || abs($precoVendaAtual - floatval($produtoAtual['preco_venda'])) > 0.001) {
                        try {
                            $stmtHP = $conn->prepare("INSERT INTO historico_precos (produto_id, preco_custo, preco_venda, data_registro) VALUES (?, ?, ?, ?)");
                            $stmtHP->execute([$produtoId, $precoCusto, $precoVendaAtual, $dataAgora]);
                        } catch (Exception $eHP) { /* não crítico */ }
                    }

                    // Registra movimentação de entrada
                    try {
                        $obsMovimentacao = 'Reposição de estoque' . ($observacao ? ': ' . $observacao : '');
                        $stmtMov = $conn->prepare("INSERT INTO movimentacoes (produto_id, tipo, quantidade, valor_unitario, valor_total, fornecedor_id, observacao) VALUES (?, 'entrada', ?, ?, ?, ?, ?)");
                        $stmtMov->execute([$produtoId, $quantidade, $precoCusto, $precoCusto * $quantidade, $fornecedorId, $obsMovimentacao]);
                    } catch (Exception $eMov) { /* não crítico */ }

                    echo json_encode(['success' => true, 'message' => 'Estoque reposto com sucesso']);

                } catch (Exception $eRepor) {
                    http_response_code(500);
                    echo json_encode(['error' => 'Erro interno: ' . $eRepor->getMessage()]);
                }
            }
            break;

        case 'historico_compras':
            if ($method === 'GET' && isset($_GET['produto_id'])) {
                $produtoId = intval($_GET['produto_id']);
                $filtroAno = isset($_GET['ano']) && intval($_GET['ano']) > 0 ? intval($_GET['ano']) : 0;
                $filtroMes = isset($_GET['mes']) && intval($_GET['mes']) > 0 ? intval($_GET['mes']) : 0;

                $where = "WHERE hc.produto_id = ?";
                $params = [$produtoId];
                if ($filtroAno > 0) {
                    $where .= " AND YEAR(hc.data_compra) = ?";
                    $params[] = $filtroAno;
                }
                if ($filtroMes > 0) {
                    $where .= " AND MONTH(hc.data_compra) = ?";
                    $params[] = $filtroMes;
                }

                $stmt = $conn->prepare("
                    SELECT hc.id, hc.quantidade, hc.preco_custo, hc.preco_custo_anterior,
                           hc.observacao, hc.data_compra, f.nome as fornecedor_nome
                    FROM historico_compras hc
                    LEFT JOIN fornecedores f ON f.id = hc.fornecedor_id
                    $where
                    ORDER BY hc.data_compra DESC
                    LIMIT 500
                ");
                $stmt->execute($params);
                $compras = $stmt->fetchAll(PDO::FETCH_ASSOC);

                // Dados mensais para gráfico (ano filtrado ou todos)
                $whereG = "WHERE hc.produto_id = ?";
                $paramsG = [$produtoId];
                if ($filtroAno > 0) {
                    $whereG .= " AND YEAR(hc.data_compra) = ?";
                    $paramsG[] = $filtroAno;
                }
                $stmtM = $conn->prepare("
                    SELECT DATE_FORMAT(hc.data_compra, '%Y-%m') as mes_ano,
                           AVG(hc.preco_custo) as preco_medio,
                           MAX(hc.preco_custo) as preco_max,
                           MIN(hc.preco_custo) as preco_min,
                           SUM(hc.quantidade) as qtd_total,
                           COUNT(*) as num_compras
                    FROM historico_compras hc
                    $whereG
                    GROUP BY DATE_FORMAT(hc.data_compra, '%Y-%m')
                    ORDER BY mes_ano ASC
                ");
                $stmtM->execute($paramsG);
                $mensal = $stmtM->fetchAll(PDO::FETCH_ASSOC);

                // Anos disponíveis
                $stmtAnos = $conn->prepare("
                    SELECT DISTINCT YEAR(data_compra) as ano
                    FROM historico_compras WHERE produto_id = ? ORDER BY ano DESC
                ");
                $stmtAnos->execute([$produtoId]);
                $anos = array_column($stmtAnos->fetchAll(PDO::FETCH_ASSOC), 'ano');

                echo json_encode(['compras' => $compras, 'mensal' => $mensal, 'anos' => $anos]);

            } elseif ($method === 'POST' && isset($_GET['acao']) && $_GET['acao'] === 'importar') {
                $data = json_decode(file_get_contents('php://input'), true);
                $produtoId = intval($data['produto_id'] ?? 0);
                $linhas = $data['linhas'] ?? [];
                if (!$produtoId || empty($linhas)) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Dados inválidos para importação']);
                    break;
                }
                $stmtIns = $conn->prepare("INSERT INTO historico_compras (produto_id, quantidade, preco_custo, preco_custo_anterior, observacao, data_compra) VALUES (?, ?, ?, ?, ?, ?)");
                $importados = 0;
                foreach ($linhas as $linha) {
                    if (empty($linha['data_compra']) || !isset($linha['preco_custo'])) continue;
                    $stmtIns->execute([
                        $produtoId,
                        intval($linha['quantidade'] ?? 1),
                        floatval(str_replace(',', '.', $linha['preco_custo'])),
                        floatval(str_replace(',', '.', $linha['preco_custo_anterior'] ?? 0)),
                        $linha['observacao'] ?? '',
                        $linha['data_compra']
                    ]);
                    $importados++;
                }
                echo json_encode(['success' => true, 'importados' => $importados]);
            }
            break;

        // CONFIGURAÇÕES DO SISTEMA (somente super admin id=1)
        case 'configuracoes':
            if ($_SESSION['usuario_id'] != 1) {
                http_response_code(403);
                echo json_encode(['error' => 'Acesso negado']);
                break;
            }
            if ($method === 'GET') {
                $stmtLim = $conn->query("SELECT valor FROM configuracoes WHERE chave = 'limite_usuarios'");
                $limRow  = $stmtLim->fetch();
                $limite  = $limRow ? (int)$limRow['valor'] : 0;
                // total de usuários excluindo o super admin
                $stmtCnt = $conn->query("SELECT COUNT(*) FROM usuarios WHERE id != 1");
                $total   = (int)$stmtCnt->fetchColumn();
                echo json_encode(['limite_usuarios' => $limite, 'total_usuarios' => $total]);
            } elseif ($method === 'PUT') {
                $data   = json_decode(file_get_contents('php://input'), true);
                $limite = max(0, (int)($data['limite_usuarios'] ?? 0));
                $stmt   = $conn->prepare("INSERT INTO configuracoes (chave, valor) VALUES ('limite_usuarios', ?) ON DUPLICATE KEY UPDATE valor = ?");
                $stmt->execute([$limite, $limite]);
                echo json_encode(['success' => true]);
            }
            break;

        default:
            http_response_code(404);
            echo json_encode(['error' => 'Endpoint não encontrado']);
            break;
    }
} catch (Exception $e) {
    ob_end_clean();
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
