// Autenticação e Gestão de Usuários
let usuarioLogado = null;
let permissoesUsuario = {};
let autenticacaoCarregada = false;
let autenticacaoEmAndamento = false;

// Função auxiliar para verificar permissão
function verificarPermissaoSecao(section) {
    if (!autenticacaoCarregada) {
        return false;
    }

    if (permissoesUsuario[section] === undefined) {
        return true; // Se não houver permissão definida, permite
    }

    return permissoesUsuario[section] == 1;
}

// Verificar se usuário está logado ao carregar a página
document.addEventListener('DOMContentLoaded', async () => {
    await verificarAutenticacao();
    if (typeof inicializarMascaras === 'function') {
        inicializarMascaras();
    }
});

async function verificarAutenticacao() {
    // Prevenir múltiplas execuções simultâneas
    if (autenticacaoEmAndamento || autenticacaoCarregada) {
        return;
    }

    autenticacaoEmAndamento = true;

    // A verificação é feita pelo PHP, se chegarmos aqui é porque está logado
    // Vamos buscar os dados do usuário
    try {
        const response = await fetch('get-user-data.php');
        const result = await response.json();

        if (!result.logado) {
            window.location.href = 'login.php';
            return;
        }

        usuarioLogado = result.usuario;
        permissoesUsuario = result.permissoes;
        autenticacaoCarregada = true;

        // Atualizar nome do usuário no sidebar
        if (document.getElementById('usuarioNome')) {
            document.getElementById('usuarioNome').textContent = usuarioLogado.nome;
        }

        // Controlar visibilidade dos menus baseado nas permissões
        aplicarPermissoes();

        // Se for admin, mostrar menu de administração
        if (permissoesUsuario.administracao == 1) {
            const menuAdmin = document.getElementById('menuAdmin');
            if (menuAdmin) {
                menuAdmin.style.display = 'block';
            }
        }

        // Inicializar o app SOMENTE APÓS autenticação completa
        if (typeof inicializarApp === 'function') {
            inicializarApp();
        }

    } catch (error) {
        console.error('Erro ao verificar autenticação:', error);
        window.location.href = 'login.php';
    } finally {
        autenticacaoEmAndamento = false;
    }
}

function aplicarPermissoes() {
    // Ocultar menus sem permissão
    document.querySelectorAll('.nav-link[data-permissao]').forEach(link => {
        const permissao = link.getAttribute('data-permissao');
        if (permissoesUsuario[permissao] == 0) {
            link.style.display = 'none';
        }
    });

    // Não redirecionar automaticamente - deixar o app.js fazer isso
    // A primeira seção ativa será mantida (dashboard por padrão)
}

function logout() {
    window.location.href = 'logout.php';
}

// ADMINISTRAÇÃO - USUÁRIOS
async function carregarUsuarios() {
    // Mostrar painel de limite apenas para o Super Admin (id = 1)
    if (usuarioLogado && usuarioLogado.id == 1) {
        const painel = document.getElementById('painelLimiteUsuarios');
        if (painel) painel.style.display = 'block';
        carregarLimiteUsuarios();
    }

    try {
        const response = await fetch('api.php?endpoint=usuarios');
        const usuarios = await response.json();

        const tbody = document.getElementById('listaUsuarios');
        tbody.innerHTML = '';

        if (usuarios.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" class="empty-state">
                        <i class="fas fa-users"></i>
                        <p>Nenhum usuário cadastrado</p>
                    </td>
                </tr>
            `;
        } else {
            usuarios.forEach(usuario => {
                const statusClass = usuario.ativo == 1 ? 'estoque-ok' : 'estoque-baixo';
                const statusText = usuario.ativo == 1 ? 'Ativo' : 'Inativo';
                const tipoBadge = usuario.tipo === 'admin' ? 'tipo-entrada' : 'tipo-saida';
                const tipoText = usuario.tipo === 'admin' ? 'ADMIN' : 'USUÁRIO';

                // Criar lista de permissões
                const permissoes = [];
                if (usuario.dashboard == 1) permissoes.push('Dashboard');
                if (usuario.produtos == 1) permissoes.push('Produtos');
                if (usuario.movimentacoes == 1) permissoes.push('Movimentações');
                if (usuario.clientes == 1) permissoes.push('Clientes');
                if (usuario.fornecedores == 1) permissoes.push('Fornecedores');
                if (usuario.alertas == 1) permissoes.push('Alertas');
                if (usuario.administracao == 1) permissoes.push('Admin');

                const permissoesText = permissoes.length > 0 ? permissoes.join(', ') : 'Nenhuma';

                tbody.innerHTML += `
                    <tr>
                        <td><strong>${usuario.nome}</strong></td>
                        <td><code>${usuario.username}</code></td>
                        <td><span class="tipo-badge ${tipoBadge}">${tipoText}</span></td>
                        <td><span class="estoque-badge ${statusClass}">${statusText}</span></td>
                        <td><small>${permissoesText}</small></td>
                        <td>${formatarDataHoraBrasil(usuario.data_cadastro)}</td>
                        <td>
                            <button class="btn btn-sm btn-primary" onclick="editarUsuario(${usuario.id})">
                                <i class="fas fa-edit"></i>
                            </button>
                            ${usuario.id !== 1 ? `
                                <button class="btn btn-sm btn-danger" onclick="excluirUsuario(${usuario.id})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            ` : ''}
                        </td>
                    </tr>
                `;
            });
        }
    } catch (error) {
        console.error('Erro ao carregar usuários:', error);
    }
}

// Função para mostrar/ocultar campo de nível admin
function toggleNivelAdmin() {
    const tipo = document.getElementById('usuarioTipo').value;
    const nivelAdminGroup = document.getElementById('nivelAdminGroup');
    const nivelAdminSelect = document.getElementById('usuarioNivelAdmin');

    if (tipo === 'admin') {
        nivelAdminGroup.style.display = '';
        nivelAdminSelect.required = true;
    } else {
        nivelAdminGroup.style.display = 'none';
        nivelAdminSelect.required = false;
        nivelAdminSelect.value = '';
    }
}

function abrirModalUsuario(id = null) {
    document.getElementById('modalUsuarioTitulo').textContent = id ? 'Editar Usuário' : 'Novo Usuário';

    // Apenas resetar o formulário se for um NOVO usuário (não edição)
    if (!id) {
        document.getElementById('formUsuario').reset();
        document.getElementById('usuarioId').value = '';

        // Marcar todas as permissões por padrão (exceto admin)
        document.getElementById('permDashboard').checked = true;
        document.getElementById('permProdutos').checked = true;
        document.getElementById('permMovimentacoes').checked = true;
        document.getElementById('permClientes').checked = true;
        document.getElementById('permFornecedores').checked = true;
        document.getElementById('permAlertas').checked = true;
        document.getElementById('permAdministracao').checked = false;

        // Resetar nível admin
        toggleNivelAdmin();
    }

    document.getElementById('modalUsuario').classList.add('active');
}

async function editarUsuario(id) {
    try {
        // Abrir o modal ANTES de carregar os dados
        abrirModalUsuario(id);

        // Buscar dados do usuário
        const response = await fetch(`api.php?endpoint=usuarios&id=${id}`);
        const usuario = await response.json();

        // Log para debug
        console.log('Dados do usuário recebidos:', usuario);

        // Verificar se recebeu os dados corretamente
        if (!usuario || !usuario.id) {
            throw new Error('Dados do usuário não foram recebidos corretamente');
        }

        // Preencher campos do formulário
        document.getElementById('usuarioId').value = usuario.id || '';
        document.getElementById('usuarioNomeForm').value = usuario.nome || '';
        document.getElementById('usuarioUsername').value = usuario.username || '';
        document.getElementById('usuarioTipo').value = usuario.tipo || 'usuario';
        document.getElementById('usuarioAtivo').value = usuario.ativo || '1';

        // Configurar nível admin se for administrador
        if (usuario.tipo === 'admin') {
            document.getElementById('nivelAdminGroup').style.display = 'block';
            if (usuario.nivel_admin) {
                document.getElementById('usuarioNivelAdmin').value = usuario.nivel_admin;
            }
        } else {
            document.getElementById('nivelAdminGroup').style.display = 'none';
        }

        // Marcar permissões
        document.getElementById('permDashboard').checked = (usuario.dashboard == 1);
        document.getElementById('permProdutos').checked = (usuario.produtos == 1);
        document.getElementById('permMovimentacoes').checked = (usuario.movimentacoes == 1);
        document.getElementById('permClientes').checked = (usuario.clientes == 1);
        document.getElementById('permFornecedores').checked = (usuario.fornecedores == 1);
        document.getElementById('permAlertas').checked = (usuario.alertas == 1);
        document.getElementById('permAdministracao').checked = (usuario.administracao == 1);

    } catch (error) {
        console.error('Erro ao carregar usuário:', error);
        alert('Erro ao carregar dados do usuário: ' + error.message);
        fecharModal('modalUsuario');
    }
}

async function salvarUsuario(event) {
    event.preventDefault();

    const id = document.getElementById('usuarioId').value;
    const senha = document.getElementById('usuarioSenha').value;

    // Validar senha em novo usuário
    if (!id && !senha) {
        alert('A senha é obrigatória para novos usuários');
        return;
    }

    const tipo = document.getElementById('usuarioTipo').value;
    const nivelAdmin = tipo === 'admin' ? document.getElementById('usuarioNivelAdmin').value : null;

    // Validar nível admin se for administrador
    if (tipo === 'admin' && !nivelAdmin) {
        alert('Por favor, selecione o nível de administrador');
        return;
    }

    const data = {
        id: id,
        nome: document.getElementById('usuarioNomeForm').value,
        username: document.getElementById('usuarioUsername').value,
        senha: senha,
        tipo: tipo,
        nivel_admin: nivelAdmin,
        ativo: document.getElementById('usuarioAtivo').value,
        permissoes: {
            dashboard: document.getElementById('permDashboard').checked ? 1 : 0,
            produtos: document.getElementById('permProdutos').checked ? 1 : 0,
            movimentacoes: document.getElementById('permMovimentacoes').checked ? 1 : 0,
            clientes: document.getElementById('permClientes').checked ? 1 : 0,
            fornecedores: document.getElementById('permFornecedores').checked ? 1 : 0,
            alertas: document.getElementById('permAlertas').checked ? 1 : 0,
            administracao: document.getElementById('permAdministracao').checked ? 1 : 0
        }
    };

    try {
        const method = id ? 'PUT' : 'POST';
        const response = await fetch('api.php?endpoint=usuarios', {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (result.success) {
            alert('Usuário salvo com sucesso!');
            fecharModal('modalUsuario');
            carregarUsuarios();
        } else if (result.error === 'limite_atingido') {
            alert('⚠️ ' + result.message);
        } else if (result.error) {
            alert('Erro: ' + result.error);
        }
    } catch (error) {
        console.error('Erro ao salvar usuário:', error);
        alert('Erro ao salvar usuário!');
    }
}

async function excluirUsuario(id) {
    if (!confirm('Deseja realmente excluir este usuário?')) return;

    try {
        const response = await fetch(`api.php?endpoint=usuarios&id=${id}`, {
            method: 'DELETE'
        });

        const result = await response.json();

        if (result.success) {
            alert('Usuário excluído com sucesso!');
            carregarUsuarios();
        } else if (result.error) {
            alert('Erro: ' + result.error);
        }
    } catch (error) {
        console.error('Erro ao excluir usuário:', error);
        alert('Erro ao excluir usuário!');
    }
}

// ── CONTROLE DE LIMITE DE USUÁRIOS (Super Admin apenas) ────────────────────

async function carregarLimiteUsuarios() {
    try {
        const resp = await fetch('api.php?endpoint=configuracoes');
        const data = await resp.json();
        if (data.error) return;

        const limite = data.limite_usuarios || 0;
        const total  = data.total_usuarios  || 0;

        // Checkbox ilimitado
        const chk = document.getElementById('chkIlimitado');
        const num = document.getElementById('limiteNumero');
        const ctrl = document.getElementById('controleNumerico');

        if (limite === 0) {
            // ilimitado
            if (chk)  chk.checked = true;
            if (ctrl) ctrl.style.opacity = '0.35';
            if (ctrl) ctrl.style.pointerEvents = 'none';
            if (num)  num.value = 1;
        } else {
            if (chk)  chk.checked = false;
            if (ctrl) ctrl.style.opacity = '1';
            if (ctrl) ctrl.style.pointerEvents = '';
            if (num)  num.value = limite;
        }

        // Texto de uso
        const txt = document.getElementById('limiteUsoTexto');
        if (txt) {
            if (limite === 0) {
                txt.textContent = total + ' usuário(s) cadastrado(s) · sem limite definido';
            } else {
                const restam = Math.max(0, limite - total);
                txt.textContent = total + ' de ' + limite + ' cadastrado(s) · ' + restam + ' vaga(s) disponível(is)';
            }
        }
    } catch (e) {
        console.error('Erro ao carregar limite:', e);
    }
}

function toggleIlimitado() {
    const chk  = document.getElementById('chkIlimitado');
    const ctrl = document.getElementById('controleNumerico');
    if (!chk || !ctrl) return;

    if (chk.checked) {
        // Ilimitado: desabilita controle numérico
        ctrl.style.opacity = '0.35';
        ctrl.style.pointerEvents = 'none';
        salvarLimiteUsuarios(0); // 0 = ilimitado
    } else {
        // Limitado: habilita controle numérico
        ctrl.style.opacity = '1';
        ctrl.style.pointerEvents = '';
        const num = document.getElementById('limiteNumero');
        const val = parseInt(num ? num.value : 1) || 1;
        if (num) num.value = val;
        salvarLimiteUsuarios(val);
    }
}

function alterarLimite(delta) {
    const chk = document.getElementById('chkIlimitado');
    if (chk && chk.checked) return; // ilimitado, não faz nada

    const num = document.getElementById('limiteNumero');
    if (!num) return;
    let val = parseInt(num.value) || 1;
    val = Math.max(1, val + delta);
    num.value = val;
    salvarLimiteUsuarios(val);
}

async function salvarLimiteUsuarios(limiteParam) {
    const chk = document.getElementById('chkIlimitado');
    let limite;
    if (limiteParam !== undefined) {
        limite = limiteParam;
    } else {
        if (chk && chk.checked) {
            limite = 0;
        } else {
            const num = document.getElementById('limiteNumero');
            limite = parseInt(num ? num.value : 1) || 1;
        }
    }

    try {
        const resp = await fetch('api.php?endpoint=configuracoes', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ limite_usuarios: limite })
        });
        const data = await resp.json();
        if (data.success) {
            // Mostrar "Salvo!" por 2 segundos
            const msg = document.getElementById('limiteSalvoMsg');
            if (msg) {
                msg.style.display = 'inline';
                setTimeout(() => { msg.style.display = 'none'; }, 2000);
            }
            // Recarregar texto de uso
            carregarLimiteUsuarios();
        }
    } catch (e) {
        console.error('Erro ao salvar limite:', e);
    }
}
// ───────────────────────────────────────────────────────────────────────────
