<?php
// Configurar timezone para horário de Brasília (GMT-3)
date_default_timezone_set('America/Sao_Paulo');

class Database {
    private $db;

    // Configurações padrão do Laragon (funciona sem configurar nada)
    private $host    = 'localhost';
    private $port    = '3306';
    private $dbname  = 'estoque_db';
    private $user    = 'root';
    private $pass    = '';       // Laragon padrão: sem senha
    private $charset = 'utf8mb4';

    public function __construct() {
        // 1) Conecta sem selecionar banco para poder criá-lo se não existir
        $dsn = "mysql:host={$this->host};port={$this->port};charset={$this->charset}";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4, time_zone = '-03:00'",
        ];
        $tmp = new PDO($dsn, $this->user, $this->pass, $options);

        // 2) Cria o banco se não existir
        $tmp->exec("CREATE DATABASE IF NOT EXISTS `{$this->dbname}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $tmp = null;

        // 3) Conecta ao banco correto
        $dsn = "mysql:host={$this->host};port={$this->port};dbname={$this->dbname};charset={$this->charset}";
        $this->db = new PDO($dsn, $this->user, $this->pass, $options);

        $this->createTables();
    }

    private function createTables() {
        // Tabela de usuários
        $this->db->exec("CREATE TABLE IF NOT EXISTS usuarios (
            id            INT AUTO_INCREMENT PRIMARY KEY,
            nome          VARCHAR(255) NOT NULL,
            username      VARCHAR(100) UNIQUE NOT NULL,
            senha         VARCHAR(255) NOT NULL,
            tipo          VARCHAR(20)  DEFAULT 'usuario',
            nivel_admin   VARCHAR(20)  DEFAULT NULL,
            ativo         TINYINT(1)   DEFAULT 1,
            data_cadastro DATETIME     DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Tabela de permissões
        $this->db->exec("CREATE TABLE IF NOT EXISTS permissoes (
            id             INT AUTO_INCREMENT PRIMARY KEY,
            usuario_id     INT NOT NULL,
            dashboard      TINYINT(1) DEFAULT 1,
            produtos       TINYINT(1) DEFAULT 1,
            movimentacoes  TINYINT(1) DEFAULT 1,
            clientes       TINYINT(1) DEFAULT 1,
            fornecedores   TINYINT(1) DEFAULT 1,
            alertas        TINYINT(1) DEFAULT 1,
            administracao  TINYINT(1) DEFAULT 0,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Tabela de clientes
        $this->db->exec("CREATE TABLE IF NOT EXISTS clientes (
            id            INT AUTO_INCREMENT PRIMARY KEY,
            nome          VARCHAR(255) NOT NULL,
            cpf_cnpj      VARCHAR(30),
            telefone      VARCHAR(30),
            email         VARCHAR(255),
            endereco      TEXT,
            cidade        VARCHAR(100),
            estado        VARCHAR(50),
            cep           VARCHAR(20),
            data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Tabela de fornecedores
        $this->db->exec("CREATE TABLE IF NOT EXISTS fornecedores (
            id                   INT AUTO_INCREMENT PRIMARY KEY,
            nome                 VARCHAR(255) NOT NULL,
            cnpj                 VARCHAR(30),
            telefone             VARCHAR(30),
            email                VARCHAR(255),
            endereco             TEXT,
            cidade               VARCHAR(100),
            estado               VARCHAR(50),
            cep                  VARCHAR(20),
            contato_responsavel  VARCHAR(255),
            data_cadastro        DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Tabela de categorias
        $this->db->exec("CREATE TABLE IF NOT EXISTS categorias (
            id        INT AUTO_INCREMENT PRIMARY KEY,
            nome      VARCHAR(255) NOT NULL,
            descricao TEXT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Tabela de produtos
        $this->db->exec("CREATE TABLE IF NOT EXISTS produtos (
            id              INT AUTO_INCREMENT PRIMARY KEY,
            codigo_barras   VARCHAR(100),
            nome            VARCHAR(255) NOT NULL,
            descricao       TEXT,
            categoria_id    INT,
            fornecedor_id   INT,
            preco_custo     DECIMAL(10,2) NOT NULL,
            preco_venda     DECIMAL(10,2) NOT NULL,
            estoque_atual   INT DEFAULT 0,
            estoque_minimo  INT DEFAULT 0,
            foto            VARCHAR(255),
            data_cadastro   DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (categoria_id)  REFERENCES categorias(id),
            FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Tabela de movimentações
        $this->db->exec("CREATE TABLE IF NOT EXISTS movimentacoes (
            id                  INT AUTO_INCREMENT PRIMARY KEY,
            produto_id          INT NOT NULL,
            tipo                VARCHAR(20) NOT NULL,
            quantidade          INT NOT NULL,
            valor_unitario      DECIMAL(10,2),
            valor_total         DECIMAL(10,2),
            cliente_id          INT,
            fornecedor_id       INT,
            observacao          TEXT,
            data_movimentacao   DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (produto_id)    REFERENCES produtos(id),
            FOREIGN KEY (cliente_id)    REFERENCES clientes(id),
            FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Tabela de histórico de preços
        $this->db->exec("CREATE TABLE IF NOT EXISTS historico_precos (
            id             INT AUTO_INCREMENT PRIMARY KEY,
            produto_id     INT NOT NULL,
            preco_custo    DECIMAL(10,2) NOT NULL,
            preco_venda    DECIMAL(10,2) NOT NULL,
            data_registro  DATETIME,
            FOREIGN KEY (produto_id) REFERENCES produtos(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Tabela de histórico de compras
        $this->db->exec("CREATE TABLE IF NOT EXISTS historico_compras (
            id                   INT AUTO_INCREMENT PRIMARY KEY,
            produto_id           INT NOT NULL,
            quantidade           INT NOT NULL,
            preco_custo          DECIMAL(10,2) NOT NULL,
            preco_custo_anterior DECIMAL(10,2),
            fornecedor_id        INT,
            observacao           TEXT,
            data_compra          DATETIME,
            FOREIGN KEY (produto_id)    REFERENCES produtos(id),
            FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Tabela de auditoria de backup/restore
        $this->db->exec("CREATE TABLE IF NOT EXISTS auditoria_backup (
            id            INT AUTO_INCREMENT PRIMARY KEY,
            usuario_id    INT NOT NULL,
            usuario_nome  VARCHAR(255) NOT NULL,
            tipo_acao     VARCHAR(20) NOT NULL,
            nome_arquivo  VARCHAR(255),
            data_hora     DATETIME DEFAULT CURRENT_TIMESTAMP,
            ip_address    VARCHAR(50),
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Tabela de configurações do sistema (super admin)
        $this->db->exec("CREATE TABLE IF NOT EXISTS configuracoes (
            chave VARCHAR(100) PRIMARY KEY,
            valor TEXT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Valor padrão: limite 0 = ilimitado
        $this->db->exec("INSERT IGNORE INTO configuracoes (chave, valor) VALUES ('limite_usuarios', '0')");

        // Inserir dados iniciais
        $this->insertSampleData();
    }

    private function insertSampleData() {
        // Cria admin master apenas se não houver nenhum usuário
        $stmt = $this->db->query("SELECT COUNT(*) FROM usuarios");
        if ($stmt->fetchColumn() == 0) {
            // Senha: Admin@2024!
            $senhaHash = password_hash('Admin@2024!', PASSWORD_DEFAULT);
            $stmt = $this->db->prepare("INSERT INTO usuarios (nome, username, senha, tipo, nivel_admin) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute(['Administrador do Sistema', 'admin', $senhaHash, 'admin', 'master']);
            $adminId = $this->db->lastInsertId();

            $stmt = $this->db->prepare("INSERT INTO permissoes (usuario_id, dashboard, produtos, movimentacoes, clientes, fornecedores, alertas, administracao) VALUES (?, 1, 1, 1, 1, 1, 1, 1)");
            $stmt->execute([$adminId]);

            // Usuário vendedor de exemplo
            $senhaUsuario = password_hash('vendedor123', PASSWORD_DEFAULT);
            $stmt = $this->db->prepare("INSERT INTO usuarios (nome, username, senha, tipo) VALUES (?, ?, ?, ?)");
            $stmt->execute(['Vendedor Exemplo', 'vendedor', $senhaUsuario, 'usuario']);
            $vendedorId = $this->db->lastInsertId();

            $stmt = $this->db->prepare("INSERT INTO permissoes (usuario_id, dashboard, produtos, movimentacoes, clientes, fornecedores, alertas, administracao) VALUES (?, 1, 1, 1, 1, 0, 1, 0)");
            $stmt->execute([$vendedorId]);
        }

        // Cria categorias padrão se não existirem
        $stmt = $this->db->query("SELECT COUNT(*) FROM categorias");
        if ($stmt->fetchColumn() == 0) {
            $this->db->exec("INSERT INTO categorias (nome, descricao) VALUES
                ('Eletrônicos', 'Produtos eletrônicos em geral'),
                ('Alimentos', 'Produtos alimentícios'),
                ('Bebidas', 'Bebidas diversas'),
                ('Limpeza', 'Produtos de limpeza'),
                ('Higiene', 'Produtos de higiene pessoal')
            ");
        }
    }

    public function getConnection() {
        return $this->db;
    }
}
?>
