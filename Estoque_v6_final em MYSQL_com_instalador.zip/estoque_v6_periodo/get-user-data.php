<?php
// Configurar timezone para horário de Brasília (GMT-3)
date_default_timezone_set('America/Sao_Paulo');

session_start();
header('Content-Type: application/json');

if (isset($_SESSION['usuario_id'])) {
    echo json_encode([
        'logado' => true,
        'usuario' => [
            'id' => $_SESSION['usuario_id'],
            'nome' => $_SESSION['usuario_nome'],
            'username' => $_SESSION['usuario_username'],
            'tipo' => $_SESSION['usuario_tipo'],
            'nivel_admin' => $_SESSION['nivel_admin'] ?? null
        ],
        'permissoes' => $_SESSION['permissoes']
    ]);
} else {
    echo json_encode(['logado' => false]);
}
?>
