<?php
// Configurar timezone para horário de Brasília (GMT-3)
date_default_timezone_set('America/Sao_Paulo');

session_start();

// SEMPRE verificar se usuário está logado - BLOQUEAR acesso direto
if (!isset($_SESSION['usuario_id']) || empty($_SESSION['usuario_id'])) {
    // Redirecionar IMEDIATAMENTE para login
    header('Location: login.php');
    exit();
}

// Verificar se a sessão ainda é válida
if (!isset($_SESSION['usuario_nome']) || !isset($_SESSION['usuario_tipo'])) {
    session_destroy();
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Controle de Estoque</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0/dist/chartjs-plugin-datalabels.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/quagga@0.12.1/dist/quagga.min.js"></script>
    <script src="masks.js"></script>
    <script src="validacoes.js"></script>
</head>
<body>
    <!-- Menu Lateral -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h2><i class="fas fa-warehouse"></i> Estoque Pro</h2>
            <div style="font-size: 12px; color: #ccc; margin-top: 5px;">
                <i class="fas fa-user"></i> <span id="usuarioNome">-</span>
            </div>
        </div>
        <nav class="sidebar-nav">
            <a href="#" class="nav-link active" onclick="showSection('dashboard')" data-permissao="dashboard">
                <i class="fas fa-chart-line"></i> Dashboard
                <span class="atalho-badge">F1</span>
            </a>
            <a href="#" class="nav-link" onclick="showSection('produtos')" data-permissao="produtos">
                <i class="fas fa-box"></i> Produtos
                <span class="atalho-badge">F2</span>
            </a>
            <a href="#" class="nav-link" onclick="showSection('movimentacoes')" data-permissao="movimentacoes">
                <i class="fas fa-exchange-alt"></i> Movimentações
                <span class="atalho-badge">F3</span>
            </a>
            <a href="#" class="nav-link" onclick="showSection('clientes')" data-permissao="clientes">
                <i class="fas fa-users"></i> Clientes
                <span class="atalho-badge">F4</span>
            </a>
            <a href="#" class="nav-link" onclick="showSection('fornecedores')" data-permissao="fornecedores">
                <i class="fas fa-truck"></i> Fornecedores
                <span class="atalho-badge">F5</span>
            </a>
            <a href="#" class="nav-link" onclick="showSection('alertas')" data-permissao="alertas">
                <i class="fas fa-exclamation-triangle"></i> Alertas
                <span class="badge" id="badgeAlertas">0</span>
            </a>
            <a href="#" class="nav-link" onclick="showSection('administracao')" data-permissao="administracao" id="menuAdmin" style="display: none;">
                <i class="fas fa-cog"></i> Administração
                <span class="atalho-badge">F7</span>
            </a>
            <a href="#" class="nav-link" onclick="logout()" style="margin-top: auto;">
                <i class="fas fa-sign-out-alt"></i> Sair
                <span class="atalho-badge">F12</span>
            </a>
        </nav>
    </div>

    <!-- Overlay mobile para fechar sidebar -->
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>

    <!-- Conteúdo Principal -->
    <div class="main-content">
        <div class="topbar">
            <button class="menu-toggle" onclick="toggleSidebar()">
                <i class="fas fa-bars"></i>
            </button>
            <h1 id="pageTitle">Dashboard</h1>
        </div>

        <!-- Seção Dashboard -->
        <div id="dashboard" class="section active">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                        <i class="fas fa-box"></i>
                    </div>
                    <div class="stat-info">
                        <h3 id="totalProdutos">0</h3>
                        <p>Total de Produtos</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                        <i class="fas fa-arrow-down"></i>
                    </div>
                    <div class="stat-info">
                        <h3 id="totalEntradas">0</h3>
                        <p>Entradas</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                        <i class="fas fa-arrow-up"></i>
                    </div>
                    <div class="stat-info">
                        <h3 id="totalSaidas">0</h3>
                        <p>Saídas</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="stat-info">
                        <h3 id="produtosBaixos">0</h3>
                        <p>Estoque Baixo</p>
                    </div>
                </div>
            </div>

            <div class="charts-grid">
                <div class="chart-card">
                    <h3>Movimentações do Mês</h3>
                    <canvas id="chartMovimentacoes"></canvas>
                </div>
                <div class="chart-card">
                    <h3>Top 5 Produtos</h3>
                    <canvas id="chartTopProdutos"></canvas>
                </div>
            </div>
        </div>

        <!-- Outras seções continuam aqui -->
        <?php include 'sections/produtos.php'; ?>
        <?php include 'sections/movimentacoes.php'; ?>
        <?php include 'sections/clientes.php'; ?>
        <?php include 'sections/fornecedores.php'; ?>
        <?php include 'sections/alertas.php'; ?>
        <?php include 'sections/administracao.php'; ?>
    </div>

    <!-- Botão Flutuante de Ajuda/Atalhos -->
    <button onclick="abrirAjudaAtalhos()" class="btn-ajuda-flutuante" title="Atalhos de Teclado (F11)">
        <i class="fas fa-keyboard"></i>
    </button>

    <!-- A ORDEM É CRÍTICA: app.js PRIMEIRO, depois auth-app.js, depois keyboard-shortcuts.js -->
    <script src="app.js?v=<?php echo time(); ?>"></script>
    <script src="auth-app.js?v=<?php echo time(); ?>"></script>
    <script src="keyboard-shortcuts.js?v=<?php echo time(); ?>"></script>
    <script>
        // Inicializar máscaras e validações quando o documento carregar
        document.addEventListener('DOMContentLoaded', function() {
            inicializarMascaras();
            inicializarValidacoes();
        });
    </script>
</body>
</html>
