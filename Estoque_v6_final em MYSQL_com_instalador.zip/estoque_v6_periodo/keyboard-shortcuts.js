// ================================================================================
// SISTEMA DE ATALHOS DE TECLADO COMPLETO - PDV PROFISSIONAL
// TODOS OS BOTÕES E AÇÕES TÊM ATALHOS
// ================================================================================

// Mapa COMPLETO de atalhos do sistema
const ATALHOS = {
    // ========== NAVEGAÇÃO ENTRE SEÇÕES ==========
    'F1': { acao: () => showSection('dashboard'), descricao: 'Dashboard', secao: 'Navegação' },
    'F2': { acao: () => showSection('produtos'), descricao: 'Produtos', secao: 'Navegação' },
    'F3': { acao: () => showSection('movimentacoes'), descricao: 'Movimentações', secao: 'Navegação' },
    'F4': { acao: () => showSection('clientes'), descricao: 'Clientes', secao: 'Navegação' },
    'F5': { acao: () => showSection('fornecedores'), descricao: 'Fornecedores', secao: 'Navegação' },
    'F6': { acao: () => showSection('relatorios'), descricao: 'Relatórios', secao: 'Navegação' },
    'F7': { acao: () => showSection('administracao'), descricao: 'Administração', secao: 'Navegação' },

    // ========== AÇÕES PRINCIPAIS ==========
    'F8': { acao: () => abrirNovoRegistro(), descricao: 'Novo Registro', secao: 'Ações Rápidas' },
    'F9': { acao: () => abrirBusca(), descricao: 'Buscar/Filtrar', secao: 'Ações Rápidas' },
    'F10': { acao: () => executarAcaoF10(), descricao: 'Leitor de Barras/Atualizar', secao: 'Ações Rápidas' },
    'F11': { acao: () => abrirAjudaAtalhos(), descricao: 'Ajuda/Atalhos', secao: 'Ajuda' },
    'F12': { acao: () => sair(), descricao: 'Sair do Sistema', secao: 'Sistema' },

    // ========== FORMULÁRIOS - SALVAR E CANCELAR ==========
    'Ctrl+S': { acao: (e) => salvarFormularioAtual(e), descricao: 'Salvar', secao: 'Formulários', badge: 'Salvar' },
    'Ctrl+Enter': { acao: () => salvarFormularioAtual({ preventDefault: () => {} }), descricao: 'Salvar (alternativo)', secao: 'Formulários' },
    'Escape': { acao: () => cancelarOuFechar(), descricao: 'Cancelar/Fechar', secao: 'Formulários', badge: 'Cancelar' },
    'Ctrl+Q': { acao: () => cancelarOuFechar(), descricao: 'Cancelar (alternativo)', secao: 'Formulários' },

    // ========== CRIAR NOVOS REGISTROS ==========
    'Ctrl+Shift+P': { acao: (e) => { e.preventDefault(); abrirModalProduto(); }, descricao: 'Novo Produto', secao: 'Criar Novo', badge: 'Novo' },
    'Ctrl+Shift+M': { acao: (e) => { e.preventDefault(); abrirModalMovimentacao(); }, descricao: 'Nova Movimentação', secao: 'Criar Novo' },
    'Ctrl+Shift+C': { acao: (e) => { e.preventDefault(); abrirModalCliente(); }, descricao: 'Novo Cliente', secao: 'Criar Novo' },
    'Ctrl+Shift+F': { acao: (e) => { e.preventDefault(); abrirModalFornecedor(); }, descricao: 'Novo Fornecedor', secao: 'Criar Novo' },
    'Ctrl+Shift+U': { acao: (e) => { e.preventDefault(); abrirModalUsuario(); }, descricao: 'Novo Usuário', secao: 'Criar Novo' },

    // ========== BUSCA E FILTROS ==========
    'Ctrl+F': { acao: (e) => focarBusca(e), descricao: 'Focar na Busca', secao: 'Busca', badge: 'Buscar' },
    'Ctrl+L': { acao: (e) => { e.preventDefault(); limparFiltros(); }, descricao: 'Limpar Filtros', secao: 'Busca' },

    // ========== AÇÕES DE EDIÇÃO E EXCLUSÃO ==========
    'Ctrl+E': { acao: (e) => { e.preventDefault(); editarPrimeiroItem(); }, descricao: 'Editar Primeiro Item', secao: 'Edição', badge: 'Editar' },
    'Delete': { acao: () => excluirItemSelecionado(), descricao: 'Excluir Item Selecionado', secao: 'Edição', badge: 'Excluir' },
    'Ctrl+Delete': { acao: () => excluirItemSelecionado(), descricao: 'Excluir (alternativo)', secao: 'Edição' },

    // ========== NAVEGAÇÃO NA TABELA ==========
    'ArrowDown': { acao: () => navegarTabela('down'), descricao: 'Próximo Item da Tabela', secao: 'Navegação Tabela' },
    'ArrowUp': { acao: () => navegarTabela('up'), descricao: 'Item Anterior da Tabela', secao: 'Navegação Tabela' },
    'Enter': { acao: () => abrirItemSelecionado(), descricao: 'Abrir Item Selecionado', secao: 'Navegação Tabela' },

    // ========== ATALHOS ESPECÍFICOS POR SEÇÃO ==========

    // Dashboard
    'Alt+D': { acao: () => { showSection('dashboard'); carregarDashboard(); }, descricao: 'Atualizar Dashboard', secao: 'Dashboard' },

    // Produtos
    'Alt+B': { acao: () => { showSection('produtos'); setTimeout(() => abrirLeitorBarras(), 100); }, descricao: 'Leitor de Código de Barras', secao: 'Produtos', badge: 'Código' },

    // Movimentações
    'Alt+F': { acao: () => carregarMovimentacoes(), descricao: 'Filtrar Movimentações', secao: 'Movimentações' },
    'Alt+N': { acao: () => abrirModalMovimentacao(), descricao: 'Nova Movimentação', secao: 'Movimentações' },
    'Alt+E': { acao: () => criarMovimentacao('entrada'), descricao: 'Nova Entrada', secao: 'Movimentações' },
    'Alt+S': { acao: () => criarMovimentacao('saida'), descricao: 'Nova Saída', secao: 'Movimentações' },

    // Alertas e Notificações
    'Alt+1': { acao: () => mostrarEstoqueBaixo(), descricao: 'Estoque Baixo', secao: 'Alertas' },
    'Alt+2': { acao: () => carregarDashboard(), descricao: 'Recarregar Dashboard', secao: 'Alertas' },
    'Alt+3': { acao: () => atualizarSecaoAtual(), descricao: 'Atualizar Página Atual', secao: 'Alertas', badge: 'Atualizar' },

    // ========== NAVEGAÇÃO ENTRE CAMPOS ==========
    'Tab': { acao: null, descricao: 'Próximo Campo', secao: 'Navegação Form' }, // Nativo do navegador
    'Shift+Tab': { acao: null, descricao: 'Campo Anterior', secao: 'Navegação Form' }, // Nativo do navegador

    // ========== ATALHOS DE SISTEMA ==========
    'Ctrl+R': { acao: (e) => { e.preventDefault(); atualizarSecaoAtual(); }, descricao: 'Recarregar Dados', secao: 'Sistema' },
    'Ctrl+H': { acao: (e) => { e.preventDefault(); abrirAjudaAtalhos(); }, descricao: 'Ajuda', secao: 'Sistema' },
};

// Variáveis de controle
let itemTabelaSelecionado = null;
let linhaTabelaSelecionada = null;

// ========== LISTENER PRINCIPAL DE TECLADO ==========
document.addEventListener('keydown', function(event) {
    // Ignorar atalhos se o usuário estiver digitando em um campo de texto
    const elementoAtivo = document.activeElement;
    const estaDigitando = elementoAtivo && (
        elementoAtivo.tagName === 'INPUT' ||
        elementoAtivo.tagName === 'TEXTAREA' ||
        elementoAtivo.tagName === 'SELECT' ||
        elementoAtivo.isContentEditable
    );

    // Montar a combinação de teclas
    let atalho = '';
    if (event.ctrlKey) atalho += 'Ctrl+';
    if (event.altKey) atalho += 'Alt+';
    if (event.shiftKey) atalho += 'Shift+';
    atalho += event.key;

    // Verificar se existe o atalho
    if (ATALHOS[atalho]) {
        // Permitir alguns atalhos mesmo digitando
        const permitidosAoDigitar = [
            'Ctrl+S', 'Ctrl+Enter', 'Escape', 'F11', 'Ctrl+H',
            'Ctrl+Shift+P', 'Ctrl+Shift+M', 'Ctrl+Shift+C', 'Ctrl+Shift+F', 'Ctrl+Shift+U'
        ];

        // Não permitir navegação com setas em campos de texto
        const bloqueadosAoDigitar = ['ArrowDown', 'ArrowUp', 'Enter', 'Delete'];

        if (estaDigitando) {
            if (!permitidosAoDigitar.includes(atalho)) {
                return; // Não executar atalho se estiver digitando
            }
        }

        // Prevenir ação padrão para atalhos específicos
        if (!['Tab', 'Shift+Tab'].includes(atalho)) {
            event.preventDefault();
            event.stopPropagation();
        }

        // Executar ação do atalho
        try {
            if (ATALHOS[atalho].acao) {
                ATALHOS[atalho].acao(event);

                // Mostrar feedback visual
                mostrarFeedbackAtalho(atalho, ATALHOS[atalho].descricao);
            }
        } catch (error) {
            console.error('Erro ao executar atalho:', atalho, error);
        }
    }
});

// ========== FUNÇÕES DE FEEDBACK VISUAL ==========
function mostrarFeedbackAtalho(tecla, descricao) {
    const feedbackAnterior = document.getElementById('atalho-feedback');
    if (feedbackAnterior) feedbackAnterior.remove();

    const feedback = document.createElement('div');
    feedback.id = 'atalho-feedback';
    feedback.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
            <kbd style="background: #fff; padding: 5px 10px; border-radius: 4px; font-weight: bold; box-shadow: 0 2px 4px rgba(0,0,0,0.2); color: #333;">${tecla}</kbd>
            <span>${descricao}</span>
        </div>
    `;
    feedback.style.cssText = `
        position: fixed; top: 20px; right: 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white; padding: 15px 20px; border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3); z-index: 10000;
        animation: slideInRight 0.3s ease; font-size: 14px;
    `;

    document.body.appendChild(feedback);
    setTimeout(() => {
        feedback.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => feedback.remove(), 300);
    }, 2000);
}

// ========== FUNÇÕES DE AÇÃO ==========

// Abrir novo registro baseado na seção atual
function abrirNovoRegistro() {
    const secao = getSecaoAtual();
    switch(secao) {
        case 'produtos': abrirModalProduto(); break;
        case 'movimentacoes': abrirModalMovimentacao(); break;
        case 'clientes': if (typeof abrirModalCliente === 'function') abrirModalCliente(); break;
        case 'fornecedores': if (typeof abrirModalFornecedor === 'function') abrirModalFornecedor(); break;
        case 'administracao': if (typeof abrirModalUsuario === 'function') abrirModalUsuario(); break;
        default: alert('Nenhuma ação de novo registro disponível nesta seção');
    }
}

// Focar no campo de busca da seção atual
function focarBusca(e) {
    e.preventDefault();
    const secao = getSecaoAtual();
    let inputBusca = null;

    switch(secao) {
        case 'produtos': inputBusca = document.getElementById('searchProduto'); break;
        case 'clientes': inputBusca = document.getElementById('searchCliente'); break;
        case 'fornecedores': inputBusca = document.getElementById('searchFornecedor'); break;
    }

    if (inputBusca) {
        inputBusca.focus();
        inputBusca.select();
    }
}

function abrirBusca() {
    focarBusca({ preventDefault: () => {} });
}

// Executar ação F10 (leitor de barras em produtos, atualizar em outras seções)
function executarAcaoF10() {
    const secao = getSecaoAtual();
    if (secao === 'produtos') {
        abrirLeitorBarras();
    } else if (secao === 'movimentacoes') {
        carregarMovimentacoes();
    } else {
        atualizarSecaoAtual();
    }
}

// Salvar o formulário ativo
function salvarFormularioAtual(e) {
    e.preventDefault();
    const modalAtivo = document.querySelector('.modal.active');
    if (!modalAtivo) return;

    const form = modalAtivo.querySelector('form');
    if (form) {
        const submitButton = form.querySelector('button[type="submit"]');
        if (submitButton) {
            submitButton.click();
        } else {
            form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
        }
    }
}

// Cancelar ou fechar modal
function cancelarOuFechar() {
    const modais = document.querySelectorAll('.modal.active');
    modais.forEach(modal => {
        modal.classList.remove('active');
        const modalId = modal.id;

        if (modalId === 'modalProduto') fecharModal('modalProduto');
        else if (modalId === 'modalMovimentacao') fecharModal('modalMovimentacao');
        else if (modalId === 'modalCliente') fecharModal('modalCliente');
        else if (modalId === 'modalFornecedor') fecharModal('modalFornecedor');
        else if (modalId === 'modalCategoria') fecharModal('modalCategoria');
        else if (modalId === 'modalUsuario') fecharModal('modalUsuario');
        else if (modalId === 'modalBarcode') fecharLeitorBarras();
        else if (modalId === 'modalAjudaAtalhos') modal.remove();
    });
}

// Obter seção atual
function getSecaoAtual() {
    const secaoAtiva = document.querySelector('.section.active');
    return secaoAtiva ? secaoAtiva.id : 'dashboard';
}

// Atualizar seção atual
function atualizarSecaoAtual() {
    const secao = getSecaoAtual();
    switch(secao) {
        case 'dashboard': carregarDashboard(); break;
        case 'produtos': carregarProdutos(); break;
        case 'movimentacoes': carregarMovimentacoes(); break;
        case 'clientes': if (typeof carregarClientes === 'function') carregarClientes(); break;
        case 'fornecedores': if (typeof carregarFornecedores === 'function') carregarFornecedores(); break;
    }
    mostrarFeedbackAtalho('Alt+3', 'Página Atualizada');
}

// Mostrar alertas de estoque baixo
function mostrarEstoqueBaixo() {
    showSection('dashboard');
    setTimeout(() => {
        const alertasEstoque = document.getElementById('alertasEstoque');
        if (alertasEstoque) {
            alertasEstoque.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 300);
}

// Sair do sistema
function sair() {
    if (confirm('Deseja realmente sair do sistema?')) {
        window.location.href = 'logout.php';
    }
}

// Limpar filtros
function limparFiltros() {
    const secao = getSecaoAtual();
    if (secao === 'produtos') {
        const searchInput = document.getElementById('searchProduto');
        if (searchInput) {
            searchInput.value = '';
            filtrarProdutos();
        }
    } else if (secao === 'movimentacoes') {
        const dataInicio = document.getElementById('movDataInicio');
        const dataFim = document.getElementById('movDataFim');
        if (dataInicio) dataInicio.value = '';
        if (dataFim) dataFim.value = '';
        carregarMovimentacoes();
    }
}

// Criar movimentação específica
function criarMovimentacao(tipo) {
    showSection('movimentacoes');
    setTimeout(() => {
        abrirModalMovimentacao();
        setTimeout(() => {
            const tipoSelect = document.getElementById('movTipo');
            if (tipoSelect) {
                tipoSelect.value = tipo;
                alterarTipoMovimentacao();
            }
        }, 100);
    }, 100);
}

// Editar primeiro item da lista
function editarPrimeiroItem() {
    const secao = getSecaoAtual();
    let primeiroItem = null;

    if (secao === 'produtos') {
        primeiroItem = document.querySelector('#listaProdutos tr[data-id]');
        if (primeiroItem) {
            const id = primeiroItem.getAttribute('data-id');
            editarProduto(id);
        }
    } else if (secao === 'clientes') {
        primeiroItem = document.querySelector('#listaClientes tr[data-id]');
        if (primeiroItem && typeof editarCliente === 'function') {
            const id = primeiroItem.getAttribute('data-id');
            editarCliente(id);
        }
    } else if (secao === 'fornecedores') {
        primeiroItem = document.querySelector('#listaFornecedores tr[data-id]');
        if (primeiroItem && typeof editarFornecedor === 'function') {
            const id = primeiroItem.getAttribute('data-id');
            editarFornecedor(id);
        }
    }
}

// Excluir item selecionado
function excluirItemSelecionado() {
    if (!linhaTabelaSelecionada) {
        alert('Selecione um item primeiro usando as setas ↑ ↓');
        return;
    }

    const id = linhaTabelaSelecionada.getAttribute('data-id');
    if (!id) return;

    const secao = getSecaoAtual();

    if (secao === 'produtos' && typeof excluirProduto === 'function') {
        excluirProduto(id);
    } else if (secao === 'clientes' && typeof excluirCliente === 'function') {
        excluirCliente(id);
    } else if (secao === 'fornecedores' && typeof excluirFornecedor === 'function') {
        excluirFornecedor(id);
    }
}

// Navegar na tabela com setas
function navegarTabela(direcao) {
    const secao = getSecaoAtual();
    let tbody = null;

    if (secao === 'produtos') tbody = document.getElementById('listaProdutos');
    else if (secao === 'clientes') tbody = document.getElementById('listaClientes');
    else if (secao === 'fornecedores') tbody = document.getElementById('listaFornecedores');
    else if (secao === 'movimentacoes') tbody = document.getElementById('listaMovimentacoes');

    if (!tbody) return;

    const linhas = Array.from(tbody.querySelectorAll('tr[data-id]'));
    if (linhas.length === 0) return;

    // Remover seleção anterior
    if (linhaTabelaSelecionada) {
        linhaTabelaSelecionada.style.backgroundColor = '';
    }

    // Determinar nova linha
    if (!linhaTabelaSelecionada) {
        linhaTabelaSelecionada = linhas[0];
    } else {
        const indexAtual = linhas.indexOf(linhaTabelaSelecionada);
        if (direcao === 'down' && indexAtual < linhas.length - 1) {
            linhaTabelaSelecionada = linhas[indexAtual + 1];
        } else if (direcao === 'up' && indexAtual > 0) {
            linhaTabelaSelecionada = linhas[indexAtual - 1];
        }
    }

    // Aplicar seleção
    linhaTabelaSelecionada.style.backgroundColor = '#e3f2fd';
    linhaTabelaSelecionada.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// Abrir item selecionado
function abrirItemSelecionado() {
    if (!linhaTabelaSelecionada) return;

    const id = linhaTabelaSelecionada.getAttribute('data-id');
    if (!id) return;

    const secao = getSecaoAtual();

    if (secao === 'produtos' && typeof editarProduto === 'function') {
        editarProduto(id);
    } else if (secao === 'clientes' && typeof editarCliente === 'function') {
        editarCliente(id);
    } else if (secao === 'fornecedores' && typeof editarFornecedor === 'function') {
        editarFornecedor(id);
    }
}

// ========== MODAL DE AJUDA ==========
function abrirAjudaAtalhos() {
    const modalAnterior = document.getElementById('modalAjudaAtalhos');
    if (modalAnterior) modalAnterior.remove();

    const atalhosPorSecao = {};
    for (const [tecla, config] of Object.entries(ATALHOS)) {
        const secao = config.secao;
        if (!atalhosPorSecao[secao]) atalhosPorSecao[secao] = [];
        atalhosPorSecao[secao].push({ tecla, descricao: config.descricao });
    }

    let htmlAtalhos = '';
    for (const [secao, atalhos] of Object.entries(atalhosPorSecao)) {
        htmlAtalhos += `
            <div style="margin-bottom: 25px;">
                <h4 style="color: #667eea; margin-bottom: 10px; font-size: 16px; border-bottom: 2px solid #667eea; padding-bottom: 5px;">${secao}</h4>
                <div style="display: grid; grid-template-columns: 180px 1fr; gap: 10px;">
        `;

        atalhos.forEach(({ tecla, descricao }) => {
            htmlAtalhos += `
                <kbd style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 8px 12px; border-radius: 4px; font-weight: bold; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.2);">${tecla}</kbd>
                <span style="display: flex; align-items: center; color: #333;">${descricao}</span>
            `;
        });

        htmlAtalhos += `</div></div>`;
    }

    const modal = document.createElement('div');
    modal.id = 'modalAjudaAtalhos';
    modal.className = 'modal active';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 900px; max-height: 90vh; overflow-y: auto;">
            <div class="modal-header">
                <h3>⌨️ Atalhos de Teclado - Sistema PDV Completo</h3>
                <span class="close" onclick="document.getElementById('modalAjudaAtalhos').remove()">&times;</span>
            </div>
            <div style="padding: 20px;">
                <p style="background: #f0f4ff; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #667eea;">
                    <strong>💡 Dica:</strong> TODOS os botões do sistema têm atalhos de teclado! Use-os para trabalhar até 10x mais rápido! 🚀
                </p>
                ${htmlAtalhos}
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="document.getElementById('modalAjudaAtalhos').remove()">Fechar (ESC)</button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);
}

// ========== ESTILOS ==========
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOutRight {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    kbd {
        font-family: 'Courier New', monospace;
        font-size: 13px;
        display: inline-block;
    }
`;
document.head.appendChild(style);

// ========== ADICIONAR BADGES NOS BOTÕES ==========
function adicionarBadgesAtalhos() {
    setTimeout(() => {
        // Mapear badges para botões
        const badges = {
            'Novo': 'F8',
            'Buscar': 'F9 / Ctrl+F',
            'Código': 'F10',
            'Salvar': 'Ctrl+S',
            'Cancelar': 'ESC',
            'Editar': 'Ctrl+E',
            'Excluir': 'Del',
            'Atualizar': 'Alt+3'
        };

        document.querySelectorAll('.btn').forEach(btn => {
            const texto = btn.textContent.trim();

            // Verificar cada badge
            for (const [palavra, atalho] of Object.entries(badges)) {
                if (texto.includes(palavra) && !btn.querySelector('kbd')) {
                    const kbd = document.createElement('kbd');
                    kbd.textContent = atalho;
                    kbd.style.cssText = 'font-size: 10px; margin-left: 8px; padding: 2px 6px; background: rgba(255,255,255,0.3); border-radius: 3px;';
                    btn.appendChild(document.createTextNode(' '));
                    btn.appendChild(kbd);
                    break;
                }
            }
        });
    }, 1000);
}

// Inicializar badges
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', adicionarBadgesAtalhos);
} else {
    adicionarBadgesAtalhos();
}

// Re-adicionar badges quando seções mudarem
const observer = new MutationObserver(adicionarBadgesAtalhos);
observer.observe(document.body, { childList: true, subtree: true });

// Exportar funções
window.abrirAjudaAtalhos = abrirAjudaAtalhos;
window.ATALHOS = ATALHOS;

console.log('✅ Sistema COMPLETO de Atalhos PDV carregado!');
console.log('💡 Pressione F11 para ver TODOS os atalhos disponíveis');
console.log('🚀 TODOS os botões agora têm atalhos de teclado!');
