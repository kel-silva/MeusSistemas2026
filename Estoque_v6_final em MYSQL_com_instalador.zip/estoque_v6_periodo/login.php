<?php
// Configurar timezone para horário de Brasília (GMT-3)
date_default_timezone_set('America/Sao_Paulo');

session_start();

// Se já estiver logado, redirecionar para o sistema
if (isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

$erro = '';

// Processar login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'database.php';

    $username = $_POST['username'] ?? '';
    $senha = $_POST['senha'] ?? '';

    if (!empty($username) && !empty($senha)) {
        $db = new Database();
        $conn = $db->getConnection();

        // Buscar usuário por username (não email)
        $stmt = $conn->prepare("SELECT u.*, p.* FROM usuarios u
                               LEFT JOIN permissoes p ON u.id = p.usuario_id
                               WHERE u.username = ? AND u.ativo = 1");
        $stmt->execute([$username]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($usuario && password_verify($senha, $usuario['senha'])) {
            // Login bem-sucedido
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['usuario_nome'] = $usuario['nome'];
            $_SESSION['usuario_username'] = $usuario['username'];
            $_SESSION['usuario_tipo'] = $usuario['tipo'];
            $_SESSION['nivel_admin'] = $usuario['nivel_admin'] ?? null;
            $_SESSION['permissoes'] = [
                'dashboard' => $usuario['dashboard'] ?? 1,
                'produtos' => $usuario['produtos'] ?? 1,
                'movimentacoes' => $usuario['movimentacoes'] ?? 1,
                'clientes' => $usuario['clientes'] ?? 1,
                'fornecedores' => $usuario['fornecedores'] ?? 1,
                'alertas' => $usuario['alertas'] ?? 1,
                'administracao' => $usuario['administracao'] ?? 0
            ];

            header('Location: index.php');
            exit;
        } else {
            $erro = 'Usuário ou senha inválidos';
        }
    } else {
        $erro = 'Preencha todos os campos';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema de Controle de Estoque</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            padding: 40px;
            width: 100%;
            max-width: 420px;
        }

        .login-header {
            text-align: center;
            margin-bottom: 35px;
        }

        .login-header h1 {
            color: #667eea;
            font-size: 28px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .login-header p {
            color: #666;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            color: #333;
            font-weight: 500;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .input-group {
            position: relative;
        }

        .input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }

        .input {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 2px solid #e1e1e1;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.3s;
        }

        .input:focus {
            outline: none;
            border-color: #667eea;
        }

        .btn-login {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
        }

        .btn-login:hover {
            transform: translateY(-2px);
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .error-message {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: center;
        }

        .footer-text {
            text-align: center;
            margin-top: 25px;
            color: #666;
            font-size: 13px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1><i class="fas fa-warehouse"></i> Estoque Pro</h1>
            <p>Faça login para acessar o sistema</p>
        </div>

        <?php if ($erro): ?>
            <div class="error-message"><?php echo htmlspecialchars($erro); ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Usuário</label>
                <div class="input-group">
                    <i class="fas fa-user"></i>
                    <input type="text" name="username" class="input" placeholder="Digite seu usuário" required autofocus>
                </div>
            </div>

            <div class="form-group">
                <label>Senha</label>
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="senha" class="input" placeholder="Digite sua senha" required>
                </div>
            </div>

            <button type="submit" class="btn-login">
                <i class="fas fa-sign-in-alt"></i> Entrar
            </button>
        </form>

        <div class="footer-text">
            © 2024 Estoque Pro - Sistema de Controle de Estoque
        </div>
    </div>
</body>
</html>
