// Máscaras para Telefone, CPF, CNPJ e CEP

// Função para aplicar máscara de telefone
function mascaraTelefone(valor) {
    valor = valor.replace(/\D/g, '');
    // Limitar a 11 dígitos
    if (valor.length > 11) {
        valor = valor.substring(0, 11);
    }
    if (valor.length <= 10) {
        // Telefone fixo: (99) 9999-9999
        valor = valor.replace(/^(\d{2})(\d)/g, '($1) $2');
        valor = valor.replace(/(\d)(\d{4})$/, '$1-$2');
    } else {
        // Celular: (99) 99999-9999
        valor = valor.replace(/^(\d{2})(\d)/g, '($1) $2');
        valor = valor.replace(/(\d)(\d{4})$/, '$1-$2');
    }
    return valor;
}

// Função para aplicar máscara de CPF
function mascaraCPF(valor) {
    valor = valor.replace(/\D/g, '');
    // Limitar a 11 dígitos
    if (valor.length > 11) {
        valor = valor.substring(0, 11);
    }
    valor = valor.replace(/(\d{3})(\d)/, '$1.$2');
    valor = valor.replace(/(\d{3})(\d)/, '$1.$2');
    valor = valor.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    return valor;
}

// Função para aplicar máscara de CNPJ
function mascaraCNPJ(valor) {
    valor = valor.replace(/\D/g, '');
    // Limitar a 14 dígitos
    if (valor.length > 14) {
        valor = valor.substring(0, 14);
    }
    valor = valor.replace(/^(\d{2})(\d)/, '$1.$2');
    valor = valor.replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3');
    valor = valor.replace(/\.(\d{3})(\d)/, '.$1/$2');
    valor = valor.replace(/(\d{4})(\d)/, '$1-$2');
    return valor;
}

// Função para aplicar máscara de CEP
function mascaraCEP(valor) {
    valor = valor.replace(/\D/g, '');
    // Limitar a 8 dígitos
    if (valor.length > 8) {
        valor = valor.substring(0, 8);
    }
    valor = valor.replace(/^(\d{5})(\d)/, '$1-$2');
    return valor;
}

// Função inteligente para CPF/CNPJ (troca automática baseada no tamanho)
function mascaraCpfCnpj(valor) {
    valor = valor.replace(/\D/g, '');

    // Limitar a 14 dígitos (tamanho máximo de CNPJ)
    if (valor.length > 14) {
        valor = valor.substring(0, 14);
    }

    if (valor.length <= 11) {
        // CPF
        return mascaraCPF(valor);
    } else {
        // CNPJ
        return mascaraCNPJ(valor);
    }
}

// Função para aplicar máscara de código de barras EAN-13
function mascaraEAN13(valor) {
    valor = valor.replace(/\D/g, '');
    // EAN-13 permite apenas 13 dígitos
    if (valor.length > 13) {
        valor = valor.substring(0, 13);
    }
    return valor;
}

// Função para validar CPF
function validarCPF(cpf) {
    cpf = cpf.replace(/\D/g, '');
    if (cpf.length !== 11) return false;

    // Verificar se todos os dígitos são iguais
    if (/^(\d)\1{10}$/.test(cpf)) return false;

    // Validar dígitos verificadores
    let soma = 0;
    let resto;

    for (let i = 1; i <= 9; i++) {
        soma += parseInt(cpf.substring(i-1, i)) * (11 - i);
    }

    resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) resto = 0;
    if (resto !== parseInt(cpf.substring(9, 10))) return false;

    soma = 0;
    for (let i = 1; i <= 10; i++) {
        soma += parseInt(cpf.substring(i-1, i)) * (12 - i);
    }

    resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) resto = 0;
    if (resto !== parseInt(cpf.substring(10, 11))) return false;

    return true;
}

// Função para validar CNPJ
function validarCNPJ(cnpj) {
    cnpj = cnpj.replace(/\D/g, '');
    if (cnpj.length !== 14) return false;

    // Verificar se todos os dígitos são iguais
    if (/^(\d)\1{13}$/.test(cnpj)) return false;

    // Validar dígitos verificadores
    let tamanho = cnpj.length - 2;
    let numeros = cnpj.substring(0, tamanho);
    let digitos = cnpj.substring(tamanho);
    let soma = 0;
    let pos = tamanho - 7;

    for (let i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2) pos = 9;
    }

    let resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado !== parseInt(digitos.charAt(0))) return false;

    tamanho = tamanho + 1;
    numeros = cnpj.substring(0, tamanho);
    soma = 0;
    pos = tamanho - 7;

    for (let i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2) pos = 9;
    }

    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado !== parseInt(digitos.charAt(1))) return false;

    return true;
}

// Função para validar EAN-13 (código de barras)
function validarEAN13(ean) {
    ean = ean.replace(/\D/g, '');
    if (ean.length !== 13) return false;

    let soma = 0;
    for (let i = 0; i < 12; i++) {
        let digito = parseInt(ean.charAt(i));
        soma += (i % 2 === 0) ? digito : digito * 3;
    }

    let checkDigit = (10 - (soma % 10)) % 10;
    return checkDigit === parseInt(ean.charAt(12));
}

// Função para inicializar máscaras em elementos HTML
function inicializarMascaras() {
    // Telefone
    document.querySelectorAll('input[data-mask="telefone"]').forEach(input => {
        input.addEventListener('input', function(e) {
            e.target.value = mascaraTelefone(e.target.value);
        });
    });

    // CPF/CNPJ com troca automática
    document.querySelectorAll('input[data-mask="cpf-cnpj"]').forEach(input => {
        input.addEventListener('input', function(e) {
            e.target.value = mascaraCpfCnpj(e.target.value);
        });
    });

    // CPF apenas
    document.querySelectorAll('input[data-mask="cpf"]').forEach(input => {
        input.addEventListener('input', function(e) {
            e.target.value = mascaraCPF(e.target.value);
        });
    });

    // CNPJ apenas
    document.querySelectorAll('input[data-mask="cnpj"]').forEach(input => {
        input.addEventListener('input', function(e) {
            e.target.value = mascaraCNPJ(e.target.value);
        });
    });

    // CEP
    document.querySelectorAll('input[data-mask="cep"]').forEach(input => {
        input.addEventListener('input', function(e) {
            e.target.value = mascaraCEP(e.target.value);
        });
    });

    // EAN-13 (código de barras)
    document.querySelectorAll('input[data-mask="ean13"]').forEach(input => {
        input.addEventListener('input', function(e) {
            e.target.value = mascaraEAN13(e.target.value);
        });
    });
}

// Função para formatar valores em Real (R$) enquanto digita
function mascaraDinheiro(valor) {
    // Remove tudo que não é dígito
    valor = valor.replace(/\D/g, '');

    // Se estiver vazio, retorna vazio
    if (valor === '') return '';

    // Converte para número e formata
    let numero = parseFloat(valor) / 100;

    // Formata com separadores de milhares e decimais
    return numero.toLocaleString('pt-BR', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// Função para converter valor formatado de volta para número
function dinheiro_para_numero(valor) {
    if (!valor) return 0;
    // Remove tudo exceto números e vírgula
    valor = valor.toString().replace(/[^\d,]/g, '');
    // Substitui vírgula por ponto
    valor = valor.replace(',', '.');
    return parseFloat(valor) || 0;
}

// Função para formatar número para exibição em Real
function numero_para_dinheiro(valor) {
    if (!valor && valor !== 0) return '';
    return parseFloat(valor).toLocaleString('pt-BR', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// Função para aplicar máscara de dinheiro em um input
function aplicarMascaraDinheiro(input) {
    input.addEventListener('input', function(e) {
        let valor = e.target.value;
        e.target.value = mascaraDinheiro(valor);
    });

    // Ao sair do campo, garante formatação correta
    input.addEventListener('blur', function(e) {
        let valor = e.target.value;
        if (valor) {
            e.target.value = mascaraDinheiro(valor.replace(/\D/g, ''));
        }
    });
}

// Função para inicializar máscaras de dinheiro em elementos HTML
function inicializarMascarasDinheiro() {
    // Seleciona todos os inputs que devem ter máscara de dinheiro
    document.querySelectorAll('input[data-mask="dinheiro"]').forEach(input => {
        aplicarMascaraDinheiro(input);
    });
}

// Exportar funções para uso global
window.mascaraTelefone = mascaraTelefone;
window.mascaraCPF = mascaraCPF;
window.mascaraCNPJ = mascaraCNPJ;
window.mascaraCpfCnpj = mascaraCpfCnpj;
window.mascaraCEP = mascaraCEP;
window.mascaraEAN13 = mascaraEAN13;
window.validarCPF = validarCPF;
window.validarCNPJ = validarCNPJ;
window.validarEAN13 = validarEAN13;
window.inicializarMascaras = inicializarMascaras;
window.mascaraDinheiro = mascaraDinheiro;
window.dinheiro_para_numero = dinheiro_para_numero;
window.numero_para_dinheiro = numero_para_dinheiro;
window.aplicarMascaraDinheiro = aplicarMascaraDinheiro;
window.inicializarMascarasDinheiro = inicializarMascarasDinheiro;

// =============================================
// FUNÇÕES DE VALIDAÇÃO OnBlur (usadas nos formulários)
// =============================================

function marcarErro(inputId, mensagem) {
    var el = document.getElementById(inputId);
    if (!el) return;
    el.style.borderColor = '#dc3545';
    el.title = mensagem;
}

function removerErro(inputId) {
    var el = document.getElementById(inputId);
    if (!el) return;
    el.style.borderColor = '';
    el.title = '';
}

function validarCnpjOnBlur(inputId) {
    var el = document.getElementById(inputId);
    if (!el) return true;
    var valor = el.value.trim();
    if (!valor) { removerErro(inputId); return true; }
    if (!validarCNPJ(valor)) {
        marcarErro(inputId, 'CNPJ inválido');
        return false;
    }
    removerErro(inputId);
    return true;
}

function validarTelefoneOnBlur(inputId) {
    var el = document.getElementById(inputId);
    if (!el) return true;
    var valor = el.value.trim().replace(/\D/g, '');
    if (!valor) { removerErro(inputId); return true; }
    if (valor.length < 10 || valor.length > 11) {
        marcarErro(inputId, 'Telefone inválido. Use (00) 00000-0000');
        return false;
    }
    removerErro(inputId);
    return true;
}

function validarEmailOnBlur(inputId) {
    var el = document.getElementById(inputId);
    if (!el) return true;
    var valor = el.value.trim();
    if (!valor) { removerErro(inputId); return true; }
    var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!re.test(valor)) {
        marcarErro(inputId, 'E-mail inválido');
        return false;
    }
    removerErro(inputId);
    return true;
}

function validarCepOnBlur(inputId) {
    var el = document.getElementById(inputId);
    if (!el) return true;
    var valor = el.value.trim().replace(/\D/g, '');
    if (!valor) { removerErro(inputId); return true; }
    if (valor.length !== 8) {
        marcarErro(inputId, 'CEP inválido. Use 00000-000');
        return false;
    }
    removerErro(inputId);
    return true;
}

function validarCpfCnpjOnBlur(inputId) {
    var el = document.getElementById(inputId);
    if (!el) return true;
    var valor = el.value.trim();
    if (!valor) { removerErro(inputId); return true; }
    var apenas = valor.replace(/\D/g, '');
    var ok = false;
    if (apenas.length === 11) ok = validarCPF(valor);
    else if (apenas.length === 14) ok = validarCNPJ(valor);
    if (!ok) {
        marcarErro(inputId, 'CPF ou CNPJ inválido');
        return false;
    }
    removerErro(inputId);
    return true;
}

window.validarCnpjOnBlur = validarCnpjOnBlur;
window.validarTelefoneOnBlur = validarTelefoneOnBlur;
window.validarEmailOnBlur = validarEmailOnBlur;
window.validarCepOnBlur = validarCepOnBlur;
window.validarCpfCnpjOnBlur = validarCpfCnpjOnBlur;
