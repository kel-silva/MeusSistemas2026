<!-- Seção Administração -->
<div id="administracao" class="section">

    <!-- ── Painel de Limite de Usuários (visível apenas ao Super Admin id=1) ── -->
    <div id="painelLimiteUsuarios" style="display:none; margin-bottom:20px;">
        <div style="background:#fff; border:1px solid #e0e0e0; border-radius:10px; padding:18px 22px; box-shadow:0 2px 8px rgba(0,0,0,0.07); display:flex; align-items:center; gap:24px; flex-wrap:wrap;">
            <div style="display:flex; align-items:center; gap:10px;">
                <i class="fas fa-users-cog" style="color:#3498db; font-size:1.4rem;"></i>
                <div>
                    <div style="font-weight:700; font-size:1rem; color:#2c3e50;">Limite de Usuários Cadastrados</div>
                    <div id="limiteUsoTexto" style="font-size:0.82rem; color:#666; margin-top:2px;">carregando...</div>
                </div>
            </div>

            <!-- Checkbox Ilimitado -->
            <label style="display:flex; align-items:center; gap:7px; cursor:pointer; font-weight:600; color:#27ae60; font-size:0.95rem; user-select:none;">
                <input type="checkbox" id="chkIlimitado" onchange="toggleIlimitado()"
                       style="width:17px; height:17px; cursor:pointer; accent-color:#27ae60;">
                Ilimitado
            </label>

            <!-- Controle +/- -->
            <div id="controleNumerico" style="display:flex; align-items:center; gap:0;">
                <button onclick="alterarLimite(-1)"
                        style="width:36px; height:36px; border:1px solid #ddd; background:#f5f5f5; border-radius:6px 0 0 6px; font-size:1.2rem; font-weight:700; cursor:pointer; color:#555; transition:background .2s;"
                        onmouseover="this.style.background='#e0e0e0'" onmouseout="this.style.background='#f5f5f5'">−</button>
                <input type="number" id="limiteNumero" value="0" min="1"
                       style="width:64px; height:36px; border:1px solid #ddd; border-left:none; border-right:none; text-align:center; font-size:1rem; font-weight:700; color:#2c3e50; outline:none;"
                       onchange="salvarLimiteUsuarios()">
                <button onclick="alterarLimite(1)"
                        style="width:36px; height:36px; border:1px solid #ddd; background:#f5f5f5; border-radius:0 6px 6px 0; font-size:1.2rem; font-weight:700; cursor:pointer; color:#555; transition:background .2s;"
                        onmouseover="this.style.background='#e0e0e0'" onmouseout="this.style.background='#f5f5f5'">+</button>
            </div>

            <div id="limiteSalvoMsg" style="display:none; color:#27ae60; font-size:0.85rem; font-weight:600;">
                <i class="fas fa-check-circle"></i> Salvo!
            </div>
        </div>
    </div>
    <!-- ───────────────────────────────────────────────────────────────────── -->

    <div class="section-header">
        <div>
            <h2>Administração</h2>
            <p>Gerencie usuários, permissões e backup do sistema</p>
        </div>
        <div class="section-actions">
            <button class="btn btn-success" onclick="fazerBackup()" title="Fazer backup do banco de dados">
                <i class="fas fa-download"></i> Fazer Backup
            </button>
            <button class="btn btn-warning" onclick="abrirModalRestore()" title="Restaurar backup do banco de dados">
                <i class="fas fa-upload"></i> Restaurar Backup
            </button>
            <button class="btn btn-primary" onclick="abrirModalUsuario()">
                <i class="fas fa-plus"></i> Novo Usuário
            </button>
        </div>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Usuário</th>
                    <th>Tipo</th>
                    <th>Status</th>
                    <th>Permissões</th>
                    <th>Data Cadastro</th>
                    <th style="width: 120px;">Ações</th>
                </tr>
            </thead>
            <tbody id="listaUsuarios">
                <tr>
                    <td colspan="7" class="empty-state">
                        <i class="fas fa-users-cog"></i>
                        <p>Nenhum usuário cadastrado</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Usuário -->
<div id="modalUsuario" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalUsuarioTitulo">Novo Usuário</h3>
            <span class="close" onclick="fecharModal('modalUsuario')">&times;</span>
        </div>
        <form id="formUsuario" onsubmit="salvarUsuario(event)">
            <input type="hidden" id="usuarioId">

            <div class="form-group">
                <label>Nome *</label>
                <input type="text" id="usuarioNomeForm" class="form-control" required>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Usuário (Login) *</label>
                    <input type="text" id="usuarioUsername" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Senha</label>
                    <input type="password" id="usuarioSenha" class="form-control" placeholder="Deixe em branco para manter">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Tipo *</label>
                    <select id="usuarioTipo" class="form-control" required onchange="toggleNivelAdmin()">
                        <option value="usuario">Usuário</option>
                        <option value="admin">Administrador</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Status *</label>
                    <select id="usuarioAtivo" class="form-control" required>
                        <option value="1">Ativo</option>
                        <option value="0">Inativo</option>
                    </select>
                </div>
            </div>

            <div class="form-group" id="nivelAdminGroup" style="display: none;">
                <label>Nível de Administrador *</label>
                <select id="usuarioNivelAdmin" class="form-control">
                    <option value="">Selecione o nível</option>
                    <option value="master">🔴 Admin Master - Pode fazer backup E restaurar</option>
                    <option value="gerente">🟡 Admin Gerente - Pode fazer backup (sem restore)</option>
                </select>
                <small style="color: #666; display: block; margin-top: 5px;">
                    <i class="fas fa-info-circle"></i> <strong>Master:</strong> controle total (backup + restore). <strong>Gerente:</strong> apenas backup.
                </small>
            </div>

            <div class="form-group">
                <label><strong>Permissões</strong></label>
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-top: 10px;">
                    <label style="display: flex; align-items: center; gap: 8px;">
                        <input type="checkbox" id="permDashboard">
                        <span>Dashboard</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 8px;">
                        <input type="checkbox" id="permProdutos">
                        <span>Produtos</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 8px;">
                        <input type="checkbox" id="permMovimentacoes">
                        <span>Movimentações</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 8px;">
                        <input type="checkbox" id="permClientes">
                        <span>Clientes</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 8px;">
                        <input type="checkbox" id="permFornecedores">
                        <span>Fornecedores</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 8px;">
                        <input type="checkbox" id="permAlertas">
                        <span>Alertas</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 8px;">
                        <input type="checkbox" id="permAdministracao">
                        <span>Administração</span>
                    </label>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="fecharModal('modalUsuario')">Cancelar</button>
                <button type="submit" class="btn btn-primary">Salvar</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Restore Backup -->
<div id="modalRestore" class="modal">
    <div class="modal-content" style="max-width: 500px;">
        <div class="modal-header">
            <h3>Restaurar Backup</h3>
            <span class="close" onclick="fecharModal('modalRestore')">&times;</span>
        </div>
        <div style="padding: 20px;">
            <div class="alert alert-warning" style="margin-bottom: 20px; padding: 15px; background: #fff3cd; border-left: 4px solid #ffc107; color: #856404;">
                <i class="fas fa-exclamation-triangle"></i>
                <strong>ATENÇÃO!</strong>
                <p style="margin: 10px 0 0 0; font-size: 14px;">
                    Esta ação irá substituir TODOS os dados atuais do sistema pelo backup selecionado.
                    Um backup de segurança será criado automaticamente antes da restauração.
                </p>
            </div>

            <form id="formRestore" onsubmit="restaurarBackup(event)">
                <div class="form-group">
                    <label><strong>Selecione o arquivo de backup (.db)</strong></label>
                    <input type="file" id="arquivoBackup" class="form-control" accept=".db" required
                           style="padding: 10px; border: 2px dashed #ddd; background: #f9f9f9;">
                    <small style="color: #666; display: block; margin-top: 8px;">
                        <i class="fas fa-info-circle"></i> Selecione apenas arquivos de backup (.db) gerados por este sistema
                    </small>
                </div>

                <div class="modal-footer" style="margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modalRestore')">
                        <i class="fas fa-times"></i> Cancelar
                    </button>
                    <button type="submit" class="btn btn-warning">
                        <i class="fas fa-upload"></i> Restaurar Backup
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
