<!-- Seção Alertas -->
<div id="alertas" class="section">
    <div class="section-header">
        <div>
            <h2>Alertas de Estoque Baixo</h2>
            <p>Produtos que atingiram o estoque mínimo</p>
        </div>
    </div>

    <div id="listaAlertas" class="alertas-grid">
        <div class="empty-state">
            <i class="fas fa-check-circle"></i>
            <p>Carregando alertas...</p>
        </div>
    </div>
</div>
