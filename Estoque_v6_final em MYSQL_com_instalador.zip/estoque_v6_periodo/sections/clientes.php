<!-- Seção Clientes -->
<div id="clientes" class="section">
    <div class="section-header">
        <div>
            <h2>Clientes</h2>
            <p>Gerencie seus clientes</p>
        </div>
        <div class="section-actions">
            <input type="text" id="searchCliente" class="search-input" placeholder="Buscar cliente..." onkeyup="filtrarClientes()">
            <button class="btn btn-primary" onclick="abrirModalCliente()">
                <i class="fas fa-plus"></i> Novo Cliente
            </button>
        </div>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>CPF/CNPJ</th>
                    <th>Telefone</th>
                    <th>Email</th>
                    <th>Cidade</th>
                    <th style="width: 120px;">Ações</th>
                </tr>
            </thead>
            <tbody id="listaClientes">
                <tr>
                    <td colspan="6" class="empty-state">
                        <i class="fas fa-users"></i>
                        <p>Nenhum cliente cadastrado</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Cliente -->
<div id="modalCliente" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalClienteTitulo">Novo Cliente</h3>
            <span class="close" onclick="fecharModal('modalCliente')">&times;</span>
        </div>
        <form id="formCliente" onsubmit="salvarCliente(event)">
            <input type="hidden" id="clienteId">

            <div class="form-group">
                <label>Nome *</label>
                <input type="text" id="clienteNome" class="form-control" required>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>CPF/CNPJ</label>
                    <input type="text" id="clienteCpfCnpj" class="form-control" data-mask="cpf-cnpj" placeholder="000.000.000-00 ou 00.000.000/0000-00" maxlength="18" onblur="validarCpfCnpjOnBlur('clienteCpfCnpj')">
                </div>
                <div class="form-group">
                    <label>Telefone</label>
                    <input type="text" id="clienteTelefone" class="form-control" data-mask="telefone" placeholder="(00) 00000-0000" maxlength="15" onblur="validarTelefoneOnBlur('clienteTelefone')">
                </div>
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" id="clienteEmail" class="form-control" placeholder="exemplo@email.com" onblur="validarEmailOnBlur('clienteEmail')">
            </div>

            <div class="form-group">
                <label>Endereço</label>
                <input type="text" id="clienteEndereco" class="form-control" placeholder="Rua, número, complemento">
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Cidade</label>
                    <input type="text" id="clienteCidade" class="form-control" placeholder="Nome da cidade">
                </div>
                <div class="form-group">
                    <label>Estado</label>
                    <select id="clienteEstado" class="form-control">
                        <option value="">Selecione...</option>
                        <option value="AC">AC</option>
                        <option value="AL">AL</option>
                        <option value="AP">AP</option>
                        <option value="AM">AM</option>
                        <option value="BA">BA</option>
                        <option value="CE">CE</option>
                        <option value="DF">DF</option>
                        <option value="ES">ES</option>
                        <option value="GO">GO</option>
                        <option value="MA">MA</option>
                        <option value="MT">MT</option>
                        <option value="MS">MS</option>
                        <option value="MG">MG</option>
                        <option value="PA">PA</option>
                        <option value="PB">PB</option>
                        <option value="PR">PR</option>
                        <option value="PE">PE</option>
                        <option value="PI">PI</option>
                        <option value="RJ">RJ</option>
                        <option value="RN">RN</option>
                        <option value="RS">RS</option>
                        <option value="RO">RO</option>
                        <option value="RR">RR</option>
                        <option value="SC">SC</option>
                        <option value="SP">SP</option>
                        <option value="SE">SE</option>
                        <option value="TO">TO</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>CEP</label>
                    <input type="text" id="clienteCep" class="form-control" data-mask="cep" placeholder="00000-000" maxlength="9" onblur="validarCepOnBlur('clienteCep')">
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="fecharModal('modalCliente')">Cancelar</button>
                <button type="submit" class="btn btn-primary">Salvar</button>
            </div>
        </form>
    </div>
</div>
