<!-- Seção Fornecedores -->
<div id="fornecedores" class="section">
    <div class="section-header">
        <div>
            <h2>Fornecedores</h2>
            <p>Gerencie seus fornecedores</p>
        </div>
        <div class="section-actions">
            <input type="text" id="searchFornecedor" class="search-input" placeholder="Buscar fornecedor..." onkeyup="filtrarFornecedores()">
            <button class="btn btn-primary" onclick="abrirModalFornecedor()">
                <i class="fas fa-plus"></i> Novo Fornecedor
            </button>
        </div>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th style="width: 60px;">Foto</th>
                    <th>Nome</th>
                    <th>CNPJ</th>
                    <th>Telefone</th>
                    <th>Email</th>
                    <th>Contato</th>
                    <th style="width: 120px;">Ações</th>
                </tr>
            </thead>
            <tbody id="listaFornecedores">
                <tr>
                    <td colspan="6" class="empty-state">
                        <i class="fas fa-truck"></i>
                        <p>Nenhum fornecedor cadastrado</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Fornecedor -->
<div id="modalFornecedor" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalFornecedorTitulo">Novo Fornecedor</h3>
            <span class="close" onclick="fecharModal('modalFornecedor')">&times;</span>
        </div>
        <form id="formFornecedor" onsubmit="salvarFornecedor(event)">
            <input type="hidden" id="fornecedorId">
            <input type="hidden" id="fornecedorFotoPath">

            <div class="form-group">
                <label>Nome *</label>
                <input type="text" id="fornecedorNome" class="form-control" required>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>CNPJ</label>
                    <input type="text" id="fornecedorCnpj" class="form-control" data-mask="cnpj" placeholder="00.000.000/0000-00" maxlength="18" onblur="validarCnpjOnBlur('fornecedorCnpj')">
                </div>
                <div class="form-group">
                    <label>Telefone</label>
                    <input type="text" id="fornecedorTelefone" class="form-control" data-mask="telefone" placeholder="(00) 00000-0000" maxlength="15" onblur="validarTelefoneOnBlur('fornecedorTelefone')">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" id="fornecedorEmail" class="form-control" placeholder="exemplo@email.com" onblur="validarEmailOnBlur('fornecedorEmail')">
                </div>
                <div class="form-group">
                    <label>Contato Responsável</label>
                    <input type="text" id="fornecedorContato" class="form-control" placeholder="Nome do contato">
                </div>
            </div>

            <div class="form-group">
                <label>Endereço</label>
                <input type="text" id="fornecedorEndereco" class="form-control" placeholder="Rua, número, complemento">
            </div>

            <div class="form-group">
                <label>Foto do Fornecedor</label>
                <input type="file" id="fornecedorFoto" class="form-control" accept="image/*" onchange="previewFotoFornecedor(event)">
                <img id="previewFornecedorFoto" style="display: none; max-width: 200px; margin-top: 10px; border-radius: 8px;">
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Cidade</label>
                    <input type="text" id="fornecedorCidade" class="form-control" placeholder="Nome da cidade">
                </div>
                <div class="form-group">
                    <label>Estado</label>
                    <select id="fornecedorEstado" class="form-control">
                        <option value="">Selecione...</option>
                        <option value="AC">AC</option>
                        <option value="AL">AL</option>
                        <option value="AP">AP</option>
                        <option value="AM">AM</option>
                        <option value="BA">BA</option>
                        <option value="CE">CE</option>
                        <option value="DF">DF</option>
                        <option value="ES">ES</option>
                        <option value="GO">GO</option>
                        <option value="MA">MA</option>
                        <option value="MT">MT</option>
                        <option value="MS">MS</option>
                        <option value="MG">MG</option>
                        <option value="PA">PA</option>
                        <option value="PB">PB</option>
                        <option value="PR">PR</option>
                        <option value="PE">PE</option>
                        <option value="PI">PI</option>
                        <option value="RJ">RJ</option>
                        <option value="RN">RN</option>
                        <option value="RS">RS</option>
                        <option value="RO">RO</option>
                        <option value="RR">RR</option>
                        <option value="SC">SC</option>
                        <option value="SP">SP</option>
                        <option value="SE">SE</option>
                        <option value="TO">TO</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>CEP</label>
                    <input type="text" id="fornecedorCep" class="form-control" data-mask="cep" placeholder="00000-000" maxlength="9" onblur="validarCepOnBlur('fornecedorCep')">
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="fecharModal('modalFornecedor')">Cancelar</button>
                <button type="submit" class="btn btn-primary">Salvar</button>
            </div>
        </form>
    </div>
</div>
