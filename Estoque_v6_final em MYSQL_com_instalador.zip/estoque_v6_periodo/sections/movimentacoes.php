<!-- Seção Movimentações -->
<div id="movimentacoes" class="section">
    <div class="section-header">
        <div>
            <h2>Movimentações</h2>
            <p>Controle de entradas e saídas</p>
        </div>
        <div class="section-actions">
            <input type="date" id="movDataInicio" class="form-control">
            <input type="date" id="movDataFim" class="form-control">
            <button class="btn btn-secondary" onclick="carregarMovimentacoes()" accesskey="f" title="Atalho: Alt+F">
                <i class="fas fa-search"></i> <u>F</u>iltrar
            </button>
            <button class="btn btn-success" onclick="imprimirMovimentacoes()" title="Imprimir Relatório">
                <i class="fas fa-print"></i> Imprimir
            </button>
            <button class="btn btn-primary" onclick="abrirModalMovimentacao()" accesskey="n" title="Atalho: Alt+N">
                <i class="fas fa-plus"></i> <u>N</u>ova Movimentação
            </button>
        </div>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Data</th>
                    <th>Tipo</th>
                    <th>Produto</th>
                    <th>Quantidade</th>
                    <th>Valor Unit.</th>
                    <th>Valor Total</th>
                    <th>Cliente/Fornecedor</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody id="listaMovimentacoes">
                <tr>
                    <td colspan="8" class="empty-state">
                        <i class="fas fa-exchange-alt"></i>
                        <p>Nenhuma movimentação encontrada</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Totalizadores de Movimentações -->
    <div id="totalizadoresMovimentacoes" class="totalizadores-container" style="display: none;">
        <div class="totalizadores-grid">
            <div class="totalizador-card totalizador-entradas">
                <div class="totalizador-icon">
                    <i class="fas fa-arrow-down"></i>
                </div>
                <div class="totalizador-info">
                    <p class="totalizador-label">Total Entradas (Custo)</p>
                    <h3 class="totalizador-valor" id="movTotalEntradas">R$ 0,00</h3>
                </div>
            </div>

            <div class="totalizador-card totalizador-saidas">
                <div class="totalizador-icon">
                    <i class="fas fa-arrow-up"></i>
                </div>
                <div class="totalizador-info">
                    <p class="totalizador-label">Total Saídas (Vendas)</p>
                    <h3 class="totalizador-valor" id="movTotalSaidas">R$ 0,00</h3>
                </div>
            </div>

            <div class="totalizador-card totalizador-saldo">
                <div class="totalizador-icon">
                    <i class="fas fa-balance-scale"></i>
                </div>
                <div class="totalizador-info">
                    <p class="totalizador-label">Saldo (Lucro/Prejuízo)</p>
                    <h3 class="totalizador-valor" id="movSaldoTotal">R$ 0,00</h3>
                    <p class="totalizador-status" id="movStatusSaldo"></p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Movimentação -->
<div id="modalMovimentacao" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="tituloModalMovimentacao">Nova Movimentação</h3>
            <span class="close" onclick="fecharModal('modalMovimentacao')">&times;</span>
        </div>
        <form id="formMovimentacao" onsubmit="salvarMovimentacao(event)">
            <input type="hidden" id="movId" value="">
            <div class="form-group">
                <label>Tipo *</label>
                <select id="movTipo" class="form-control" required onchange="alterarTipoMovimentacao()">
                    <option value="entrada">Entrada</option>
                    <option value="saida">Saída</option>
                </select>
            </div>

            <div class="form-group">
                <label>Produto *</label>
                <select id="movProduto" class="form-control" required onchange="atualizarPrecoMovimentacao()">
                    <option value="">Selecione...</option>
                </select>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Quantidade *</label>
                    <input type="number" id="movQuantidade" class="form-control" min="1" required oninput="calcularTotalMovimentacao()" onchange="calcularTotalMovimentacao()">
                </div>
                <div class="form-group">
                    <label>Valor Unitário *</label>
                    <input type="text" id="movValorUnitario" class="form-control" data-mask="dinheiro" required oninput="calcularTotalMovimentacao()" onchange="calcularTotalMovimentacao()" placeholder="0,00">
                </div>
                <div class="form-group">
                    <label>Valor Total *</label>
                    <input type="text" id="movValorTotal" class="form-control" readonly style="background-color: #f8f9fa; font-weight: bold; color: #2ecc71;">
                </div>
            </div>

            <div class="form-group" id="divFornecedor">
                <label>Fornecedor</label>
                <select id="movFornecedor" class="form-control">
                    <option value="">Selecione...</option>
                </select>
            </div>

            <div class="form-group" id="divCliente" style="display: none;">
                <label>Cliente</label>
                <select id="movCliente" class="form-control">
                    <option value="">Selecione...</option>
                </select>
            </div>

            <div class="form-group">
                <label>Observação</label>
                <textarea id="movObservacao" class="form-control" rows="2"></textarea>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="fecharModal('modalMovimentacao')">Cancelar</button>
                <button type="submit" class="btn btn-primary">Salvar</button>
            </div>
        </form>
    </div>
</div>
