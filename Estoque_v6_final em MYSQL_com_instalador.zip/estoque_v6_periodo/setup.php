<?php
date_default_timezone_set('America/Sao_Paulo');

$step = isset($_POST['step']) ? $_POST['step'] : '1';
$error = '';
$success = '';

if ($step === '2') {
    $host   = trim($_POST['host']   ?? '');
    $dbname = trim($_POST['dbname'] ?? '');
    $user   = trim($_POST['user']   ?? '');
    $pass   = trim($_POST['pass']   ?? '');
    $charset = 'utf8mb4';

    try {
        $dsn = "mysql:host={$host};port=3306;dbname={$dbname};charset={$charset}";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4, time_zone = '-03:00'",
        ];
        $db = new PDO($dsn, $user, $pass, $options);

        $db->exec("CREATE TABLE IF NOT EXISTS usuarios (id INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(255) NOT NULL, username VARCHAR(100) UNIQUE NOT NULL, senha VARCHAR(255) NOT NULL, tipo VARCHAR(20) DEFAULT 'usuario', nivel_admin VARCHAR(20) DEFAULT NULL, ativo TINYINT(1) DEFAULT 1, data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS permissoes (id INT AUTO_INCREMENT PRIMARY KEY, usuario_id INT NOT NULL, dashboard TINYINT(1) DEFAULT 1, produtos TINYINT(1) DEFAULT 1, movimentacoes TINYINT(1) DEFAULT 1, clientes TINYINT(1) DEFAULT 1, fornecedores TINYINT(1) DEFAULT 1, alertas TINYINT(1) DEFAULT 1, administracao TINYINT(1) DEFAULT 0, FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS clientes (id INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(255) NOT NULL, cpf_cnpj VARCHAR(30), telefone VARCHAR(30), email VARCHAR(255), endereco TEXT, cidade VARCHAR(100), estado VARCHAR(50), cep VARCHAR(20), data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS fornecedores (id INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(255) NOT NULL, cnpj VARCHAR(30), telefone VARCHAR(30), email VARCHAR(255), endereco TEXT, cidade VARCHAR(100), estado VARCHAR(50), cep VARCHAR(20), contato_responsavel VARCHAR(255), data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS categorias (id INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(255) NOT NULL, descricao TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS produtos (id INT AUTO_INCREMENT PRIMARY KEY, codigo_barras VARCHAR(100), nome VARCHAR(255) NOT NULL, descricao TEXT, categoria_id INT, fornecedor_id INT, preco_custo DECIMAL(10,2) NOT NULL, preco_venda DECIMAL(10,2) NOT NULL, estoque_atual INT DEFAULT 0, estoque_minimo INT DEFAULT 0, foto VARCHAR(255), data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (categoria_id) REFERENCES categorias(id), FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS movimentacoes (id INT AUTO_INCREMENT PRIMARY KEY, produto_id INT NOT NULL, tipo VARCHAR(20) NOT NULL, quantidade INT NOT NULL, valor_unitario DECIMAL(10,2), valor_total DECIMAL(10,2), cliente_id INT, fornecedor_id INT, observacao TEXT, data_movimentacao DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (produto_id) REFERENCES produtos(id), FOREIGN KEY (cliente_id) REFERENCES clientes(id), FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS historico_precos (id INT AUTO_INCREMENT PRIMARY KEY, produto_id INT NOT NULL, preco_custo DECIMAL(10,2) NOT NULL, preco_venda DECIMAL(10,2) NOT NULL, data_registro DATETIME, FOREIGN KEY (produto_id) REFERENCES produtos(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS historico_compras (id INT AUTO_INCREMENT PRIMARY KEY, produto_id INT NOT NULL, quantidade INT NOT NULL, preco_custo DECIMAL(10,2) NOT NULL, preco_custo_anterior DECIMAL(10,2), fornecedor_id INT, observacao TEXT, data_compra DATETIME, FOREIGN KEY (produto_id) REFERENCES produtos(id), FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS auditoria_backup (id INT AUTO_INCREMENT PRIMARY KEY, usuario_id INT NOT NULL, usuario_nome VARCHAR(255) NOT NULL, tipo_acao VARCHAR(20) NOT NULL, nome_arquivo VARCHAR(255), data_hora DATETIME DEFAULT CURRENT_TIMESTAMP, ip_address VARCHAR(50), FOREIGN KEY (usuario_id) REFERENCES usuarios(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS configuracoes (chave VARCHAR(100) PRIMARY KEY, valor TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("INSERT IGNORE INTO configuracoes (chave, valor) VALUES ('limite_usuarios', '0')");

        $stmt = $db->query("SELECT COUNT(*) FROM usuarios");
        if ($stmt->fetchColumn() == 0) {
            $h = password_hash('Admin@2024!', PASSWORD_DEFAULT);
            $s = $db->prepare("INSERT INTO usuarios (nome,username,senha,tipo,nivel_admin) VALUES (?,?,?,?,?)");
            $s->execute(['Administrador do Sistema','admin',$h,'admin','master']);
            $aid = $db->lastInsertId();
            $db->prepare("INSERT INTO permissoes (usuario_id,dashboard,produtos,movimentacoes,clientes,fornecedores,alertas,administracao) VALUES (?,1,1,1,1,1,1,1)")->execute([$aid]);
            $h2 = password_hash('vendedor123', PASSWORD_DEFAULT);
            $s->execute(['Vendedor Exemplo','vendedor',$h2,'usuario',null]);
            $vid = $db->lastInsertId();
            $db->prepare("INSERT INTO permissoes (usuario_id,dashboard,produtos,movimentacoes,clientes,fornecedores,alertas,administracao) VALUES (?,1,1,1,1,0,1,0)")->execute([$vid]);
        }

        $stmt = $db->query("SELECT COUNT(*) FROM categorias");
        if ($stmt->fetchColumn() == 0) {
            $db->exec("INSERT INTO categorias (nome,descricao) VALUES ('Eletrônicos','Produtos eletrônicos'),('Alimentos','Produtos alimentícios'),('Bebidas','Bebidas diversas'),('Limpeza','Produtos de limpeza'),('Higiene','Higiene pessoal')");
        }

        // Reescreve database.php com as credenciais corretas
        $h = addslashes($host); $d = addslashes($dbname); $u = addslashes($user); $p = addslashes($pass);
        $content = "<?php\ndate_default_timezone_set('America/Sao_Paulo');\n\nclass Database {\n    private \$db;\n    private \$host    = '{$h}';\n    private \$port    = '3306';\n    private \$dbname  = '{$d}';\n    private \$user    = '{$u}';\n    private \$pass    = '{$p}';\n    private \$charset = 'utf8mb4';\n\n    public function __construct() {\n        \$dsn = \"mysql:host={\$this->host};port={\$this->port};dbname={\$this->dbname};charset={\$this->charset}\";\n        \$options = [\n            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,\n            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,\n            PDO::MYSQL_ATTR_INIT_COMMAND => \"SET NAMES utf8mb4, time_zone = '-03:00'\",\n        ];\n        \$this->db = new PDO(\$dsn, \$this->user, \$this->pass, \$options);\n        \$this->createTables();\n    }\n\n    private function createTables() {\n        // Tabelas gerenciadas pelo setup.php\n    }\n\n    public function getConnection() {\n        return \$this->db;\n    }\n}\n?>";
        file_put_contents(__DIR__ . '/database.php', $content);

        $success = true;
    } catch (Exception $e) {
        $error = $e->getMessage();
        $step  = '1';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Instalador — Estoque Pro</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',sans-serif;background:#0f172a;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.card{background:#1e293b;border-radius:16px;padding:40px;width:100%;max-width:480px;box-shadow:0 25px 50px rgba(0,0,0,.5)}
.logo{text-align:center;margin-bottom:30px}
.logo h1{color:#38bdf8;font-size:26px;font-weight:700}
.logo p{color:#94a3b8;font-size:14px;margin-top:4px}
label{display:block;color:#cbd5e1;font-size:13px;font-weight:600;margin-bottom:6px;margin-top:18px}
input{width:100%;padding:12px 14px;border-radius:8px;border:1px solid #334155;background:#0f172a;color:#f1f5f9;font-size:14px;outline:none;transition:.2s}
input:focus{border-color:#38bdf8;box-shadow:0 0 0 3px rgba(56,189,248,.15)}
.hint{color:#64748b;font-size:12px;margin-top:4px}
button{width:100%;padding:14px;margin-top:28px;background:linear-gradient(135deg,#0ea5e9,#6366f1);color:#fff;border:none;border-radius:10px;font-size:16px;font-weight:700;cursor:pointer;transition:.2s}
button:hover{opacity:.9;transform:translateY(-1px)}
.error{background:#7f1d1d;border:1px solid #ef4444;color:#fca5a5;padding:14px;border-radius:8px;margin-bottom:20px;font-size:13px}
.success-box{text-align:center}
.check{font-size:64px;margin-bottom:16px}
.success-box h2{color:#4ade80;font-size:22px;margin-bottom:10px}
.success-box p{color:#94a3b8;font-size:14px;line-height:1.6}
.cred{background:#0f172a;border-radius:8px;padding:14px;margin:16px 0;text-align:left}
.cred span{color:#64748b;font-size:12px}
.cred strong{color:#f1f5f9;font-size:15px;display:block;margin-top:2px}
.btn-ir{display:inline-block;margin-top:20px;padding:13px 32px;background:linear-gradient(135deg,#4ade80,#16a34a);color:#fff;border-radius:10px;text-decoration:none;font-weight:700;font-size:15px}
.warning{background:#431407;border:1px solid #f97316;color:#fed7aa;padding:10px 14px;border-radius:8px;font-size:12px;margin-top:14px}
</style>
</head>
<body>
<?php if ($success): ?>
<div class="card">
  <div class="success-box">
    <div class="check">✅</div>
    <h2>Instalação concluída!</h2>
    <p>Banco configurado, tabelas criadas e <code>database.php</code> atualizado com sucesso.</p>
    <div class="cred">
      <span>Login admin</span><strong>admin</strong>
      <span style="margin-top:8px;display:block">Senha admin</span><strong>Admin@2024!</strong>
      <span style="margin-top:8px;display:block">Login vendedor</span><strong>vendedor</strong>
      <span style="margin-top:8px;display:block">Senha vendedor</span><strong>vendedor123</strong>
    </div>
    <a class="btn-ir" href="index.php">🚀 Entrar no sistema</a>
    <div class="warning">⚠️ <strong>Delete o arquivo setup.php</strong> do servidor após acessar o sistema!</div>
  </div>
</div>
<?php else: ?>
<div class="card">
  <div class="logo">
    <h1>📦 Estoque Pro</h1>
    <p>Instalador — informe os dados do banco InfiniteFree</p>
  </div>
  <?php if ($error): ?>
  <div class="error">❌ <strong>Erro de conexão:</strong><br><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  <form method="POST">
    <input type="hidden" name="step" value="2">
    <label>MySQL Host</label>
    <input name="host" placeholder="ex: sql200.infinityfree.com" required value="<?= htmlspecialchars($_POST['host'] ?? '') ?>">
    <div class="hint">Painel InfiniteFree → MySQL Databases → ver detalhes</div>
    <label>Nome do Banco</label>
    <input name="dbname" placeholder="ex: if0_37123456_estoque" required value="<?= htmlspecialchars($_POST['dbname'] ?? '') ?>">
    <label>Usuário MySQL</label>
    <input name="user" placeholder="ex: if0_37123456" required value="<?= htmlspecialchars($_POST['user'] ?? '') ?>">
    <label>Senha MySQL</label>
    <input name="pass" type="password" placeholder="Senha definida no painel">
    <button type="submit">⚡ Instalar agora</button>
  </form>
</div>
<?php endif; ?>
</body>
</html>
