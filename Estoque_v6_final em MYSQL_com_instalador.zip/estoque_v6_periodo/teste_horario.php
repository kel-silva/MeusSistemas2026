<?php
// Configurar timezone para horário de Brasília (GMT-3)
date_default_timezone_set('America/Sao_Paulo');

echo "<h1>Teste de Horário - Brasília (GMT-3)</h1>";

echo "<h2>1. Horário do PHP:</h2>";
echo "<p>date('Y-m-d H:i:s'): <strong>" . date('Y-m-d H:i:s') . "</strong></p>";
echo "<p>date('d/m/Y H:i:s'): <strong>" . date('d/m/Y H:i:s') . "</strong></p>";

echo "<h2>2. Timezone configurado:</h2>";
echo "<p>" . date_default_timezone_get() . "</p>";

echo "<h2>3. Teste com SQLite:</h2>";
require_once 'database.php';
$db = new Database();
$conn = $db->getConnection();

// Testar função DATETIME_BR
$stmt = $conn->query("SELECT DATETIME_BR() as hora_brasil");
$result = $stmt->fetch(PDO::FETCH_ASSOC);
echo "<p>DATETIME_BR(): <strong>" . $result['hora_brasil'] . "</strong></p>";

// Testar datetime padrão do SQLite
$stmt = $conn->query("SELECT datetime('now') as hora_utc");
$result = $stmt->fetch(PDO::FETCH_ASSOC);
echo "<p>datetime('now') UTC: <strong>" . $result['hora_utc'] . "</strong></p>";

echo "<h2>4. Última data cadastrada na tabela usuarios:</h2>";
$stmt = $conn->query("SELECT data_cadastro FROM usuarios ORDER BY id DESC LIMIT 1");
$result = $stmt->fetch(PDO::FETCH_ASSOC);
if ($result) {
    echo "<p>Última data: <strong>" . $result['data_cadastro'] . "</strong></p>";
} else {
    echo "<p>Nenhum usuário cadastrado ainda</p>";
}

echo "<hr>";
echo "<p><em>Se o horário estiver errado, delete o arquivo estoque.db e recarregue a página</em></p>";
?>
