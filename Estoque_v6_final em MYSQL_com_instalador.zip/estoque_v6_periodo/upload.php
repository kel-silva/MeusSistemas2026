<?php
header('Content-Type: application/json');

// Diretório de upload (relativo à raiz do projeto)
$uploadDir = 'uploads/';

// Criar diretório se não existir
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Verificar se recebeu arquivo
if (!isset($_FILES['foto']) || $_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'error' => 'Nenhum arquivo enviado ou erro no upload']);
    exit;
}

$file = $_FILES['foto'];

// Validar tipo de arquivo
$allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
if (!in_array($file['type'], $allowedTypes)) {
    echo json_encode(['success' => false, 'error' => 'Tipo de arquivo não permitido. Use JPG, PNG, GIF ou WEBP']);
    exit;
}

// Validar tamanho (máximo 5MB)
$maxSize = 5 * 1024 * 1024; // 5MB
if ($file['size'] > $maxSize) {
    echo json_encode(['success' => false, 'error' => 'Arquivo muito grande. Máximo 5MB']);
    exit;
}

// Gerar nome único para o arquivo
$extension = pathinfo($file['name'], PATHINFO_EXTENSION);
$fileName = uniqid() . '_' . time() . '.' . $extension;
$targetPath = $uploadDir . $fileName;

// Mover arquivo para o diretório de upload
if (move_uploaded_file($file['tmp_name'], $targetPath)) {
    // Retornar caminho RELATIVO (funciona em qualquer servidor/hospedagem)
    echo json_encode([
        'success' => true,
        'path' => $targetPath,  // uploads/xxxxx.jpg (caminho relativo)
        'filename' => $fileName
    ]);
} else {
    echo json_encode(['success' => false, 'error' => 'Erro ao salvar arquivo']);
}
?>
