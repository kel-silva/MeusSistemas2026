# 🚀 INSTALAÇÃO RÁPIDA - CORREÇÃO DO ERRO DE LOGIN

## ❌ PROBLEMA RESOLVIDO

**Erro corrigido:** `SQLSTATE[HY000]: General error: 1 no such column: login`

Este erro ocorria porque a tabela `usuarios` não tinha a coluna `login`.

---

## ✅ SOLUÇÃO IMPLEMENTADA

A correção foi feita **automaticamente no código**! Você não precisa executar scripts SQL manualmente.

### O que foi corrigido:

1. **config.php** - Atualizado para criar automaticamente a coluna `login`
2. **admin.php** - Mantido com todas as funcionalidades de login
3. **index.php** - Tela de login funcionando com campo de usuário
4. **update_database.sql** - Atualizado com instruções para SQLite

---

## 📋 INSTRUÇÕES DE INSTALAÇÃO

### PASSO 1: FAZER BACKUP (IMPORTANTE!)

Antes de atualizar, faça backup do seu banco de dados:

```bash
# Copie o arquivo erp.db para um local seguro
cp database/erp.db database/erp.db.backup
```

### PASSO 2: SUBSTITUIR ARQUIVOS

Substitua os seguintes arquivos no seu servidor:

- ✅ `config.php` (arquivo principal corrigido)
- ✅ `admin.php` (painel administrativo)
- ✅ `index.php` (tela de login)
- ✅ `update_database.sql` (referência)

**IMPORTANTE:** Mantenha backup dos arquivos originais!

### PASSO 3: ACESSAR O SISTEMA

1. Acesse a tela de login do sistema
2. A coluna `login` será criada **automaticamente**
3. Os logins serão gerados baseados nos emails existentes

**Exemplos de logins criados:**
- Email: `joao@empresa.com` → Login: `joao`
- Email: `maria.silva@teste.com` → Login: `maria.silva`

### PASSO 4: TESTAR

1. Faça login como **administrador master**:
   - Email: `admin@sistema.com`
   - Senha: `Admin@2024!Secure`

2. Ou faça login com um **usuário da empresa** usando o **login** (não o email)

3. Teste o cadastro de novas empresas

---

## 🔧 COMO FUNCIONA A CORREÇÃO AUTOMÁTICA

O arquivo `config.php` foi atualizado com um mecanismo que:

1. Verifica se a coluna `login` existe na tabela `usuarios`
2. Se não existir, cria automaticamente
3. Preenche os logins baseados nos emails (parte antes do @)
4. Define o campo como único (UNIQUE)

**Você não precisa fazer NADA manualmente!**

---

## 📝 ESTRUTURA DO BANCO APÓS ATUALIZAÇÃO

```sql
Tabela: usuarios
├── id (INTEGER PRIMARY KEY)
├── nome (TEXT)
├── login (TEXT UNIQUE) ← NOVA COLUNA
├── email (TEXT UNIQUE)
├── senha (TEXT)
├── empresa_id (INTEGER)
├── tipo (TEXT)
├── is_master (INTEGER)
└── data_cadastro (DATETIME)
```

---

## ⚠️ RESOLUÇÃO DE PROBLEMAS

### Erro persiste após atualização

**Solução 1:** Limpe o cache do navegador
```
Ctrl + Shift + Delete (Chrome/Firefox)
```

**Solução 2:** Verifique permissões da pasta database
```bash
chmod 777 database/
chmod 666 database/erp.db
```

**Solução 3:** Apague o banco e deixe o sistema recriar
```bash
# ATENÇÃO: Isso apaga TODOS os dados!
rm database/erp.db
# Acesse o sistema - um novo banco será criado
```

### Não consigo fazer login

1. Verifique se os arquivos foram substituídos corretamente
2. Acesse como admin master primeiro (credenciais acima)
3. No painel admin, veja os logins dos usuários
4. Use o **login**, não o email, para entrar

### Erro: "Duplicate column name: login"

Isso significa que a coluna já existe. Ignore o erro, o sistema vai funcionar.

---

## 🎯 RESUMO DAS MUDANÇAS

### Arquivos modificados:
- ✅ `config.php` - Adiciona coluna login automaticamente
- ✅ `update_database.sql` - Atualizado para SQLite
- ✅ `INSTALACAO_RAPIDA.md` - Este arquivo de instruções

### Arquivos que permanecem iguais:
- ✅ `admin.php` - Funcionando corretamente
- ✅ `index.php` - Funcionando corretamente
- ✅ `dashboard.php`, `clientes.php`, `produtos.php`, `vendas.php`, `relatorios.php`

---

## 📞 SUPORTE

Se encontrar problemas:

1. Verifique os logs de erro do PHP
2. Verifique permissões da pasta `database/`
3. Certifique-se de que substituiu o arquivo `config.php`
4. Teste com o usuário admin master primeiro

---

## ✨ FUNCIONALIDADES DO SISTEMA

Após a instalação, você terá acesso a:

- ✅ Login com usuário (não email)
- ✅ Painel administrativo master
- ✅ Cadastro multi-empresa
- ✅ Gestão de clientes, produtos e vendas
- ✅ Relatórios e dashboards
- ✅ Teclas de atalho (Alt+Letra)
- ✅ Máscaras de entrada (CPF, telefone)

---

**Versão:** 2.0 Corrigido
**Data:** Março 2026
**Banco de Dados:** SQLite
