# Sistema ERP - Gestão Empresarial

## 🔧 Correções Aplicadas

### ✅ Problemas Corrigidos:

1. **Login de Empresas Corrigido**
   - Agora as empresas cadastradas conseguem fazer login corretamente
   - Sistema verifica corretamente o hash da senha
   - Redirecionamento baseado no tipo de usuário (admin ou usuário comum)

2. **Cadastro de Empresas Otimizado**
   - Tipo de usuário corrigido para 'usuario' ao invés de 'admin_empresa'
   - Validação de email duplicado
   - Hash de senha usando PASSWORD_DEFAULT (bcrypt)

3. **Melhorias de Segurança**
   - Senhas armazenadas com hash bcrypt
   - Validação de email único no sistema
   - Proteção contra SQL injection usando prepared statements
   - Sanitização de entradas de dados

4. **Sistema de Verificação**
   - Função verificarAdmin() corrigida para redirecionar corretamente
   - Validação de sessão em todas as páginas protegidas

---

## 📋 Como Usar

### 1️⃣ Instalação

1. Extraia os arquivos em um servidor com PHP 7.4+ e SQLite habilitado
2. Configure as permissões da pasta `database/` para escrita (777 ou 755)
3. Acesse pelo navegador: `http://seu-servidor/erp-system-novo/`

### 2️⃣ Login como Administrador Master

**Credenciais padrão:**
- Email: `admin@sistema.com`
- Senha: `Admin@2024!Secure`

**Como acessar:**
1. Na tela de login, pressione `Ctrl + L`
2. O formulário de administrador aparecerá
3. Digite as credenciais acima
4. Clique em "Entrar como Administrador"

### 3️⃣ Cadastrar Nova Empresa

1. Faça login como administrador
2. Preencha o formulário "Cadastrar Nova Empresa":
   - Nome da Empresa
   - Nome do Responsável
   - Email de Login (será usado para login)
   - Senha (mínimo 6 caracteres)
3. Clique em "Cadastrar Empresa"

### 4️⃣ Login como Empresa

1. Faça logout do administrador (se estiver logado)
2. Na tela de login principal, use:
   - Email: o email cadastrado para a empresa
   - Senha: a senha definida no cadastro
3. Clique em "Entrar"

### 5️⃣ Gerenciar Empresas

**Editar:**
- Na lista de empresas, clique em "Editar"
- Você pode alterar: nome da empresa, email de login e senha
- Deixe o campo senha em branco para manter a atual

**Ativar/Inativar:**
- Clique no botão "Ativar" ou "Inativar"
- Empresas inativas não podem fazer login

---

## 🆘 Solução de Problemas

### "Email ou senha inválidos"
- Verifique se está usando o email correto cadastrado
- Senhas são case-sensitive (maiúsculas/minúsculas)
- Certifique-se de que a empresa está ativa

### "Empresa desativada"
- Entre em contato com o administrador
- O administrador pode ativar a empresa no painel admin

### Esqueci a senha de uma empresa
- Acesse como administrador
- Edite a empresa
- Defina uma nova senha no campo "Nova Senha"

---

## 📞 Suporte

Sistema desenvolvido com:
- PHP 7.4+
- SQLite 3
- Bootstrap 5.3
- Bootstrap Icons

**Licença:** Todos os direitos reservados © 2024
