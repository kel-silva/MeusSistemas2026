# 📊 Sistema ERP - Versão Single-Tenant

## 🎯 Sobre esta Versão

Este sistema foi **otimizado para arquitetura de subdomínios**, onde cada cliente tem sua própria instalação independente.

### ✅ **Isolamento de Dados REMOVIDO**

Esta versão **NÃO** possui isolamento por `empresa_id`. Cada instalação é completamente independente e deve ser usada em subdomínios separados.

## 🏗️ Arquitetura Recomendada

### **Modelo de Subdomínios:**

```
empresa1.seudominio.com → Instalação 1 (Banco próprio)
empresa2.seudominio.com → Instalação 2 (Banco próprio)
empresa3.seudominio.com → Instalação 3 (Banco próprio)
```

## 📁 Estrutura de Pastas no Servidor

```
/var/www/
├── empresa1/          ← Instalação Cliente 1
│   ├── index.php
│   ├── dashboard.php
│   └── database/
│       └── erp.db     ← Banco de dados do Cliente 1
│
├── empresa2/          ← Instalação Cliente 2
│   ├── index.php
│   ├── dashboard.php
│   └── database/
│       └── erp.db     ← Banco de dados do Cliente 2
│
└── empresa3/          ← Instalação Cliente 3
    ├── index.php
    ├── dashboard.php
    └── database/
        └── erp.db     ← Banco de dados do Cliente 3
```

## ⚙️ Configuração de Subdomínios

### **1. No cPanel:**

1. Acesse **Domínios** ou **Subdomínios**
2. Adicione: `empresa1.seudominio.com`
3. Direcione para: `/public_html/empresa1`
4. Repita para cada cliente

### **2. Apache (VirtualHost):**

```apache
<VirtualHost *:80>
    ServerName empresa1.seudominio.com
    DocumentRoot /var/www/empresa1

    <Directory /var/www/empresa1>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

### **3. Nginx:**

```nginx
server {
    listen 80;
    server_name empresa1.seudominio.com;
    root /var/www/empresa1;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
    }
}
```

## 🚀 Instalação para Novo Cliente

### **Passo 1: Upload dos Arquivos**

Faça upload via FTP/SSH para a pasta do cliente:
```bash
/var/www/empresaNOVO/
```

### **Passo 2: Configurar Permissões**

```bash
chmod 755 /var/www/empresaNOVO/database
chmod 644 /var/www/empresaNOVO/database/erp.db
```

### **Passo 3: Acessar e Configurar**

1. Acesse: `https://empresaNOVO.seudominio.com`
2. Faça login com as credenciais padrão
3. **IMPORTANTE:** Altere a senha imediatamente
4. Configure os dados da empresa

## 🔐 Credenciais Padrão

```
Email: admin@sistema.com
Senha: admin123
```

⚠️ **ALTERE IMEDIATAMENTE APÓS O PRIMEIRO LOGIN!**

## 📦 Funcionalidades

- ✅ **Dashboard** - Visão geral de vendas e estoque
- ✅ **Produtos** - Cadastro e controle de produtos
- ✅ **Clientes** - Gestão de clientes (com CPF)
- ✅ **Vendas** - Registro e controle de vendas
- ✅ **Relatórios** - Relatórios detalhados
- ✅ **Administração** - Gerenciamento de usuários

## 🔄 Backup e Restore

### **Backup Completo:**

```bash
# Backup de uma instalação
tar -czf empresa1-backup-$(date +%Y%m%d).tar.gz /var/www/empresa1/

# Apenas o banco de dados
cp /var/www/empresa1/database/erp.db ~/backups/empresa1-$(date +%Y%m%d).db
```

### **Restore:**

```bash
# Restaurar banco
cp ~/backups/empresa1-20240327.db /var/www/empresa1/database/erp.db
chmod 644 /var/www/empresa1/database/erp.db
```

## 🛡️ Segurança

### **Configurações Recomendadas:**

1. **HTTPS Obrigatório** - Configure SSL/TLS
2. **Proteção do Banco:**

Adicione ao `.htaccess`:
```apache
<FilesMatch "\.db$">
    Order allow,deny
    Deny from all
</FilesMatch>
```

3. **Senha Forte** - Altere senha padrão
4. **Backup Automático** - Configure cron jobs
5. **Permissões Corretas** - database/ com 755, .db com 644

## 🔧 Manutenção

### **Atualizar Todos os Clientes:**

```bash
#!/bin/bash
for dir in /var/www/empresa*/; do
    echo "Atualizando $dir"
    # Copiar arquivos atualizados
    cp index.php "$dir"
    cp dashboard.php "$dir"
    cp produtos.php "$dir"
    cp clientes.php "$dir"
    cp vendas.php "$dir"
    cp relatorios.php "$dir"
    # NÃO copie database/ para preservar dados!
done
echo "✓ Atualização concluída!"
```

## 📊 Estrutura do Banco de Dados

### **Tabelas:**

- `empresas` - Dados da empresa (nome, status)
- `usuarios` - Usuários do sistema
- `clientes` - Cadastro de clientes
- `produtos` - Produtos e estoque
- `vendas` - Registro de vendas
- `itens_venda` - Itens de cada venda

### **Sem Isolamento:**

✅ Não há campo `empresa_id` nas tabelas
✅ Cada instalação é totalmente independente
✅ Impossível vazamento de dados entre clientes

## 🎯 Vantagens desta Arquitetura

| Aspecto | Multi-Tenant | Single-Tenant (Esta Versão) |
|---------|--------------|------------------------------|
| **Segurança** | ⚠️ Risco de vazamento | ✅ Totalmente isolado |
| **Performance** | ⚠️ Banco único cresce | ✅ Bancos pequenos |
| **Backup** | ⚠️ Tudo ou nada | ✅ Individual |
| **Personalização** | ❌ Difícil | ✅ Fácil |
| **Escalabilidade** | ⚠️ Servidor único | ✅ Múltiplos servidores |
| **Manutenção** | ⚠️ Update afeta todos | ✅ Update controlado |

## 💡 Dicas Importantes

1. **Teste Primeiro** - Sempre teste atualizações em ambiente de desenvolvimento
2. **Backup Regular** - Configure backup automático diário
3. **Monitoramento** - Monitore tamanho do banco e performance
4. **Documentação** - Mantenha registro de qual cliente usa qual subdomínio
5. **Nomenclatura** - Use nomes descritivos (empresa-matriz, empresa-filial1)

## 🆘 Troubleshooting

### **Erro: "Banco de dados não encontrado"**
- Verifique se a pasta `database/` existe
- Verifique permissões (755 para pasta, 644 para .db)

### **Erro: "Não foi possível gravar no banco"**
- Verifique se o servidor web tem permissão de escrita
- Execute: `chmod 644 database/erp.db`

### **Erro: "Sessão expirada constantemente"**
- Verifique configuração de `session_save_path` no PHP
- Aumente `session.gc_maxlifetime` no php.ini

## 📞 Suporte

Para cada cliente:
- Backup/restore independente
- Customizações específicas
- Testes isolados
- Migração para servidor dedicado se necessário

---

## 🏆 Resumo

✅ **Seguro** - Cada cliente completamente isolado
✅ **Rápido** - Bancos pequenos e otimizados
✅ **Flexível** - Personalize cada instalação
✅ **Confiável** - Backup/restore individual
✅ **Escalável** - Distribua em múltiplos servidores

---

**Desenvolvido com foco em escalabilidade, segurança e performance** 🚀
