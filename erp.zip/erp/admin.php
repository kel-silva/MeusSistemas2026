<?php
require_once 'config.php';
verificarLogin();
verificarAdmin();

$pdo = getConnection();
$mensagem = '';
$tipo_msg = 'success';

// Processar cadastro de empresa COM login/senha
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cadastrar_empresa'])) {
    $nome_empresa = sanitize($_POST['nome_empresa']);
    $nome_usuario = sanitize($_POST['nome_usuario']);
    $email_usuario = sanitize($_POST['email_usuario']);
    $senha_usuario = $_POST['senha_usuario'];

    if (empty($nome_empresa) || empty($nome_usuario) || empty($email_usuario) || empty($senha_usuario)) {
        $mensagem = 'Todos os campos são obrigatórios!';
        $tipo_msg = 'danger';
    } else {
        try {
            $pdo->beginTransaction();

            // Verificar se email já existe
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE email = ?");
            $stmt->execute([$email_usuario]);
            if ($stmt->fetchColumn() > 0) {
                throw new Exception('Email já está em uso!');
            }

            // Criar empresa
            $stmt = $pdo->prepare("INSERT INTO empresas (nome, status) VALUES (?, 1)");
            $stmt->execute([$nome_empresa]);

            // Criar usuário administrador da empresa
            $senha_hash = password_hash($senha_usuario, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, empresa_id, tipo, is_master)
                                   VALUES (?, ?, ?, ?, 'usuario', 0)");
            $stmt->execute([$nome_usuario, $email_usuario, $senha_hash]);

            $pdo->commit();
            $mensagem = 'Empresa cadastrada com sucesso!';
            $tipo_msg = 'success';
        } catch (Exception $e) {
            $pdo->rollBack();
            $mensagem = 'Erro: ' . $e->getMessage();
            $tipo_msg = 'danger';
        }
    }
}

// Processar edição de empresa
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['editar_empresa'])) {
    $nome_empresa = sanitize($_POST['nome_empresa_edit']);
    $email_usuario = sanitize($_POST['email_usuario_edit']);
    $senha_usuario = $_POST['senha_usuario_edit'] ?? '';

    try {
        $pdo->beginTransaction();

        // Atualizar nome da empresa
        $stmt = $pdo->prepare("UPDATE empresas SET nome = ? WHERE id = ?");
        $stmt->execute([$nome_empresa]);

        // Buscar usuário principal da empresa (não master)
        $stmt = $pdo->prepare("SELECT id, email FROM usuarios AND is_master = 0 LIMIT 1");
        $stmt->execute([$empresa_id]);
        $usuario = $stmt->fetch();

        if ($usuario) {
            // Atualizar email
            if ($email_usuario !== $usuario['email']) {
                // Verificar se novo email já existe
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE email = ? AND id != ?");
                $stmt->execute([$email_usuario, $usuario['id']]);
                if ($stmt->fetchColumn() > 0) {
                    throw new Exception('Email já está em uso!');
                }
                $stmt = $pdo->prepare("UPDATE usuarios SET email = ? WHERE id = ?");
                $stmt->execute([$email_usuario, $usuario['id']]);
            }

            // Atualizar senha se fornecida
            if (!empty($senha_usuario)) {
                $senha_hash = password_hash($senha_usuario, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE usuarios SET senha = ? WHERE id = ?");
                $stmt->execute([$senha_hash, $usuario['id']]);
            }
        }

        $pdo->commit();
        $mensagem = 'Empresa atualizada com sucesso!';
        $tipo_msg = 'success';
    } catch (Exception $e) {
        $pdo->rollBack();
        $mensagem = 'Erro: ' . $e->getMessage();
        $tipo_msg = 'danger';
    }
}

// Processar ativação/desativação
if (isset($_GET['toggleStatus'])) {
    $stmt = $pdo->prepare("SELECT status FROM empresas WHERE id = ?");
    $stmt->execute([$empresa_id]);
    $empresa = $stmt->fetch();

    if ($empresa) {
        $novo_status = $empresa['status'] == 1 ? 0 : 1;
        $stmt = $pdo->prepare("UPDATE empresas SET status = ? WHERE id = ?");
        $stmt->execute([$novo_status]);
        header('Location: admin.php?msg=status');
        exit;
    }
}

// Listar empresas com seus usuários
$stmt = $pdo->query("SELECT e.*,
                     (SELECT COUNT(*) FROM usuarios WHERE empresa_id = e.id) as total_usuarios,
                     (SELECT email FROM usuarios WHERE empresa_id = e.id AND is_master = 0 LIMIT 1) as email_principal
                     FROM empresas e
                     ORDER BY e.id DESC");
$empresas = $stmt->fetchAll();

// Estatísticas gerais
$total_empresas = count($empresas);
$stmt = $pdo->query("SELECT COUNT(*) FROM usuarios");
$total_usuarios = $stmt->fetchColumn();
$stmt = $pdo->query("SELECT COUNT(*) FROM vendas");
$total_vendas_sistema = $stmt->fetchColumn();

if (isset($_GET['msg']) && $_GET['msg'] === 'status') {
    $mensagem = 'Status atualizado com sucesso!';
    $tipo_msg = 'success';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Administrativo - ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #f093fb 0%, #f5576c 100%);
        }
        .sidebar a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        .required-field::after {
            content: " *";
            color: red;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 p-0 sidebar">
                <div class="p-4 text-white">
                    <h4><i class="bi bi-shield-lock"></i> ADMIN MASTER</h4>
                    <small>Painel Administrativo</small>
                </div>
                <nav>
                    <a href="admin.php" class="active" accesskey="e">
                        <i class="bi bi-building"></i> <u>E</u>mpresas
                    </a>
                    <hr class="text-white">
                    <a href="logout.php" accesskey="q">
                        <i class="bi bi-box-arrow-right"></i> Sair (Ctrl+<u>Q</u>)
                    </a>
                </nav>
            </div>

            <!-- Conteúdo Principal -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="bi bi-shield-lock"></i> Painel Administrativo</h2>
                    <div>
                        <i class="bi bi-person-circle"></i> <?= $_SESSION['nome'] ?>
                    </div>
                </div>

                <?php if ($mensagem): ?>
                    <div class="alert alert-<?= $tipo_msg ?> alert-dismissible fade show">
                        <?= $mensagem ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Estatísticas -->
                <div class="row g-4 mb-4">
                    <div class="col-md-4">
                        <div class="card border-primary">
                            <div class="card-body text-center">
                                <div class="text-primary fs-1">
                                    <i class="bi bi-building"></i>
                                </div>
                                <h6 class="text-muted">Total de Empresas</h6>
                                <h2><?= $total_empresas ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-success">
                            <div class="card-body text-center">
                                <div class="text-success fs-1">
                                    <i class="bi bi-people"></i>
                                </div>
                                <h6 class="text-muted">Total de Usuários</h6>
                                <h2><?= $total_usuarios ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-warning">
                            <div class="card-body text-center">
                                <div class="text-warning fs-1">
                                    <i class="bi bi-cart-check"></i>
                                </div>
                                <h6 class="text-muted">Total de Vendas</h6>
                                <h2><?= $total_vendas_sistema ?></h2>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Formulário Nova Empresa -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <i class="bi bi-building-add"></i> Cadastrar Nova Empresa
                    </div>
                    <div class="card-body">
                        <form method="POST" class="row g-3" id="formNovaEmpresa">
                            <div class="col-md-6">
                                <label class="form-label required-field">Nome da Empresa</label>
                                <input type="text" name="nome_empresa" class="form-control"
                                       placeholder="Ex: Empresa ABC Ltda" required accesskey="n">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label required-field">Nome do Responsável</label>
                                <input type="text" name="nome_usuario" class="form-control"
                                       placeholder="Ex: João Silva" required accesskey="r">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label required-field">Email de Login</label>
                                <input type="email" name="email_usuario" class="form-control"
                                       placeholder="usuario@empresa.com" required accesskey="l">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label required-field">Senha</label>
                                <input type="password" name="senha_usuario" class="form-control"
                                       placeholder="Mínimo 6 caracteres" required minlength="6" accesskey="s">
                            </div>
                            <div class="col-12">
                                <button type="submit" name="cadastrar_empresa" class="btn btn-success" accesskey="c">
                                    <i class="bi bi-plus-circle"></i> <u>C</u>adastrar Empresa
                                </button>
                                <button type="reset" class="btn btn-secondary" accesskey="p">
                                    <i class="bi bi-x-circle"></i> Lim<u>p</u>ar
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Lista de Empresas -->
                <div class="card">
                    <div class="card-header bg-secondary text-white">
                        <i class="bi bi-list"></i> Lista de Empresas Cadastradas
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Nome da Empresa</th>
                                        <th>Email de Login</th>
                                        <th>Usuários</th>
                                        <th>Data de Cadastro</th>
                                        <th>Status</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($empresas as $empresa): ?>
                                        <tr>
                                            <td><?= $empresa['id'] ?></td>
                                            <td>
                                                <strong><?= htmlspecialchars($empresa['nome']) ?></strong>
                                            </td>
                                            <td>
                                                <code><?= htmlspecialchars($empresa['email_principal'] ?? 'N/A') ?></code>
                                            </td>
                                            <td>
                                                <span class="badge bg-info"><?= $empresa['total_usuarios'] ?> usuário(s)</span>
                                            </td>
                                            <td><?= date('d/m/Y H:i', strtotime($empresa['data_cadastro'])) ?></td>
                                            <td>
                                                <?php if ($empresa['status'] == 1): ?>
                                                    <span class="badge bg-success">Ativa</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Inativa</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm" role="group">
                                                    <a href="?toggleStatus=<?= $empresa['id'] ?>"
                                                       class="btn btn-<?= $empresa['status'] == 1 ? 'warning' : 'success' ?>"
                                                       onclick="return confirm('Deseja alterar o status desta empresa?')"
                                                       title="Ativar/Desativar (Alt+T)">
                                                        <i class="bi bi-toggle-<?= $empresa['status'] == 1 ? 'on' : 'off' ?>"></i>
                                                        <?= $empresa['status'] == 1 ? 'Inativar' : 'Ativar' ?>
                                                    </a>
                                                    <button type="button" class="btn btn-primary"
                                                            onclick="editarEmpresa(<?= $empresa['id'] ?>, '<?= htmlspecialchars($empresa['nome'], ENT_QUOTES) ?>', '<?= htmlspecialchars($empresa['email_principal'] ?? '', ENT_QUOTES) ?>')"
                                                            title="Editar (Alt+E)">
                                                        <i class="bi bi-pencil"></i> Editar
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($empresas)): ?>
                                        <tr>
                                            <td colspan="7" class="text-center text-muted">
                                                Nenhuma empresa cadastrada
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Editar Empresa -->
    <div class="modal fade" id="modalEditarEmpresa" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="bi bi-pencil"></i> Editar Empresa</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="empresa_id" id="editEmpresaId">
                        <div class="mb-3">
                            <label class="form-label required-field">Nome da Empresa</label>
                            <input type="text" name="nome_empresa_edit" id="editNomeEmpresa"
                                   class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label required-field">Email de Login</label>
                            <input type="email" name="email_usuario_edit" id="editEmailUsuario"
                                   class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Nova Senha (deixe em branco para manter a atual)</label>
                            <input type="password" name="senha_usuario_edit" id="editSenhaUsuario"
                                   class="form-control" placeholder="Nova senha (opcional)" minlength="6">
                        </div>
                        <div class="alert alert-warning">
                            <i class="bi bi-exclamation-triangle"></i>
                            <strong>Atenção:</strong> As alterações afetarão o login desta empresa.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="bi bi-x"></i> Cancelar
                        </button>
                        <button type="submit" name="editar_empresa" class="btn btn-primary">
                            <i class="bi bi-check"></i> Salvar Alterações
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editarEmpresa(id, nome, email) {
            document.getElementById('editEmpresaId').value = id;
            document.getElementById('editNomeEmpresa').value = nome;
            document.getElementById('editEmailUsuario').value = email;
            document.getElementById('editSenhaUsuario').value = '';

            const modal = new bootstrap.Modal(document.getElementById('modalEditarEmpresa'));
            modal.show();
        }

        // Atalho Ctrl+Q para sair
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.key === 'q') {
                e.preventDefault();
                if (confirm('Deseja realmente sair?')) {
                    window.location.href = 'logout.php';
                }
            }
        });
    </script>
</body>
</html>
