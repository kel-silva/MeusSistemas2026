<?php
require_once 'config.php';
verificarLogin();

$pdo = getConnection();
$mensagem = '';

// Processar cadastro/edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = sanitize($_POST['nome']);
    $cpf = preg_replace('/[^0-9]/', '', sanitize($_POST['cpf']));
    $telefone = preg_replace('/[^0-9]/', '', sanitize($_POST['telefone']));
    $email = sanitize($_POST['email']);
    $endereco = sanitize($_POST['endereco']);

    if (isset($_POST['id']) && !empty($_POST['id'])) {
        // Atualizar
        $stmt = $pdo->prepare("UPDATE clientes SET nome = ?, cpf = ?, telefone = ?, email = ?, endereco = ?
                              WHERE id = ?");
        $stmt->execute([$nome, $cpf, $telefone, $email, $endereco, $_POST['id']]);
        $mensagem = 'Cliente atualizado com sucesso!';
    } else {
        // Inserir
        $stmt = $pdo->prepare("INSERT INTO clientes (nome, cpf, telefone, email, endereco)
                              VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$nome, $cpf, $telefone, $email, $endereco]);
        $mensagem = 'Cliente cadastrado com sucesso!';
    }
}

// Processar exclusão
if (isset($_GET['deletar'])) {
    $stmt = $pdo->prepare("DELETE FROM clientes WHERE id = ?");
    $stmt->execute([$_GET['deletar']]);
    header('Location: clientes.php?msg=deleted');
    exit;
}

// Buscar cliente para edição
$cliente_editar = null;
if (isset($_GET['editar'])) {
    $stmt = $pdo->prepare("SELECT * FROM clientes WHERE id = ?");
    $stmt->execute([$_GET['editar']]);
    $cliente_editar = $stmt->fetch();
}

// Listar clientes
$stmt = $pdo->prepare("SELECT * FROM clientes ORDER BY nome");
$stmt->execute([$empresa_id]);
$clientes = $stmt->fetchAll();

if (isset($_GET['msg']) && $_GET['msg'] === 'deleted') {
    $mensagem = 'Cliente excluído com sucesso!';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes - ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
        }
        .sidebar a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 p-0 sidebar">
                <div class="p-4 text-white">
                    <h4><i class="bi bi-diagram-3"></i> ERP</h4>
                    <small><?= $_SESSION['empresa_nome'] ?? 'Sistema' ?></small>
                </div>
                <nav>
                    <a href="dashboard.php" accesskey="d"><i class="bi bi-speedometer2"></i> <u>D</u>ashboard</a>
                    <a href="clientes.php" class="active" accesskey="c"><i class="bi bi-people"></i> <u>C</u>lientes</a>
                    <a href="produtos.php" accesskey="p"><i class="bi bi-box-seam"></i> <u>P</u>rodutos</a>
                    <a href="vendas.php" accesskey="v"><i class="bi bi-cart-check"></i> <u>V</u>endas</a>
                    <a href="relatorios.php" accesskey="r"><i class="bi bi-file-earmark-text"></i> <u>R</u>elatórios</a>
                    <hr class="text-white">
                    <a href="logout.php" accesskey="q"><i class="bi bi-box-arrow-right"></i> Sair (Alt+<u>Q</u>)</a>
                </nav>
            </div>

            <!-- Conteúdo Principal -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="bi bi-people"></i> Gerenciar Clientes</h2>
                    <div>
                        <i class="bi bi-person-circle"></i> <?= $_SESSION['nome'] ?>
                    </div>
                </div>

                <?php if ($mensagem): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-check-circle"></i> <?= $mensagem ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Formulário -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <i class="bi bi-person-plus"></i> <?= $cliente_editar ? 'Editar' : 'Novo' ?> Cliente
                    </div>
                    <div class="card-body">
                        <form method="POST" id="formCliente">
                            <?php if ($cliente_editar): ?>
                                <input type="hidden" name="id" value="<?= $cliente_editar['id'] ?>">
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Nome Completo <span class="text-danger">*</span></label>
                                    <input type="text" name="nome" id="nome" class="form-control"
                                           value="<?= $cliente_editar['nome'] ?? '' ?>"
                                           placeholder="Ex: João da Silva" required autofocus accesskey="n">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">CPF</label>
                                    <input type="text" name="cpf" id="cpf" class="form-control"
                                           value="<?= isset($cliente_editar['cpf']) ? formatarCPF($cliente_editar['cpf']) : '' ?>"
                                           placeholder="000.000.000-00" maxlength="14" accesskey="f">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Telefone</label>
                                    <input type="text" name="telefone" id="telefone" class="form-control"
                                           value="<?= isset($cliente_editar['telefone']) ? formatarTelefone($cliente_editar['telefone']) : '' ?>"
                                           placeholder="(00) 00000-0000" maxlength="15" accesskey="t">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" name="email" id="email" class="form-control"
                                           value="<?= $cliente_editar['email'] ?? '' ?>"
                                           placeholder="cliente@email.com" accesskey="e">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Endereço</label>
                                    <input type="text" name="endereco" id="endereco" class="form-control"
                                           value="<?= $cliente_editar['endereco'] ?? '' ?>"
                                           placeholder="Rua, Número, Bairro, Cidade" accesskey="o">
                                </div>
                            </div>
                            <button type="submit" class="btn btn-success" accesskey="s">
                                <i class="bi bi-check-circle"></i> <?= $cliente_editar ? 'Atualizar' : 'Cadastrar' ?> (Alt+<u>S</u>)
                            </button>
                            <?php if ($cliente_editar): ?>
                                <a href="clientes.php" class="btn btn-secondary" accesskey="a">
                                    <i class="bi bi-x-circle"></i> C<u>a</u>ncelar
                                </a>
                            <?php else: ?>
                                <button type="reset" class="btn btn-secondary" accesskey="l">
                                    <i class="bi bi-arrow-counterclockwise"></i> <u>L</u>impar
                                </button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>

                <!-- Lista de Clientes -->
                <div class="card">
                    <div class="card-header bg-secondary text-white">
                        <i class="bi bi-list"></i> Lista de Clientes (<?= count($clientes) ?>)
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Nome</th>
                                        <th>CPF</th>
                                        <th>Telefone</th>
                                        <th>Email</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($clientes as $cliente): ?>
                                        <tr>
                                            <td><?= $cliente['id'] ?></td>
                                            <td><strong><?= htmlspecialchars($cliente['nome']) ?></strong></td>
                                            <td><?= !empty($cliente['cpf']) ? formatarCPF($cliente['cpf']) : '-' ?></td>
                                            <td><?= !empty($cliente['telefone']) ? formatarTelefone($cliente['telefone']) : '-' ?></td>
                                            <td><?= htmlspecialchars($cliente['email'] ?? '-') ?></td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="?editar=<?= $cliente['id'] ?>" class="btn btn-warning"
                                                       title="Editar cliente">
                                                        <i class="bi bi-pencil"></i> Editar
                                                    </a>
                                                    <a href="?deletar=<?= $cliente['id'] ?>"
                                                       class="btn btn-danger"
                                                       onclick="return confirm('Deseja realmente excluir <?= htmlspecialchars($cliente['nome']) ?>?')"
                                                       title="Excluir cliente">
                                                        <i class="bi bi-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($clientes)): ?>
                                        <tr>
                                            <td colspan="6" class="text-center text-muted py-4">
                                                <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                                Nenhum cliente cadastrado
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Máscara CPF
        document.getElementById('cpf').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length <= 11) {
                value = value.replace(/(\d{3})(\d)/, '$1.$2');
                value = value.replace(/(\d{3})(\d)/, '$1.$2');
                value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
                e.target.value = value;
            }
        });

        // Máscara Telefone
        document.getElementById('telefone').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length <= 11) {
                if (value.length <= 10) {
                    value = value.replace(/(\d{2})(\d)/, '($1) $2');
                    value = value.replace(/(\d{4})(\d)/, '$1-$2');
                } else {
                    value = value.replace(/(\d{2})(\d)/, '($1) $2');
                    value = value.replace(/(\d{5})(\d)/, '$1-$2');
                }
                e.target.value = value;
            }
        });

        // Navegação por Tab e Enter
        document.getElementById('formCliente').addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
                e.preventDefault();
                const form = e.target.form;
                const index = Array.prototype.indexOf.call(form, e.target);
                if (form.elements[index + 1]) {
                    form.elements[index + 1].focus();
                } else {
                    form.submit();
                }
            }
        });
    </script>
</body>
</html>
