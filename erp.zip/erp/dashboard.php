<?php
require_once 'config.php';
verificarLogin();

$pdo = getConnection();

// Buscar estatísticas
$stmt = $pdo->prepare("SELECT COUNT(*) as total FROM produtos");
$stmt->execute([$empresa_id]);
$total_produtos = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) as total FROM clientes");
$stmt->execute([$empresa_id]);
$total_clientes = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) as total FROM vendas");
$stmt->execute([$empresa_id]);
$total_vendas = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT SUM(preco * quantidade) as total FROM produtos");
$stmt->execute([$empresa_id]);
$valor_estoque = $stmt->fetchColumn() ?? 0;

// Buscar nome da empresa
$stmt = $pdo->prepare("SELECT nome FROM empresas WHERE id = ?");
$stmt->execute([$empresa_id]);
$empresa = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
        }
        .sidebar a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        .stat-card {
            border-left: 4px solid;
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 p-0 sidebar">
                <div class="p-4 text-white">
                    <h4><i class="bi bi-diagram-3"></i> ERP</h4>
                    <small><?= htmlspecialchars($empresa['nome']) ?></small>
                </div>
                <nav>
                    <a href="dashboard.php" class="active"><i class="bi bi-speedometer2"></i> Dashboard</a>
                    <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
                    <a href="produtos.php"><i class="bi bi-box-seam"></i> Produtos</a>
                    <a href="vendas.php"><i class="bi bi-cart-check"></i> Vendas</a>
                    <a href="relatorios.php"><i class="bi bi-file-earmark-text"></i> Relatórios</a>
                    <hr class="text-white">
                    <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Sair</a>
                </nav>
            </div>

            <!-- Conteúdo Principal -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Dashboard</h2>
                    <div>
                        <i class="bi bi-person-circle"></i> <?= htmlspecialchars($_SESSION['nome']) ?>
                    </div>
                </div>

                <!-- Cards de Estatísticas -->
                <div class="row g-4 mb-4">
                    <div class="col-md-3">
                        <div class="card stat-card border-primary">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h6 class="text-muted">Total de Produtos</h6>
                                        <h2><?= $total_produtos ?></h2>
                                    </div>
                                    <div class="text-primary fs-1">
                                        <i class="bi bi-box-seam"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card stat-card border-success">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h6 class="text-muted">Total de Clientes</h6>
                                        <h2><?= $total_clientes ?></h2>
                                    </div>
                                    <div class="text-success fs-1">
                                        <i class="bi bi-people"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card stat-card border-warning">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h6 class="text-muted">Total de Vendas</h6>
                                        <h2><?= $total_vendas ?></h2>
                                    </div>
                                    <div class="text-warning fs-1">
                                        <i class="bi bi-cart-check"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card stat-card border-info">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h6 class="text-muted">Valor em Estoque</h6>
                                        <h2>R$ <?= number_format($valor_estoque, 2, ',', '.') ?></h2>
                                    </div>
                                    <div class="text-info fs-1">
                                        <i class="bi bi-cash-stack"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Informações Adicionais -->
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <i class="bi bi-info-circle"></i> Bem-vindo ao Sistema ERP
                            </div>
                            <div class="card-body">
                                <h5>Olá, <?= htmlspecialchars($_SESSION['nome']) ?>!</h5>
                                <p>Este é seu painel de controle. Aqui você pode gerenciar todos os aspectos do seu negócio.</p>
                                <ul>
                                    <li>Cadastre e gerencie clientes</li>
                                    <li>Controle seu estoque de produtos</li>
                                    <li>Registre vendas e acompanhe o faturamento</li>
                                    <li>Gere relatórios detalhados</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header bg-success text-white">
                                <i class="bi bi-graph-up"></i> Atalhos Rápidos
                            </div>
                            <div class="card-body">
                                <div class="d-grid gap-2">
                                    <a href="clientes.php" class="btn btn-outline-primary">
                                        <i class="bi bi-person-plus"></i> Cadastrar Novo Cliente
                                    </a>
                                    <a href="produtos.php" class="btn btn-outline-success">
                                        <i class="bi bi-box"></i> Cadastrar Novo Produto
                                    </a>
                                    <a href="vendas.php" class="btn btn-outline-warning">
                                        <i class="bi bi-cart-plus"></i> Registrar Nova Venda
                                    </a>
                                    <a href="relatorios.php" class="btn btn-outline-info">
                                        <i class="bi bi-file-text"></i> Ver Relatórios
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
