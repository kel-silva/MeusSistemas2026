<?php
require_once 'config.php';

$erro = '';

// Processar login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = sanitize($_POST['email']);
    $senha = $_POST['senha'];

    $pdo = getConnection();
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    $usuario = $stmt->fetch();

    if ($usuario && password_verify($senha, $usuario['senha'])) {
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['nome'] = $usuario['nome'];
        $_SESSION['email'] = $usuario['email'];
        $_SESSION['tipo'] = $usuario['tipo'];

        // Redirecionar baseado no tipo de usuário
        if ($usuario['tipo'] === 'admin') {
            header('Location: admin.php');
        } else {
            header('Location: dashboard.php');
        }
        exit;
    } else {
        $erro = 'Email ou senha inválidos.';
    }
}

// Login master removido - use o usuário admin padrão do banco de dados
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ERP - Sistema de Gestão Empresarial</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-container {
            max-width: 450px;
            width: 100%;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .btn-admin {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            border: none;
            color: white;
            display: none;
        }
        .btn-admin.visible {
            display: block;
        }
        .btn-admin:hover {
            background: linear-gradient(135deg, #f5576c 0%, #f093fb 100%);
            color: white;
        }
        .admin-section {
            display: none;
            border-top: 2px solid #dee2e6;
            margin-top: 20px;
            padding-top: 20px;
        }
        .admin-section.visible {
            display: block;
        }
    </style>
</head>
<body>
    <div class="container login-container">
        <div class="text-center mb-4">
            <h1 class="text-white"><i class="bi bi-diagram-3"></i> Sistema ERP</h1>
            <p class="text-white">Gestão Empresarial Completa</p>
        </div>

        <?php if ($erro): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle"></i> <?= $erro ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-5">
                <!-- Login Normal -->
                <h3 class="mb-4"><i class="bi bi-box-arrow-in-right"></i> Login</h3>
                <form method="POST" id="formLoginNormal">
                    <div class="mb-3">
                        <label class="form-label">Email <span class="text-danger">*</span></label>
                        <input type="email" name="email" id="email" class="form-control"
                               placeholder="seu@email.com" required autofocus accesskey="e">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Senha <span class="text-danger">*</span></label>
                        <input type="password" name="senha" id="senha" class="form-control"
                               placeholder="••••••••" required accesskey="s">
                    </div>
                    <button type="submit" name="login" class="btn btn-primary w-100" accesskey="n">
                        <i class="bi bi-box-arrow-in-right"></i> E<u>n</u>trar
                    </button>
                </form>

                <!-- Seção Admin - Oculta por padrão -->
                <div class="admin-section" id="adminSection">
                    <h5 class="text-danger mb-3">
                        <i class="bi bi-shield-lock"></i> Acesso Administrativo
                    </h5>
                    <form method="POST" id="formLoginAdmin">
                        <div class="mb-3">
                            <label class="form-label">Email Admin</label>
                            <input type="email" name="email_admin" id="emailAdmin"
                                   class="form-control" placeholder="admin@sistema.com" accesskey="a">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Senha Admin</label>
                            <input type="password" name="senha_admin" id="senhaAdmin"
                                   class="form-control" placeholder="••••••••" accesskey="d">
                        </div>
                        <button type="submit" name="login_admin" class="btn btn-admin w-100 visible" accesskey="m">
                            <i class="bi bi-shield-lock"></i> Entrar como Ad<u>m</u>inistrador
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="text-center mt-4">
            <p class="text-white-50">© 2024 Sistema ERP - Todos os direitos reservados</p>
            <small class="text-white-50" id="adminHint" style="display:none;">
                Pressione Ctrl+L para acessar o painel administrativo
            </small>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Detectar Ctrl+L para mostrar login admin
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.key === 'l') {
                e.preventDefault();
                const adminSection = document.getElementById('adminSection');
                const adminHint = document.getElementById('adminHint');

                if (adminSection.classList.contains('visible')) {
                    adminSection.classList.remove('visible');
                    adminHint.style.display = 'none';
                } else {
                    adminSection.classList.add('visible');
                    adminHint.style.display = 'block';
                    document.getElementById('emailAdmin').focus();
                }
            }
        });

        // Navegação por teclado
        document.addEventListener('keydown', function(e) {
            // Enter no último campo submete o formulário ativo
            if (e.key === 'Enter') {
                const activeElement = document.activeElement;
                if (activeElement && activeElement.form) {
                    activeElement.form.submit();
                }
            }
        });
    </script>
</body>
</html>
