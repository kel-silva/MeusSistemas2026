<?php
require_once 'config.php';
verificarLogin();

$pdo = getConnection();
$mensagem = '';

// Processar cadastro/edição
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['salvar'])) {
    $nome = sanitize($_POST['nome']);
    $descricao = sanitize($_POST['descricao']);
    $preco = floatval($_POST['preco']);
    $quantidade = intval($_POST['quantidade']);

    if (isset($_POST['id']) && !empty($_POST['id'])) {
        // Atualizar
        $stmt = $pdo->prepare("UPDATE produtos SET nome = ?, descricao = ?, preco = ?, quantidade = ?
                              WHERE id = ?");
        $stmt->execute([$nome, $descricao, $preco, $quantidade, $_POST['id']]);
        $mensagem = 'Produto atualizado com sucesso!';
    } else {
        // Inserir
        $stmt = $pdo->prepare("INSERT INTO produtos (nome, descricao, preco, quantidade)
                              VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$nome, $descricao, $preco, $quantidade]);
        $mensagem = 'Produto cadastrado com sucesso!';
    }
}

// Processar movimentação de estoque
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['movimentar'])) {
    $produto_id = intval($_POST['produto_id']);
    $tipo = $_POST['tipo']; // entrada ou saida
    $qtd = intval($_POST['quantidade_mov']);

    $stmt = $pdo->prepare("SELECT quantidade FROM produtos WHERE id = ?");
    $stmt->execute([$produto_id]);
    $produto = $stmt->fetch();

    if ($produto) {
        if ($tipo === 'entrada') {
            $nova_qtd = $produto['quantidade'] + $qtd;
        } else {
            $nova_qtd = $produto['quantidade'] - $qtd;
            if ($nova_qtd < 0) {
                $mensagem = 'Erro: Quantidade insuficiente em estoque!';
                $nova_qtd = $produto['quantidade'];
            }
        }

        if (empty($mensagem)) {
            $stmt = $pdo->prepare("UPDATE produtos SET quantidade = ? WHERE id = ?");
            $stmt->execute([$nova_qtd, $produto_id]);
            $mensagem = 'Estoque atualizado com sucesso!';
        }
    }
}

// Processar exclusão
if (isset($_GET['deletar'])) {
    $stmt = $pdo->prepare("DELETE FROM produtos WHERE id = ?");
    $stmt->execute([$_GET['deletar']]);
    $mensagem = 'Produto excluído com sucesso!';
}

// Buscar produto para edição
$produto_editar = null;
if (isset($_GET['editar'])) {
    $stmt = $pdo->prepare("SELECT * FROM produtos WHERE id = ?");
    $stmt->execute([$_GET['editar']]);
    $produto_editar = $stmt->fetch();
}

// Listar produtos
$stmt = $pdo->prepare("SELECT * FROM produtos ORDER BY nome");
$stmt->execute([$empresa_id]);
$produtos = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos - ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
        }
        .sidebar a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        .estoque-baixo {
            background-color: #fff3cd;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 p-0 sidebar">
                <div class="p-4 text-white">
                    <h4><i class="bi bi-diagram-3"></i> ERP</h4>
                </div>
                <nav>
                    <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
                    <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
                    <a href="produtos.php" class="active"><i class="bi bi-box-seam"></i> Produtos</a>
                    <a href="vendas.php"><i class="bi bi-cart-check"></i> Vendas</a>
                    <a href="relatorios.php"><i class="bi bi-file-earmark-text"></i> Relatórios</a>
                    <hr class="text-white">
                    <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Sair</a>
                </nav>
            </div>

            <!-- Conteúdo Principal -->
            <div class="col-md-10 p-4">
                <h2 class="mb-4"><i class="bi bi-box-seam"></i> Gerenciar Produtos e Estoque</h2>

                <?php if ($mensagem): ?>
                    <div class="alert alert-<?= strpos($mensagem, 'Erro') !== false ? 'danger' : 'success' ?> alert-dismissible fade show">
                        <?= $mensagem ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Formulário -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <i class="bi bi-box"></i> <?= $produto_editar ? 'Editar' : 'Novo' ?> Produto
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <?php if ($produto_editar): ?>
                                <input type="hidden" name="id" value="<?= $produto_editar['id'] ?>">
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Nome *</label>
                                    <input type="text" name="nome" class="form-control"
                                           value="<?= $produto_editar['nome'] ?? '' ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Preço (R$) *</label>
                                    <input type="number" name="preco" class="form-control" step="0.01"
                                           value="<?= $produto_editar['preco'] ?? '0.00' ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Quantidade em Estoque *</label>
                                    <input type="number" name="quantidade" class="form-control"
                                           value="<?= $produto_editar['quantidade'] ?? '0' ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Descrição</label>
                                    <input type="text" name="descricao" class="form-control"
                                           value="<?= $produto_editar['descricao'] ?? '' ?>">
                                </div>
                            </div>
                            <button type="submit" name="salvar" class="btn btn-success">
                                <i class="bi bi-check-circle"></i> <?= $produto_editar ? 'Atualizar' : 'Cadastrar' ?>
                            </button>
                            <?php if ($produto_editar): ?>
                                <a href="produtos.php" class="btn btn-secondary">
                                    <i class="bi bi-x-circle"></i> Cancelar
                                </a>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>

                <!-- Lista de Produtos -->
                <div class="card">
                    <div class="card-header bg-secondary text-white">
                        <i class="bi bi-list"></i> Lista de Produtos (<?= count($produtos) ?>)
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Nome</th>
                                        <th>Descrição</th>
                                        <th>Preço</th>
                                        <th>Quantidade</th>
                                        <th>Total</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($produtos as $produto): ?>
                                        <tr class="<?= $produto['quantidade'] < 10 ? 'estoque-baixo' : '' ?>">
                                            <td><?= $produto['id'] ?></td>
                                            <td><?= htmlspecialchars($produto['nome']) ?></td>
                                            <td><?= htmlspecialchars($produto['descricao']) ?></td>
                                            <td>R$ <?= number_format($produto['preco'], 2, ',', '.') ?></td>
                                            <td>
                                                <?= $produto['quantidade'] ?>
                                                <?php if ($produto['quantidade'] < 10): ?>
                                                    <i class="bi bi-exclamation-triangle text-warning" title="Estoque baixo"></i>
                                                <?php endif; ?>
                                            </td>
                                            <td>R$ <?= number_format($produto['preco'] * $produto['quantidade'], 2, ',', '.') ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-info" data-bs-toggle="modal"
                                                        data-bs-target="#modalEstoque<?= $produto['id'] ?>">
                                                    <i class="bi bi-arrow-left-right"></i>
                                                </button>
                                                <a href="?editar=<?= $produto['id'] ?>" class="btn btn-sm btn-warning">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <a href="?deletar=<?= $produto['id'] ?>"
                                                   class="btn btn-sm btn-danger"
                                                   onclick="return confirm('Deseja realmente excluir este produto?')">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </td>
                                        </tr>

                                        <!-- Modal Movimentação Estoque -->
                                        <div class="modal fade" id="modalEstoque<?= $produto['id'] ?>" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Movimentar Estoque</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <form method="POST">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="produto_id" value="<?= $produto['id'] ?>">
                                                            <p><strong>Produto:</strong> <?= htmlspecialchars($produto['nome']) ?></p>
                                                            <p><strong>Estoque atual:</strong> <?= $produto['quantidade'] ?></p>
                                                            <div class="mb-3">
                                                                <label class="form-label">Tipo de Movimentação</label>
                                                                <select name="tipo" class="form-select" required>
                                                                    <option value="entrada">Entrada</option>
                                                                    <option value="saida">Saída</option>
                                                                </select>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">Quantidade</label>
                                                                <input type="number" name="quantidade_mov" class="form-control" min="1" required>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                            <button type="submit" name="movimentar" class="btn btn-primary">Confirmar</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                    <?php if (empty($produtos)): ?>
                                        <tr>
                                            <td colspan="7" class="text-center text-muted">
                                                Nenhum produto cadastrado
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
