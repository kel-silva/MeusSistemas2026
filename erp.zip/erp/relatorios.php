<?php
require_once 'config.php';
verificarLogin();

$pdo = getConnection();

// Filtros
$data_inicio = $_GET['data_inicio'] ?? date('Y-m-01');
$data_fim = $_GET['data_fim'] ?? date('Y-m-d');

// Buscar vendas do período
$stmt = $pdo->prepare("SELECT v.*, c.nome as cliente_nome
                      FROM vendas v
                      INNER JOIN clientes c ON v.cliente_id = c.id
                      WHERE v.empresa_id = ? AND DATE(v.data) BETWEEN ? AND ?
                      ORDER BY v.data DESC");
$stmt->execute([$data_inicio, $data_fim]);
$vendas = $stmt->fetchAll();

// Calcular totais
$total_vendido = 0;
$quantidade_vendas = count($vendas);
foreach ($vendas as $venda) {
    $total_vendido += $venda['total'];
}

// Produto mais vendido
$stmt = $pdo->prepare("SELECT p.nome, SUM(iv.quantidade) as total_vendido
                      FROM itens_venda iv
                      INNER JOIN produtos p ON iv.produto_id = p.id
                      INNER JOIN vendas v ON iv.venda_id = v.id
                      WHERE iv.empresa_id = ? AND DATE(v.data) BETWEEN ? AND ?
                      GROUP BY p.id
                      ORDER BY total_vendido DESC
                      LIMIT 1");
$stmt->execute([$data_inicio, $data_fim]);
$produto_mais_vendido = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios - ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
        }
        .sidebar a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        @media print {
            .sidebar, .no-print {
                display: none !important;
            }
            .col-md-10 {
                width: 100% !important;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 p-0 sidebar">
                <div class="p-4 text-white">
                    <h4><i class="bi bi-diagram-3"></i> ERP</h4>
                </div>
                <nav>
                    <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
                    <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
                    <a href="produtos.php"><i class="bi bi-box-seam"></i> Produtos</a>
                    <a href="vendas.php"><i class="bi bi-cart-check"></i> Vendas</a>
                    <a href="relatorios.php" class="active"><i class="bi bi-file-earmark-text"></i> Relatórios</a>
                    <hr class="text-white">
                    <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Sair</a>
                </nav>
            </div>

            <!-- Conteúdo Principal -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="bi bi-file-earmark-text"></i> Relatório de Vendas</h2>
                    <button onclick="window.print()" class="btn btn-primary no-print">
                        <i class="bi bi-printer"></i> Imprimir
                    </button>
                </div>

                <!-- Filtros -->
                <div class="card mb-4 no-print">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Data Início</label>
                                <input type="date" name="data_inicio" class="form-control"
                                       value="<?= $data_inicio ?>" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Data Fim</label>
                                <input type="date" name="data_fim" class="form-control"
                                       value="<?= $data_fim ?>" required>
                            </div>
                            <div class="col-md-4 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="bi bi-search"></i> Filtrar
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Resumo -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="card border-primary">
                            <div class="card-body text-center">
                                <h6 class="text-muted">Total de Vendas</h6>
                                <h2><?= $quantidade_vendas ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-success">
                            <div class="card-body text-center">
                                <h6 class="text-muted">Total Vendido</h6>
                                <h2>R$ <?= number_format($total_vendido, 2, ',', '.') ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-warning">
                            <div class="card-body text-center">
                                <h6 class="text-muted">Ticket Médio</h6>
                                <h2>R$ <?= $quantidade_vendas > 0 ? number_format($total_vendido / $quantidade_vendas, 2, ',', '.') : '0,00' ?></h2>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if ($produto_mais_vendido): ?>
                <div class="alert alert-info">
                    <i class="bi bi-star"></i> <strong>Produto Mais Vendido:</strong>
                    <?= htmlspecialchars($produto_mais_vendido['nome']) ?>
                    (<?= $produto_mais_vendido['total_vendido'] ?> unidades)
                </div>
                <?php endif; ?>

                <!-- Tabela de Vendas -->
                <div class="card">
                    <div class="card-header bg-secondary text-white">
                        <i class="bi bi-table"></i> Detalhamento de Vendas
                        <small>(<?= date('d/m/Y', strtotime($data_inicio)) ?> até <?= date('d/m/Y', strtotime($data_fim)) ?>)</small>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Data/Hora</th>
                                        <th>Cliente</th>
                                        <th>Total</th>
                                        <th class="no-print">Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($vendas as $venda): ?>
                                        <tr>
                                            <td><?= $venda['id'] ?></td>
                                            <td><?= date('d/m/Y H:i', strtotime($venda['data'])) ?></td>
                                            <td><?= htmlspecialchars($venda['cliente_nome']) ?></td>
                                            <td>R$ <?= number_format($venda['total'], 2, ',', '.') ?></td>
                                            <td class="no-print">
                                                <button class="btn btn-sm btn-info" data-bs-toggle="modal"
                                                        data-bs-target="#modalDetalhes<?= $venda['id'] ?>">
                                                    <i class="bi bi-eye"></i> Ver Itens
                                                </button>
                                            </td>
                                        </tr>

                                        <!-- Modal Detalhes -->
                                        <div class="modal fade" id="modalDetalhes<?= $venda['id'] ?>" tabindex="-1">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Detalhes da Venda #<?= $venda['id'] ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p><strong>Cliente:</strong> <?= htmlspecialchars($venda['cliente_nome']) ?></p>
                                                        <p><strong>Data:</strong> <?= date('d/m/Y H:i', strtotime($venda['data'])) ?></p>

                                                        <h6>Produtos:</h6>
                                                        <table class="table table-sm">
                                                            <thead>
                                                                <tr>
                                                                    <th>Produto</th>
                                                                    <th>Quantidade</th>
                                                                    <th>Preço Unit.</th>
                                                                    <th>Subtotal</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php
                                                                $stmt_itens = $pdo->prepare("SELECT iv.*, p.nome
                                                                                            FROM itens_venda iv
                                                                                            INNER JOIN produtos p ON iv.produto_id = p.id
                                                                                            WHERE iv.venda_id = ? AND iv.empresa_id = ?");
                                                                $stmt_itens->execute([$venda['id']]);
                                                                $itens = $stmt_itens->fetchAll();

                                                                foreach ($itens as $item):
                                                                ?>
                                                                    <tr>
                                                                        <td><?= htmlspecialchars($item['nome']) ?></td>
                                                                        <td><?= $item['quantidade'] ?></td>
                                                                        <td>R$ <?= number_format($item['preco'], 2, ',', '.') ?></td>
                                                                        <td>R$ <?= number_format($item['preco'] * $item['quantidade'], 2, ',', '.') ?></td>
                                                                    </tr>
                                                                <?php endforeach; ?>
                                                            </tbody>
                                                            <tfoot>
                                                                <tr>
                                                                    <th colspan="3">Total</th>
                                                                    <th>R$ <?= number_format($venda['total'], 2, ',', '.') ?></th>
                                                                </tr>
                                                            </tfoot>
                                                        </table>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                    <?php if (empty($vendas)): ?>
                                        <tr>
                                            <td colspan="5" class="text-center text-muted">
                                                Nenhuma venda encontrada no período
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                                <tfoot>
                                    <tr class="fw-bold">
                                        <td colspan="3">TOTAL GERAL</td>
                                        <td>R$ <?= number_format($total_vendido, 2, ',', '.') ?></td>
                                        <td class="no-print"></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
