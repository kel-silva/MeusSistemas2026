-- ===============================================================
-- Script de Atualização do Banco de Dados ERP
-- Adiciona o campo 'login' na tabela usuarios
-- Compatível com SQLite
-- ===============================================================

-- ATENÇÃO: Este script é executado automaticamente pelo sistema!
-- Você NÃO precisa executar manualmente este arquivo SQL.
--
-- O arquivo config.php foi atualizado para verificar e criar
-- automaticamente a coluna 'login' quando necessário.
--
-- Basta substituir os arquivos e acessar o sistema.

-- ===============================================================
-- PARA EXECUÇÃO MANUAL (se necessário):
-- ===============================================================

-- 1. Adicionar coluna 'login' na tabela usuarios (se não existir)
-- ALTER TABLE usuarios ADD COLUMN login TEXT UNIQUE;

-- 2. Preencher login baseado no email (parte antes do @)
-- UPDATE usuarios
-- SET login = SUBSTR(email, 1, INSTR(email, '@') - 1)
-- WHERE login IS NULL OR login = '';

-- 3. Verificar os dados
-- SELECT id, nome, login, email FROM usuarios;

-- ===============================================================
-- OBSERVAÇÕES:
-- ===============================================================
-- - O sistema usa SQLite, não MySQL
-- - A atualização é feita automaticamente pelo config.php
-- - Logins são criados baseados no email (texto antes do @)
-- - Exemplos:
--   Email: joao@empresa.com  →  Login: joao
--   Email: maria.silva@teste.com  →  Login: maria.silva
-- ===============================================================
