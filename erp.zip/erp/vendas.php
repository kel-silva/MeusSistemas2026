<?php
require_once 'config.php';
verificarLogin();

$pdo = getConnection();
$mensagem = '';

// Processar nova venda
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['finalizar_venda'])) {
    $cliente_id = intval($_POST['cliente_id']);
    $produtos_venda = $_POST['produtos'] ?? [];
    $quantidades = $_POST['quantidades'] ?? [];

    if (empty($produtos_venda)) {
        $mensagem = 'Erro: Selecione pelo menos um produto!';
    } else {
        try {
            $pdo->beginTransaction();

            $total_venda = 0;

            // Verificar estoque e calcular total
            foreach ($produtos_venda as $index => $produto_id) {
                $quantidade = intval($quantidades[$index]);

                $stmt = $pdo->prepare("SELECT preco, quantidade FROM produtos WHERE id = ?");
                $stmt->execute([$produto_id]);
                $produto = $stmt->fetch();

                if (!$produto) {
                    throw new Exception("Produto não encontrado!");
                }

                if ($produto['quantidade'] < $quantidade) {
                    throw new Exception("Estoque insuficiente para o produto ID: $produto_id");
                }

                $total_venda += $produto['preco'] * $quantidade;
            }

            // Criar venda
            $stmt = $pdo->prepare("INSERT INTO vendas (cliente_id, total) VALUES (?, ?, ?)");
            $stmt->execute([$cliente_id, $total_venda]);
            $venda_id = $pdo->lastInsertId();

            // Inserir itens e atualizar estoque
            foreach ($produtos_venda as $index => $produto_id) {
                $quantidade = intval($quantidades[$index]);

                $stmt = $pdo->prepare("SELECT preco, quantidade FROM produtos WHERE id = ?");
                $stmt->execute([$produto_id]);
                $produto = $stmt->fetch();

                // Inserir item da venda
                $stmt = $pdo->prepare("INSERT INTO itens_venda (venda_id, produto_id, quantidade, preco)
                                      VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$venda_id, $produto_id, $quantidade, $produto['preco']]);

                // Atualizar estoque
                $nova_quantidade = $produto['quantidade'] - $quantidade;
                $stmt = $pdo->prepare("UPDATE produtos SET quantidade = ? WHERE id = ?");
                $stmt->execute([$nova_quantidade, $produto_id]);
            }

            $pdo->commit();
            $mensagem = "Venda realizada com sucesso! Total: R$ " . number_format($total_venda, 2, ',', '.');
        } catch (Exception $e) {
            $pdo->rollBack();
            $mensagem = "Erro: " . $e->getMessage();
        }
    }
}

// Buscar clientes
$stmt = $pdo->prepare("SELECT * FROM clientes ORDER BY nome");
$stmt->execute([$empresa_id]);
$clientes = $stmt->fetchAll();

// Buscar produtos
$stmt = $pdo->prepare("SELECT * FROM produtos AND quantidade > 0 ORDER BY nome");
$stmt->execute([$empresa_id]);
$produtos = $stmt->fetchAll();

// Buscar últimas vendas
$stmt = $pdo->prepare("SELECT v.*, c.nome as cliente_nome FROM vendas v
                      INNER JOIN clientes c ON v.cliente_id = c.id
                      WHERE v.empresa_id = ? ORDER BY v.data DESC LIMIT 10");
$stmt->execute([$empresa_id]);
$ultimas_vendas = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendas - ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
        }
        .sidebar a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        .produto-item {
            border: 1px solid #dee2e6;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 p-0 sidebar">
                <div class="p-4 text-white">
                    <h4><i class="bi bi-diagram-3"></i> ERP</h4>
                </div>
                <nav>
                    <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
                    <a href="clientes.php"><i class="bi bi-people"></i> Clientes</a>
                    <a href="produtos.php"><i class="bi bi-box-seam"></i> Produtos</a>
                    <a href="vendas.php" class="active"><i class="bi bi-cart-check"></i> Vendas</a>
                    <a href="relatorios.php"><i class="bi bi-file-earmark-text"></i> Relatórios</a>
                    <hr class="text-white">
                    <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Sair</a>
                </nav>
            </div>

            <!-- Conteúdo Principal -->
            <div class="col-md-10 p-4">
                <h2 class="mb-4"><i class="bi bi-cart-check"></i> Registrar Venda</h2>

                <?php if ($mensagem): ?>
                    <div class="alert alert-<?= strpos($mensagem, 'Erro') !== false ? 'danger' : 'success' ?> alert-dismissible fade show">
                        <?= $mensagem ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <!-- Formulário de Venda -->
                    <div class="col-md-7">
                        <div class="card mb-4">
                            <div class="card-header bg-primary text-white">
                                <i class="bi bi-cart-plus"></i> Nova Venda
                            </div>
                            <div class="card-body">
                                <form method="POST" id="formVenda">
                                    <div class="mb-3">
                                        <label class="form-label">Cliente *</label>
                                        <select name="cliente_id" class="form-select" required>
                                            <option value="">Selecione um cliente</option>
                                            <?php foreach ($clientes as $cliente): ?>
                                                <option value="<?= $cliente['id'] ?>">
                                                    <?= htmlspecialchars($cliente['nome']) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Produtos *</label>
                                        <div id="produtos-container">
                                            <div class="produto-item">
                                                <div class="row">
                                                    <div class="col-8">
                                                        <select name="produtos[]" class="form-select produto-select" required>
                                                            <option value="">Selecione um produto</option>
                                                            <?php foreach ($produtos as $produto): ?>
                                                                <option value="<?= $produto['id'] ?>"
                                                                        data-preco="<?= $produto['preco'] ?>"
                                                                        data-estoque="<?= $produto['quantidade'] ?>">
                                                                    <?= htmlspecialchars($produto['nome']) ?> - R$ <?= number_format($produto['preco'], 2, ',', '.') ?>
                                                                    (Estoque: <?= $produto['quantidade'] ?>)
                                                                </option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-4">
                                                        <input type="number" name="quantidades[]" class="form-control"
                                                               placeholder="Qtd" min="1" value="1" required>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <button type="button" class="btn btn-sm btn-outline-primary" onclick="adicionarProduto()">
                                            <i class="bi bi-plus-circle"></i> Adicionar Produto
                                        </button>
                                    </div>

                                    <div class="d-grid">
                                        <button type="submit" name="finalizar_venda" class="btn btn-success btn-lg">
                                            <i class="bi bi-check-circle"></i> Finalizar Venda
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Últimas Vendas -->
                    <div class="col-md-5">
                        <div class="card">
                            <div class="card-header bg-success text-white">
                                <i class="bi bi-clock-history"></i> Últimas Vendas
                            </div>
                            <div class="card-body">
                                <?php if (empty($ultimas_vendas)): ?>
                                    <p class="text-muted text-center">Nenhuma venda realizada</p>
                                <?php else: ?>
                                    <div class="list-group">
                                        <?php foreach ($ultimas_vendas as $venda): ?>
                                            <div class="list-group-item">
                                                <div class="d-flex justify-content-between">
                                                    <strong>#<?= $venda['id'] ?> - <?= htmlspecialchars($venda['cliente_nome']) ?></strong>
                                                    <span class="badge bg-success">R$ <?= number_format($venda['total'], 2, ',', '.') ?></span>
                                                </div>
                                                <small class="text-muted">
                                                    <?= date('d/m/Y H:i', strtotime($venda['data'])) ?>
                                                </small>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let produtoIndex = 1;

        function adicionarProduto() {
            const container = document.getElementById('produtos-container');
            const novoProduto = `
                <div class="produto-item">
                    <div class="row">
                        <div class="col-8">
                            <select name="produtos[]" class="form-select produto-select" required>
                                <option value="">Selecione um produto</option>
                                <?php foreach ($produtos as $produto): ?>
                                    <option value="<?= $produto['id'] ?>"
                                            data-preco="<?= $produto['preco'] ?>"
                                            data-estoque="<?= $produto['quantidade'] ?>">
                                        <?= htmlspecialchars($produto['nome']) ?> - R$ <?= number_format($produto['preco'], 2, ',', '.') ?>
                                        (Estoque: <?= $produto['quantidade'] ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-3">
                            <input type="number" name="quantidades[]" class="form-control"
                                   placeholder="Qtd" min="1" value="1" required>
                        </div>
                        <div class="col-1">
                            <button type="button" class="btn btn-danger btn-sm" onclick="this.parentElement.parentElement.parentElement.remove()">
                                <i class="bi bi-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', novoProduto);
        }
    </script>
</body>
</html>
