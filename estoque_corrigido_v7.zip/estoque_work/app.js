// API Base URL
const API_URL = 'api.php';
let chartLucro = null;
let chartMovimentacoes = null;
let chartTopProdutos = null;

// =============================================
// FUNÇÃO DE NOTIFICAÇÃO (toast) - GLOBAL
// =============================================
function mostrarNotificacao(mensagem, tipo) {
    tipo = tipo || 'success';
    var antigas = document.querySelectorAll('.notificacao-toast');
    antigas.forEach(function(n) { n.remove(); });

    var toast = document.createElement('div');
    toast.className = 'notificacao-toast';

    var cores = {
        success: { bg: '#28a745', icon: '✅' },
        error:   { bg: '#dc3545', icon: '❌' },
        warning: { bg: '#ffc107', icon: '⚠️' },
        info:    { bg: '#17a2b8', icon: 'ℹ️' }
    };
    var cor = cores[tipo] || cores.success;

    toast.style.cssText = 'position:fixed;top:20px;right:20px;background:' + cor.bg + ';color:#fff;padding:14px 20px;border-radius:8px;box-shadow:0 4px 15px rgba(0,0,0,0.3);z-index:99999;font-size:15px;font-weight:600;max-width:380px;display:flex;align-items:center;gap:10px;animation:slideInRight 0.3s ease;';

    if (!document.getElementById('toast-style')) {
        var style = document.createElement('style');
        style.id = 'toast-style';
        style.textContent = '@keyframes slideInRight{from{transform:translateX(120%);opacity:0}to{transform:translateX(0);opacity:1}}@keyframes slideOutRight{from{transform:translateX(0);opacity:1}to{transform:translateX(120%);opacity:0}}';
        document.head.appendChild(style);
    }

    toast.innerHTML = '<span>' + cor.icon + '</span><span>' + mensagem + '</span>';
    document.body.appendChild(toast);

    setTimeout(function() {
        toast.style.animation = 'slideOutRight 0.3s ease forwards';
        setTimeout(function() { toast.remove(); }, 300);
    }, 3500);
}
// =============================================

let appInicializado = false;

// Aguardar autenticação antes de inicializar
function inicializarApp() {
    if (appInicializado) {
        return;
    }
    appInicializado = true;

    // Configurar datas padrão (último mês) apenas se os elementos existirem
    const hoje = new Date();
    const mesPassado = new Date(hoje.getFullYear(), hoje.getMonth() - 1, hoje.getDate());

    const dataInicio = document.getElementById('dataInicio');
    const dataFim = document.getElementById('dataFim');
    const movDataInicio = document.getElementById('movDataInicio');
    const movDataFim = document.getElementById('movDataFim');

    if (dataInicio) dataInicio.valueAsDate = mesPassado;
    if (dataFim) dataFim.valueAsDate = hoje;
    if (movDataInicio) movDataInicio.valueAsDate = mesPassado;
    if (movDataFim) movDataFim.valueAsDate = hoje;

    // Inicializar máscaras de dinheiro
    inicializarMascarasDinheiro();

    // Carregar dados APENAS após autenticação completa
    carregarDashboard();
    carregarCategorias();
    carregarProdutos();
    carregarClientes();
    carregarFornecedores();
    carregarEstoqueBaixo();
}

// NÃO inicializar automaticamente - aguardar chamada do auth-app.js
// A inicialização será feita APENAS quando a autenticação estiver completa

// NAVEGAÇÃO
function showSection(section) {
    // Verificar permissão (se a função existir do auth-app.js)
    if (typeof verificarPermissaoSecao === 'function' && !verificarPermissaoSecao(section)) {
        alert('Você não tem permissão para acessar esta seção');
        return;
    }

    // Fechar sidebar automaticamente em dispositivos móveis
    if (window.innerWidth <= 768) {
        document.getElementById('sidebar').classList.remove('active');
        const overlay = document.getElementById('sidebarOverlay');
        if (overlay) overlay.classList.remove('active');
    }

    // Remover active de todas as seções
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));

    // Ativar seção selecionada (sem prefixo 'section-')
    const sectionElement = document.getElementById(section);
    if (sectionElement) {
        sectionElement.classList.add('active');
    }

    // Ativar link do menu
    if (event && event.target) {
        event.target.closest('.nav-link').classList.add('active');
    }

    // Atualizar título
    const titles = {
        'dashboard': 'Dashboard',
        'produtos': 'Produtos',
        'movimentacoes': 'Movimentações',
        'clientes': 'Clientes',
        'fornecedores': 'Fornecedores',
        'alertas': 'Alertas de Estoque',
        'administracao': 'Administração'
    };
    document.getElementById('pageTitle').textContent = titles[section] || section;

    // Recarregar dados se necessário
    if (section === 'movimentacoes') {
        carregarMovimentacoes();
    } else if (section === 'administracao' && typeof carregarUsuarios === 'function') {
        carregarUsuarios();
        controlarBotoesBackup(); // Controlar visibilidade dos botões de backup/restore
    }
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    sidebar.classList.toggle('active');
    if (overlay) overlay.classList.toggle('active');
}

// DASHBOARD
async function carregarDashboard() {
    try {
        const response = await fetch(`${API_URL}?endpoint=dashboard_resumo`);
        const data = await response.json();

        if (document.getElementById('totalProdutos')) {
            document.getElementById('totalProdutos').textContent = data.total_produtos || 0;
        }
        if (document.getElementById('totalEntradas')) {
            document.getElementById('totalEntradas').textContent = data.total_entradas || 0;
        }
        if (document.getElementById('totalSaidas')) {
            document.getElementById('totalSaidas').textContent = data.total_saidas || 0;
        }
        if (document.getElementById('produtosBaixos')) {
            document.getElementById('produtosBaixos').textContent = data.produtos_estoque_baixo || 0;
        }
        if (document.getElementById('badgeAlertas')) {
            document.getElementById('badgeAlertas').textContent = data.produtos_estoque_baixo || 0;
        }

        // Carregar gráficos
        carregarGraficos();
    } catch (error) {
        console.error('Erro ao carregar dashboard:', error);
    }
}

// Carregar gráficos do dashboard
async function carregarGraficos() {
    try {
        // Gráfico de movimentações
        const responseMovimentacoes = await fetch(`${API_URL}?endpoint=dashboard_movimentacoes_mes`);
        const dataMovimentacoes = await responseMovimentacoes.json();

        const ctxMov = document.getElementById('chartMovimentacoes');
        if (ctxMov) {
            if (chartMovimentacoes) {
                chartMovimentacoes.destroy();
            }

            chartMovimentacoes = new Chart(ctxMov.getContext('2d'), {
                type: 'bar',
                data: {
                    labels: ['Entradas', 'Saídas'],
                    datasets: [{
                        label: 'Quantidade',
                        data: [dataMovimentacoes.entradas || 0, dataMovimentacoes.saidas || 0],
                        backgroundColor: [
                            'rgba(46, 204, 113, 0.6)',
                            'rgba(231, 76, 60, 0.6)'
                        ],
                        borderColor: [
                            'rgba(46, 204, 113, 1)',
                            'rgba(231, 76, 60, 1)'
                        ],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        // Gráfico de top produtos
        const responseTopProdutos = await fetch(`${API_URL}?endpoint=dashboard_top_produtos`);
        const dataTopProdutos = await responseTopProdutos.json();

        const ctxTop = document.getElementById('chartTopProdutos');
        if (ctxTop && dataTopProdutos.length > 0) {
            if (chartTopProdutos) {
                chartTopProdutos.destroy();
            }

            chartTopProdutos = new Chart(ctxTop.getContext('2d'), {
                type: 'doughnut',
                data: {
                    labels: dataTopProdutos.map(p => p.nome),
                    datasets: [{
                        data: dataTopProdutos.map(p => p.total_vendido),
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.6)',
                            'rgba(54, 162, 235, 0.6)',
                            'rgba(255, 206, 86, 0.6)',
                            'rgba(75, 192, 192, 0.6)',
                            'rgba(153, 102, 255, 0.6)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(153, 102, 255, 1)'
                        ],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }
    } catch (error) {
        console.error('Erro ao carregar gráficos:', error);
    }
}

async function atualizarGrafico() {
    const dataInicio = document.getElementById('dataInicio').value;
    const dataFim = document.getElementById('dataFim').value;

    try {
        const response = await fetch(`${API_URL}?endpoint=dashboard_lucro&data_inicio=${dataInicio}&data_fim=${dataFim}`);
        const data = await response.json();

        const labels = data.map(d => formatarData(d.data));
        const vendas = data.map(d => parseFloat(d.vendas || 0));
        const lucro = data.map(d => parseFloat(d.lucro || 0));

        const ctx = document.getElementById('chartLucro').getContext('2d');

        if (chartLucro) {
            chartLucro.destroy();
        }

        chartLucro = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Vendas',
                        data: vendas,
                        borderColor: '#3498db',
                        backgroundColor: 'rgba(52, 152, 219, 0.1)',
                        tension: 0.4,
                        fill: true
                    },
                    {
                        label: 'Lucro',
                        data: lucro,
                        borderColor: '#2ecc71',
                        backgroundColor: 'rgba(46, 204, 113, 0.1)',
                        tension: 0.4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += formatarMoeda(context.parsed.y);
                                return label;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'R$ ' + value.toFixed(2);
                            }
                        }
                    }
                }
            }
        });
    } catch (error) {
        console.error('Erro ao carregar gráfico:', error);
    }
}

// PRODUTOS
async function carregarCategorias() {
    try {
        const response = await fetch(`${API_URL}?endpoint=categorias`);
        const categorias = await response.json();

        const select = document.getElementById('produtoCategoria');
        select.innerHTML = '<option value="">Selecione...</option>';
        categorias.forEach(cat => {
            select.innerHTML += `<option value="${cat.id}">${cat.nome}</option>`;
        });
    } catch (error) {
        console.error('Erro ao carregar categorias:', error);
    }
}

async function carregarProdutos() {
    try {
        const response = await fetch(`${API_URL}?endpoint=produtos`);
        const produtos = await response.json();

        const tbody = document.getElementById('listaProdutos');
        tbody.innerHTML = '';

        if (produtos.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="8" class="empty-state">
                        <i class="fas fa-box-open"></i>
                        <p>Nenhum produto cadastrado</p>
                    </td>
                </tr>
            `;
            return;
        }

        produtos.forEach(produto => {
            const estoqueClass = produto.estoque_atual <= produto.estoque_minimo ? 'estoque-baixo' : 'estoque-ok';
            const estoqueText = produto.estoque_atual <= produto.estoque_minimo ?
                `${produto.estoque_atual} (BAIXO!)` : produto.estoque_atual;
            const descricaoSafe = (produto.descricao || '').replace(/"/g, '&quot;');

            tbody.innerHTML += `
                <tr data-descricao="${descricaoSafe}">
                    <td>
                        ${produto.foto ?
                            `<img src="${produto.foto}" class="produto-foto" alt="${produto.nome}">` :
                            `<div class="produto-foto" style="background: #ecf0f1; display: flex; align-items: center; justify-content: center;">
                                <i class="fas fa-image" style="color: #95a5a6;"></i>
                            </div>`
                        }
                    </td>
                    <td>${produto.codigo_barras || '-'}</td>
                    <td><strong>${produto.nome}</strong>${produto.descricao ? `<br><small style="color:#888;font-size:11px;">${produto.descricao.substring(0,60)}${produto.descricao.length>60?'...':''}</small>` : ''}</td>
                    <td>${produto.categoria_nome || '-'}</td>
                    <td><span class="estoque-badge ${estoqueClass}">${estoqueText}</span></td>
                    <td>${formatarMoeda(produto.preco_custo)}</td>
                    <td>${formatarMoeda(produto.preco_venda)}</td>
                    <td>
                        ${produto.estoque_atual <= produto.estoque_minimo ? `
                        <button class="btn btn-sm btn-repor" title="Repor Estoque" style="display:block;margin-bottom:5px;" onclick="abrirModalReposicao(${produto.id}, '${produto.nome.replace(/'/g,"\\'")}', ${produto.preco_custo}, ${produto.preco_venda})">
                            <i class="fas fa-cart-plus"></i> Repor
                        </button>` : ''}
                        <button class="btn btn-sm" style="background:#8e44ad;color:#fff;" onclick="verGraficoPrecos(${produto.id}, '${produto.nome.replace(/'/g,"\\'")}')">
                            <i class="fas fa-chart-line"></i>
                        </button>
                        <button class="btn btn-sm btn-primary" onclick="editarProduto(${produto.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="excluirProduto(${produto.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        });

        // Atualizar select de produtos para movimentação
        const selectProdutos = document.getElementById('movProduto');
        selectProdutos.innerHTML = '<option value="">Selecione...</option>';
        produtos.forEach(p => {
            selectProdutos.innerHTML += `<option value="${p.id}" data-preco-custo="${p.preco_custo}" data-preco-venda="${p.preco_venda}">${p.nome} (Estoque: ${p.estoque_atual})</option>`;
        });
    } catch (error) {
        console.error('Erro ao carregar produtos:', error);
    }
}

function filtrarProdutos() {
    const busca = document.getElementById('searchProduto').value.toLowerCase().trim();
    const linhas = document.querySelectorAll('#listaProdutos tr');

    linhas.forEach(linha => {
        const textoVisivel = linha.textContent.toLowerCase();
        const descricao = (linha.getAttribute('data-descricao') || '').toLowerCase();
        const encontrado = textoVisivel.includes(busca) || descricao.includes(busca);
        linha.style.display = encontrado ? '' : 'none';
    });
}

function abrirModalProduto(id = null) {
    document.getElementById('modalProdutoTitulo').textContent = id ? 'Editar Produto' : 'Novo Produto';

    // APENAS fazer reset se for NOVO produto (id null)
    if (!id) {
        document.getElementById('formProduto').reset();
        document.getElementById('previewProdutoFoto').style.display = 'none';
    }

    document.getElementById('produtoId').value = id || '';
    document.getElementById('modalProduto').classList.add('active');

    // Reinicializar máscaras de dinheiro após abrir o modal
    setTimeout(() => inicializarMascarasDinheiro(), 100);
}

async function editarProduto(id) {
    try {
        console.log('Editando produto ID:', id);
        const response = await fetch(`${API_URL}?endpoint=produtos&id=${id}`);

        if (!response.ok) {
            throw new Error('Erro na resposta da API: ' + response.status);
        }

        const produto = await response.json();
        console.log('Produto recebido:', produto);

        // Verificar se recebemos um produto válido
        if (!produto || !produto.id) {
            throw new Error('Produto não encontrado ou dados inválidos');
        }

        // Preencher campos do formulário
        document.getElementById('produtoId').value = produto.id;
        document.getElementById('produtoCodigoBarras').value = produto.codigo_barras || '';
        document.getElementById('produtoNome').value = produto.nome || '';
        document.getElementById('produtoDescricao').value = produto.descricao || '';
        document.getElementById('produtoCategoria').value = produto.categoria_id || '';
        document.getElementById('produtoFornecedor').value = produto.fornecedor_id || '';
        document.getElementById('produtoPrecoCusto').value = numero_para_dinheiro(produto.preco_custo || 0);
        document.getElementById('produtoPrecoVenda').value = numero_para_dinheiro(produto.preco_venda || 0);
        document.getElementById('produtoEstoqueAtual').value = produto.estoque_atual || 0;
        document.getElementById('produtoEstoqueMinimo').value = produto.estoque_minimo || 0;
        document.getElementById('produtoFotoPath').value = produto.foto || '';

        // Exibir foto se existir
        if (produto.foto) {
            const preview = document.getElementById('previewProdutoFoto');
            preview.src = produto.foto;
            preview.style.display = 'block';
        } else {
            document.getElementById('previewProdutoFoto').style.display = 'none';
        }

        // Abrir modal
        console.log('Abrindo modal...');
        abrirModalProduto(id);
    } catch (error) {
        console.error('Erro ao carregar produto:', error);
        alert('Erro ao carregar produto: ' + error.message);
    }
}

async function salvarProduto(event) {
    event.preventDefault();

    // Validar fornecedor obrigatório
    const fornecedor = document.getElementById('produtoFornecedor').value;
    if (!fornecedor) {
        alert('Por favor, selecione um fornecedor!');
        document.getElementById('produtoFornecedor').focus();
        return;
    }

    const id = document.getElementById('produtoId').value;
    let fotoPath = document.getElementById('produtoFotoPath').value;

    // Upload da foto se houver
    const fotoInput = document.getElementById('produtoFoto');
    if (fotoInput.files.length > 0) {
        const formData = new FormData();
        formData.append('foto', fotoInput.files[0]);

        try {
            const uploadResponse = await fetch('upload.php', {
                method: 'POST',
                body: formData
            });
            const uploadResult = await uploadResponse.json();

            if (uploadResult.success) {
                fotoPath = uploadResult.path;
            }
        } catch (error) {
            console.error('Erro ao fazer upload da foto:', error);
        }
    }

    const data = {
        id: id,
        codigo_barras: document.getElementById('produtoCodigoBarras').value,
        nome: document.getElementById('produtoNome').value,
        descricao: document.getElementById('produtoDescricao').value,
        categoria_id: document.getElementById('produtoCategoria').value || null,
        fornecedor_id: document.getElementById('produtoFornecedor').value || null,
        preco_custo: dinheiro_para_numero(document.getElementById('produtoPrecoCusto').value),
        preco_venda: dinheiro_para_numero(document.getElementById('produtoPrecoVenda').value),
        estoque_atual: parseInt(document.getElementById('produtoEstoqueAtual').value),
        estoque_minimo: parseInt(document.getElementById('produtoEstoqueMinimo').value),
        foto: fotoPath
    };

    try {
        const method = id ? 'PUT' : 'POST';
        const response = await fetch(`${API_URL}?endpoint=produtos`, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (result.success) {
            alert('Produto salvo com sucesso!');
            fecharModal('modalProduto');
            carregarProdutos();
            carregarDashboard();
        }
    } catch (error) {
        console.error('Erro ao salvar produto:', error);
        alert('Erro ao salvar produto!');
    }
}

async function excluirProduto(id) {
    if (!confirm('Deseja realmente excluir este produto?')) return;

    try {
        const response = await fetch(`${API_URL}?endpoint=produtos&id=${id}`, {
            method: 'DELETE'
        });

        const result = await response.json();

        if (result.success) {
            alert('Produto excluído com sucesso!');
            carregarProdutos();
            carregarDashboard();
        }
    } catch (error) {
        console.error('Erro ao excluir produto:', error);
        alert('Erro ao excluir produto!');
    }
}

function previewFoto(event) {
    const preview = document.getElementById('previewProdutoFoto');
    const file = event.target.files[0];

    if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            preview.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    }
}

function previewFotoFornecedor(event) {
    const preview = document.getElementById('previewFornecedorFoto');
    const file = event.target.files[0];

    if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            preview.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    }
}

// MOVIMENTAÇÕES
async function carregarMovimentacoes() {
    const dataInicio = document.getElementById('movDataInicio').value;
    const dataFim = document.getElementById('movDataFim').value;

    try {
        let url = `${API_URL}?endpoint=movimentacoes`;
        if (dataInicio && dataFim) {
            url += `&data_inicio=${dataInicio}&data_fim=${dataFim}`;
        }

        const response = await fetch(url);
        const movimentacoes = await response.json();

        const tbody = document.getElementById('listaMovimentacoes');
        tbody.innerHTML = '';

        if (movimentacoes.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="8" class="empty-state">
                        <i class="fas fa-exchange-alt"></i>
                        <p>Nenhuma movimentação encontrada</p>
                    </td>
                </tr>
            `;
            // Esconder totalizadores se não houver movimentações
            document.getElementById('totalizadoresMovimentacoes').style.display = 'none';
            return;
        }

        // Variáveis para calcular totais
        let totalEntradas = 0;
        let totalSaidas = 0;

        movimentacoes.forEach(mov => {
            const tipoClass = mov.tipo === 'entrada' ? 'tipo-entrada' : 'tipo-saida';
            const tipoText = mov.tipo === 'entrada' ? 'ENTRADA' : 'SAÍDA';
            const pessoa = mov.tipo === 'entrada' ? mov.fornecedor_nome : mov.cliente_nome;

            // Calcular totais - converter string para número corretamente
            let valorTotal = 0;
            if (typeof mov.valor_total === 'string') {
                // Remover "R$", espaços e trocar vírgula por ponto
                valorTotal = parseFloat(mov.valor_total.replace(/[R$\s]/g, '').replace(',', '.')) || 0;
            } else {
                valorTotal = parseFloat(mov.valor_total) || 0;
            }

            console.log('Tipo:', mov.tipo, 'Valor Total:', valorTotal, 'Original:', mov.valor_total);

            if (mov.tipo === 'entrada') {
                totalEntradas += valorTotal;
            } else if (mov.tipo === 'saida') {
                totalSaidas += valorTotal;
            }

            tbody.innerHTML += `
                <tr>
                    <td>${formatarDataHoraBrasil(mov.data_movimentacao)}</td>
                    <td><span class="tipo-badge ${tipoClass}">${tipoText}</span></td>
                    <td>${mov.produto_nome}</td>
                    <td>${mov.quantidade}</td>
                    <td>${formatarMoeda(mov.valor_unitario)}</td>
                    <td><strong>${formatarMoeda(mov.valor_total)}</strong></td>
                    <td>${pessoa || '-'}</td>
                    <td>
                        <button class="btn btn-sm btn-primary" onclick="editarMovimentacao(${mov.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="excluirMovimentacao(${mov.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        });

        // Calcular saldo (Lucro/Prejuízo)
        const saldo = totalSaidas - totalEntradas;

        console.log('Total Entradas:', totalEntradas);
        console.log('Total Saídas:', totalSaidas);
        console.log('Saldo:', saldo);

        // Atualizar totalizadores (usando IDs específicos de movimentações)
        const elemTotalEntradas = document.getElementById('movTotalEntradas');
        const elemTotalSaidas = document.getElementById('movTotalSaidas');
        const elemSaldoTotal = document.getElementById('movSaldoTotal');

        if (elemTotalEntradas) elemTotalEntradas.textContent = formatarMoeda(totalEntradas);
        if (elemTotalSaidas) elemTotalSaidas.textContent = formatarMoeda(totalSaidas);
        if (elemSaldoTotal) elemSaldoTotal.textContent = formatarMoeda(Math.abs(saldo));

        // Atualizar status do saldo
        const statusSaldo = document.getElementById('movStatusSaldo');
        const totalizadorSaldo = document.querySelector('.totalizador-saldo');

        if (saldo > 0) {
            statusSaldo.textContent = '✓ Lucro';
            statusSaldo.style.color = '#2ecc71';
            totalizadorSaldo.classList.remove('prejuizo');
            totalizadorSaldo.classList.add('lucro');
        } else if (saldo < 0) {
            statusSaldo.textContent = '✗ Prejuízo';
            statusSaldo.style.color = '#e74c3c';
            totalizadorSaldo.classList.remove('lucro');
            totalizadorSaldo.classList.add('prejuizo');
        } else {
            statusSaldo.textContent = '= Equilibrado';
            statusSaldo.style.color = '#95a5a6';
            totalizadorSaldo.classList.remove('lucro', 'prejuizo');
        }

        // Mostrar totalizadores
        document.getElementById('totalizadoresMovimentacoes').style.display = 'block';

    } catch (error) {
        console.error('Erro ao carregar movimentações:', error);
    }
}

async function imprimirMovimentacoes() {
    const dataInicio = document.getElementById('movDataInicio').value;
    const dataFim = document.getElementById('movDataFim').value;

    try {
        let url = `${API_URL}?endpoint=movimentacoes`;
        if (dataInicio && dataFim) {
            url += `&data_inicio=${dataInicio}&data_fim=${dataFim}`;
        }

        const response = await fetch(url);
        const movimentacoes = await response.json();

        // Calcular totais
        let totalEntradas = 0;
        let totalSaidas = 0;

        movimentacoes.forEach(mov => {
            let valorTotal = 0;
            if (typeof mov.valor_total === 'string') {
                valorTotal = parseFloat(mov.valor_total.replace(/[R$\s]/g, '').replace(',', '.')) || 0;
            } else {
                valorTotal = parseFloat(mov.valor_total) || 0;
            }

            if (mov.tipo === 'entrada') {
                totalEntradas += valorTotal;
            } else if (mov.tipo === 'saida') {
                totalSaidas += valorTotal;
            }
        });

        const saldo = totalSaidas - totalEntradas;

        // Gerar HTML para impressão
        const periodoTexto = dataInicio && dataFim
            ? `Período: ${formatarDataBrasil(dataInicio)} a ${formatarDataBrasil(dataFim)}`
            : 'Todas as Movimentações';

        let htmlImpressao = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <title>Relatório de Movimentações</title>
                <style>
                    @media print {
                        @page { margin: 1cm; }
                        body { margin: 0; }
                    }

                    * { margin: 0; padding: 0; box-sizing: border-box; }

                    body {
                        font-family: 'Segoe UI', Arial, sans-serif;
                        padding: 20px;
                        background: white;
                        color: #2c3e50;
                    }

                    .header {
                        text-align: center;
                        margin-bottom: 30px;
                        padding-bottom: 20px;
                        border-bottom: 3px solid #3498db;
                    }

                    .header h1 {
                        color: #2c3e50;
                        font-size: 28px;
                        margin-bottom: 8px;
                        font-weight: 600;
                    }

                    .header p {
                        color: #7f8c8d;
                        font-size: 14px;
                        margin-top: 5px;
                    }

                    .periodo {
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        color: white;
                        padding: 12px 20px;
                        border-radius: 8px;
                        text-align: center;
                        margin-bottom: 25px;
                        font-weight: 500;
                        font-size: 15px;
                    }

                    table {
                        width: 100%;
                        border-collapse: collapse;
                        margin-bottom: 25px;
                        background: white;
                        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                        border-radius: 8px;
                        overflow: hidden;
                    }

                    thead {
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        color: white;
                    }

                    th {
                        padding: 14px 12px;
                        text-align: left;
                        font-weight: 600;
                        font-size: 13px;
                        text-transform: uppercase;
                        letter-spacing: 0.5px;
                    }

                    td {
                        padding: 12px;
                        border-bottom: 1px solid #ecf0f1;
                        font-size: 13px;
                    }

                    tbody tr:hover {
                        background-color: #f8f9fa;
                    }

                    tbody tr:last-child td {
                        border-bottom: none;
                    }

                    .tipo-badge {
                        padding: 5px 12px;
                        border-radius: 20px;
                        font-size: 11px;
                        font-weight: 600;
                        text-transform: uppercase;
                        letter-spacing: 0.5px;
                        display: inline-block;
                    }

                    .tipo-entrada {
                        background-color: #d4edda;
                        color: #155724;
                    }

                    .tipo-saida {
                        background-color: #f8d7da;
                        color: #721c24;
                    }

                    .resumo {
                        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                        padding: 20px;
                        border-radius: 8px;
                        margin-top: 25px;
                    }

                    .resumo-grid {
                        display: grid;
                        grid-template-columns: repeat(3, 1fr);
                        gap: 15px;
                        margin-bottom: 15px;
                    }

                    .resumo-item {
                        background: white;
                        padding: 15px;
                        border-radius: 8px;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    }

                    .resumo-item h4 {
                        color: #7f8c8d;
                        font-size: 12px;
                        font-weight: 500;
                        margin-bottom: 8px;
                        text-transform: uppercase;
                        letter-spacing: 0.5px;
                    }

                    .resumo-item .valor {
                        font-size: 22px;
                        font-weight: 700;
                        color: #2c3e50;
                    }

                    .resumo-item.entradas .valor { color: #27ae60; }
                    .resumo-item.saidas .valor { color: #e74c3c; }
                    .resumo-item.saldo.lucro .valor { color: #2ecc71; }
                    .resumo-item.saldo.prejuizo .valor { color: #e74c3c; }

                    .footer {
                        margin-top: 30px;
                        padding-top: 15px;
                        border-top: 2px solid #ecf0f1;
                        text-align: center;
                        color: #95a5a6;
                        font-size: 12px;
                    }

                    .vazio {
                        text-align: center;
                        padding: 40px;
                        color: #95a5a6;
                    }

                    .vazio i {
                        font-size: 48px;
                        margin-bottom: 15px;
                        opacity: 0.3;
                    }

                    @media print {
                        .resumo-grid {
                            break-inside: avoid;
                        }

                        tbody tr {
                            break-inside: avoid;
                        }
                    }
                </style>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
            </head>
            <body>
                <div class="header">
                    <h1><i class="fas fa-exchange-alt"></i> Relatório de Movimentações</h1>
                    <p>Sistema de Controle de Estoque - PDV Profissional</p>
                </div>

                <div class="periodo">
                    <i class="fas fa-calendar-alt"></i> ${periodoTexto}
                </div>
        `;

        if (movimentacoes.length === 0) {
            htmlImpressao += `
                <div class="vazio">
                    <i class="fas fa-inbox"></i>
                    <p>Nenhuma movimentação encontrada para o período selecionado.</p>
                </div>
            `;
        } else {
            htmlImpressao += `
                <table>
                    <thead>
                        <tr>
                            <th>Data/Hora</th>
                            <th>Tipo</th>
                            <th>Produto</th>
                            <th style="text-align: center;">Qtd.</th>
                            <th style="text-align: right;">Valor Unit.</th>
                            <th style="text-align: right;">Valor Total</th>
                            <th>Cliente/Fornecedor</th>
                        </tr>
                    </thead>
                    <tbody>
            `;

            movimentacoes.forEach(mov => {
                const tipoClass = mov.tipo === 'entrada' ? 'tipo-entrada' : 'tipo-saida';
                const tipoText = mov.tipo === 'entrada' ? 'ENTRADA' : 'SAÍDA';
                const pessoa = mov.tipo === 'entrada' ? mov.fornecedor_nome : mov.cliente_nome;

                htmlImpressao += `
                    <tr>
                        <td>${formatarDataHoraBrasil(mov.data_movimentacao)}</td>
                        <td><span class="tipo-badge ${tipoClass}">${tipoText}</span></td>
                        <td><strong>${mov.produto_nome}</strong></td>
                        <td style="text-align: center;">${mov.quantidade}</td>
                        <td style="text-align: right;">${formatarMoeda(mov.valor_unitario)}</td>
                        <td style="text-align: right;"><strong>${formatarMoeda(mov.valor_total)}</strong></td>
                        <td>${pessoa || '-'}</td>
                    </tr>
                `;
            });

            htmlImpressao += `
                    </tbody>
                </table>

                <div class="resumo">
                    <div class="resumo-grid">
                        <div class="resumo-item entradas">
                            <h4><i class="fas fa-arrow-down"></i> Total de Entradas</h4>
                            <div class="valor">${formatarMoeda(totalEntradas)}</div>
                        </div>
                        <div class="resumo-item saidas">
                            <h4><i class="fas fa-arrow-up"></i> Total de Saídas</h4>
                            <div class="valor">${formatarMoeda(totalSaidas)}</div>
                        </div>
                        <div class="resumo-item saldo ${saldo >= 0 ? 'lucro' : 'prejuizo'}">
                            <h4><i class="fas fa-balance-scale"></i> Saldo (${saldo >= 0 ? 'Lucro' : 'Prejuízo'})</h4>
                            <div class="valor">${formatarMoeda(Math.abs(saldo))}</div>
                        </div>
                    </div>
                </div>
            `;
        }

        htmlImpressao += `
                <div class="footer">
                    <p><i class="fas fa-print"></i> Relatório gerado em ${formatarDataHoraBrasil(new Date().toISOString())}</p>
                    <p>Sistema PDV Profissional - Controle de Estoque</p>
                </div>
            </body>
            </html>
        `;

        // Abrir nova janela e imprimir
        const janelaImpressao = window.open('', '_blank', 'width=900,height=700');
        janelaImpressao.document.write(htmlImpressao);
        janelaImpressao.document.close();

        // Aguardar carregamento e imprimir
        setTimeout(() => {
            janelaImpressao.focus();
            janelaImpressao.print();
        }, 500);

    } catch (error) {
        console.error('Erro ao gerar relatório:', error);
        alert('Erro ao gerar relatório de impressão!');
    }
}

function formatarDataBrasil(data) {
    if (!data) return '';
    const partes = data.split('-');
    return `${partes[2]}/${partes[1]}/${partes[0]}`;
}

function abrirModalMovimentacao() {
    document.getElementById('formMovimentacao').reset();
    document.getElementById('movId').value = '';
    document.getElementById('tituloModalMovimentacao').textContent = 'Nova Movimentação';
    document.getElementById('modalMovimentacao').classList.add('active');
    alterarTipoMovimentacao();

    // Reinicializar máscaras de dinheiro após abrir o modal
    setTimeout(() => inicializarMascarasDinheiro(), 100);
}

function alterarTipoMovimentacao() {
    const tipo = document.getElementById('movTipo').value;

    if (tipo === 'entrada') {
        document.getElementById('divCliente').style.display = 'none';
        document.getElementById('divFornecedor').style.display = 'block';
    } else {
        document.getElementById('divCliente').style.display = 'block';
        document.getElementById('divFornecedor').style.display = 'none';
    }
}

function atualizarPrecoMovimentacao() {
    const select = document.getElementById('movProduto');
    const option = select.options[select.selectedIndex];
    const tipo = document.getElementById('movTipo').value;

    if (option && option.value) {
        const preco = tipo === 'entrada' ?
            option.getAttribute('data-preco-custo') :
            option.getAttribute('data-preco-venda');

        // Formatar o preço antes de inserir no campo
        document.getElementById('movValorUnitario').value = numero_para_dinheiro(preco);
        calcularTotalMovimentacao();
    }
}

function calcularTotalMovimentacao() {
    const quantidade = parseFloat(document.getElementById('movQuantidade').value) || 0;
    const valorUnitario = dinheiro_para_numero(document.getElementById('movValorUnitario').value) || 0;
    const total = quantidade * valorUnitario;

    // Formatar como moeda brasileira
    const totalFormatado = new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(total);

    document.getElementById('movValorTotal').value = totalFormatado;
}

async function salvarMovimentacao(event) {
    event.preventDefault();

    // Validações antes de salvar
    const produto = document.getElementById('movProduto').value;
    if (!produto) {
        alert('Por favor, selecione um produto!');
        document.getElementById('movProduto').focus();
        return;
    }

    const quantidade = parseInt(document.getElementById('movQuantidade').value);
    if (!quantidade || quantidade <= 0) {
        alert('Por favor, informe uma quantidade válida!');
        document.getElementById('movQuantidade').focus();
        return;
    }

    const valorUnitario = dinheiro_para_numero(document.getElementById('movValorUnitario').value);
    if (!valorUnitario || valorUnitario <= 0) {
        alert('Por favor, informe um valor unitário válido!');
        document.getElementById('movValorUnitario').focus();
        return;
    }

    const tipo = document.getElementById('movTipo').value;
    const clienteId = document.getElementById('movCliente').value;
    const fornecedorId = document.getElementById('movFornecedor').value;

    // Validar se cliente ou fornecedor foi selecionado conforme o tipo
    if (tipo === 'saida' && !clienteId) {
        alert('Por favor, selecione um cliente para a saída!');
        document.getElementById('movCliente').focus();
        return;
    }

    if (tipo === 'entrada' && !fornecedorId) {
        alert('Por favor, selecione um fornecedor para a entrada!');
        document.getElementById('movFornecedor').focus();
        return;
    }

    // Calcular valor total corretamente (remover formatação de moeda)
    const valorTotal = quantidade * valorUnitario;

    const movId = document.getElementById('movId').value;

    const data = {
        produto_id: parseInt(produto),
        tipo: tipo,
        quantidade: quantidade,
        valor_unitario: valorUnitario,
        valor_total: valorTotal,
        cliente_id: clienteId || null,
        fornecedor_id: fornecedorId || null,
        observacao: document.getElementById('movObservacao').value
    };

    try {
        let url = `${API_URL}?endpoint=movimentacoes`;
        let method = 'POST';

        if (movId) {
            url += `&id=${movId}`;
            method = 'PUT';
        }

        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (result.success) {
            alert(movId ? 'Movimentação atualizada com sucesso!' : 'Movimentação registrada com sucesso!');
            fecharModal('modalMovimentacao');
            carregarMovimentacoes();
            carregarProdutos();
            carregarDashboard();
            carregarEstoqueBaixo();
            atualizarGrafico();
        }
    } catch (error) {
        console.error('Erro ao salvar movimentação:', error);
        alert('Erro ao salvar movimentação!');
    }
}

async function editarMovimentacao(id) {
    try {
        const response = await fetch(`${API_URL}?endpoint=movimentacoes&id=${id}`);
        const movimentacao = await response.json();

        if (movimentacao) {
            document.getElementById('movId').value = movimentacao.id;
            document.getElementById('tituloModalMovimentacao').textContent = 'Editar Movimentação';
            document.getElementById('movTipo').value = movimentacao.tipo;
            document.getElementById('movProduto').value = movimentacao.produto_id;
            document.getElementById('movQuantidade').value = movimentacao.quantidade;
            document.getElementById('movValorUnitario').value = numero_para_dinheiro(movimentacao.valor_unitario);
            document.getElementById('movCliente').value = movimentacao.cliente_id || '';
            document.getElementById('movFornecedor').value = movimentacao.fornecedor_id || '';
            document.getElementById('movObservacao').value = movimentacao.observacao || '';

            alterarTipoMovimentacao();
            calcularTotalMovimentacao();

            document.getElementById('modalMovimentacao').classList.add('active');

            // Reinicializar máscaras de dinheiro após preencher o modal
            setTimeout(() => inicializarMascarasDinheiro(), 100);
        }
    } catch (error) {
        console.error('Erro ao carregar movimentação:', error);
        alert('Erro ao carregar movimentação!');
    }
}

async function excluirMovimentacao(id) {
    if (!confirm('Deseja realmente excluir esta movimentação?')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}?endpoint=movimentacoes&id=${id}`, {
            method: 'DELETE'
        });

        const result = await response.json();

        if (result.success) {
            alert('Movimentação excluída com sucesso!');
            carregarMovimentacoes();
            carregarProdutos();
            carregarDashboard();
            carregarEstoqueBaixo();
            atualizarGrafico();
        }
    } catch (error) {
        console.error('Erro ao excluir movimentação:', error);
        alert('Erro ao excluir movimentação!');
    }
}

function imprimirMovimentacoes() {
    // Pegar os dados da tabela atual
    const tbody = document.getElementById('listaMovimentacoes');
    const linhas = tbody.querySelectorAll('tr');

    // Verificar se há movimentações
    if (linhas.length === 0 || linhas[0].querySelector('.empty-state')) {
        alert('Não há movimentações para imprimir!');
        return;
    }

    // Pegar as datas do filtro
    const dataInicio = document.getElementById('movDataInicio').value;
    const dataFim = document.getElementById('movDataFim').value;
    let periodo = 'Todas as Movimentações';
    if (dataInicio && dataFim) {
        periodo = `Período: ${formatarDataBrasil(dataInicio)} a ${formatarDataBrasil(dataFim)}`;
    }

    // Pegar os totalizadores
    const totalEntradas = document.getElementById('movTotalEntradas')?.textContent || 'R$ 0,00';
    const totalSaidas = document.getElementById('movTotalSaidas')?.textContent || 'R$ 0,00';
    const saldoTotal = document.getElementById('movSaldoTotal')?.textContent || 'R$ 0,00';
    const statusSaldo = document.getElementById('movStatusSaldo')?.textContent || '';

    // Construir HTML da tabela para impressão
    let htmlTabela = '';
    linhas.forEach(linha => {
        if (!linha.querySelector('.empty-state')) {
            const colunas = linha.querySelectorAll('td');
            if (colunas.length >= 7) {
                htmlTabela += `
                    <tr>
                        <td>${colunas[0].textContent}</td>
                        <td>${colunas[1].textContent}</td>
                        <td>${colunas[2].textContent}</td>
                        <td>${colunas[3].textContent}</td>
                        <td>${colunas[4].textContent}</td>
                        <td>${colunas[5].textContent}</td>
                        <td>${colunas[6].textContent}</td>
                    </tr>
                `;
            }
        }
    });

    // Criar janela de impressão
    const janelaImpressao = window.open('', '_blank');
    janelaImpressao.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Relatório de Movimentações</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    font-family: Arial, sans-serif;
                    padding: 20px;
                    font-size: 12px;
                }
                .cabecalho {
                    text-align: center;
                    margin-bottom: 30px;
                    border-bottom: 2px solid #333;
                    padding-bottom: 15px;
                }
                .cabecalho h1 {
                    font-size: 24px;
                    color: #2c3e50;
                    margin-bottom: 5px;
                }
                .cabecalho p {
                    font-size: 14px;
                    color: #7f8c8d;
                }
                .periodo {
                    text-align: center;
                    font-size: 13px;
                    color: #34495e;
                    margin-bottom: 20px;
                    font-weight: bold;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 30px;
                }
                th {
                    background-color: #34495e;
                    color: white;
                    padding: 10px;
                    text-align: left;
                    font-size: 11px;
                    border: 1px solid #2c3e50;
                }
                td {
                    padding: 8px;
                    border: 1px solid #ddd;
                    font-size: 11px;
                }
                tr:nth-child(even) {
                    background-color: #f8f9fa;
                }
                .totalizadores {
                    display: grid;
                    grid-template-columns: repeat(3, 1fr);
                    gap: 15px;
                    margin-top: 20px;
                    page-break-inside: avoid;
                }
                .totalizador {
                    border: 2px solid #ddd;
                    padding: 15px;
                    text-align: center;
                    border-radius: 8px;
                }
                .totalizador.entradas { border-color: #3498db; background-color: #ebf5fb; }
                .totalizador.saidas { border-color: #2ecc71; background-color: #eafaf1; }
                .totalizador.saldo { border-color: #f39c12; background-color: #fef5e7; }
                .totalizador.saldo.lucro { border-color: #2ecc71; background-color: #eafaf1; }
                .totalizador.saldo.prejuizo { border-color: #e74c3c; background-color: #fadbd8; }
                .totalizador-label {
                    font-size: 11px;
                    color: #7f8c8d;
                    margin-bottom: 5px;
                    text-transform: uppercase;
                    font-weight: bold;
                }
                .totalizador-valor {
                    font-size: 20px;
                    font-weight: bold;
                    color: #2c3e50;
                }
                .totalizador-status {
                    font-size: 12px;
                    margin-top: 5px;
                    font-weight: bold;
                }
                .rodape {
                    margin-top: 30px;
                    text-align: center;
                    font-size: 10px;
                    color: #95a5a6;
                    border-top: 1px solid #ddd;
                    padding-top: 10px;
                }
                @media print {
                    body { padding: 10px; }
                    .totalizadores { page-break-inside: avoid; }
                }
            </style>
        </head>
        <body>
            <div class="cabecalho">
                <h1>📊 Relatório de Movimentações</h1>
                <p>Sistema PDV - Controle de Estoque</p>
            </div>

            <div class="periodo">${periodo}</div>

            <table>
                <thead>
                    <tr>
                        <th>Data</th>
                        <th>Tipo</th>
                        <th>Produto</th>
                        <th>Qtd</th>
                        <th>Valor Unit.</th>
                        <th>Valor Total</th>
                        <th>Cliente/Fornecedor</th>
                    </tr>
                </thead>
                <tbody>
                    ${htmlTabela}
                </tbody>
            </table>

            <div class="totalizadores">
                <div class="totalizador entradas">
                    <div class="totalizador-label">Total Entradas (Custo)</div>
                    <div class="totalizador-valor">${totalEntradas}</div>
                </div>
                <div class="totalizador saidas">
                    <div class="totalizador-label">Total Saídas (Vendas)</div>
                    <div class="totalizador-valor">${totalSaidas}</div>
                </div>
                <div class="totalizador saldo ${statusSaldo.includes('Lucro') ? 'lucro' : statusSaldo.includes('Prejuízo') ? 'prejuizo' : ''}">
                    <div class="totalizador-label">Saldo (Lucro/Prejuízo)</div>
                    <div class="totalizador-valor">${saldoTotal}</div>
                    <div class="totalizador-status">${statusSaldo}</div>
                </div>
            </div>

            <div class="rodape">
                <p>Relatório gerado em ${new Date().toLocaleString('pt-BR')}</p>
            </div>

            <script>
                window.onload = function() {
                    window.print();
                };
            </script>
        </body>
        </html>
    `);
    janelaImpressao.document.close();
}

function formatarDataBrasil(dataISO) {
    if (!dataISO) return '';
    const partes = dataISO.split('-');
    return `${partes[2]}/${partes[1]}/${partes[0]}`;
}

// CLIENTES
async function carregarClientes() {
    try {
        const response = await fetch(`${API_URL}?endpoint=clientes`);
        const clientes = await response.json();

        const tbody = document.getElementById('listaClientes');
        tbody.innerHTML = '';

        if (clientes.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="empty-state">
                        <i class="fas fa-users"></i>
                        <p>Nenhum cliente cadastrado</p>
                    </td>
                </tr>
            `;
        } else {
            clientes.forEach(cliente => {
                tbody.innerHTML += `
                    <tr>
                        <td><strong>${cliente.nome}</strong></td>
                        <td>${cliente.cpf_cnpj || '-'}</td>
                        <td>${cliente.telefone || '-'}</td>
                        <td>${cliente.email || '-'}</td>
                        <td>${cliente.cidade || '-'}</td>
                        <td>
                            <button class="btn btn-sm btn-primary" onclick="editarCliente(${cliente.id})">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="excluirCliente(${cliente.id})">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
        }

        // Atualizar select de clientes para movimentação
        const select = document.getElementById('movCliente');
        select.innerHTML = '<option value="">Selecione...</option>';
        clientes.forEach(c => {
            select.innerHTML += `<option value="${c.id}">${c.nome}</option>`;
        });
    } catch (error) {
        console.error('Erro ao carregar clientes:', error);
    }
}

function filtrarClientes() {
    const busca = document.getElementById('searchCliente').value.toLowerCase();
    const linhas = document.querySelectorAll('#listaClientes tr');

    linhas.forEach(linha => {
        const texto = linha.textContent.toLowerCase();
        linha.style.display = texto.includes(busca) ? '' : 'none';
    });
}

function abrirModalCliente(id = null) {
    document.getElementById('modalClienteTitulo').textContent = id ? 'Editar Cliente' : 'Novo Cliente';

    // APENAS fazer reset se for NOVO cliente (id null)
    if (!id) {
        document.getElementById('formCliente').reset();
    }

    document.getElementById('clienteId').value = id || '';
    document.getElementById('modalCliente').classList.add('active');
}

async function editarCliente(id) {
    try {
        console.log('Editando cliente ID:', id);
        const response = await fetch(`${API_URL}?endpoint=clientes&id=${id}`);

        if (!response.ok) {
            throw new Error('Erro na resposta da API: ' + response.status);
        }

        const cliente = await response.json();
        console.log('Cliente recebido:', cliente);

        if (!cliente || !cliente.id) {
            throw new Error('Cliente não encontrado ou dados inválidos');
        }

        document.getElementById('clienteId').value = cliente.id;
        document.getElementById('clienteNome').value = cliente.nome || '';
        document.getElementById('clienteCpfCnpj').value = cliente.cpf_cnpj || '';
        document.getElementById('clienteTelefone').value = cliente.telefone || '';
        document.getElementById('clienteEmail').value = cliente.email || '';
        document.getElementById('clienteEndereco').value = cliente.endereco || '';
        document.getElementById('clienteCidade').value = cliente.cidade || '';
        document.getElementById('clienteEstado').value = cliente.estado || '';
        document.getElementById('clienteCep').value = cliente.cep || '';

        console.log('Abrindo modal cliente...');
        abrirModalCliente(id);
    } catch (error) {
        console.error('Erro ao carregar cliente:', error);
        alert('Erro ao carregar cliente: ' + error.message);
    }
}

async function salvarCliente(event) {
    event.preventDefault();

    // Validações antes de salvar
    let validacaoOK = true;

    // Validar nome (obrigatório)
    const nome = document.getElementById('clienteNome').value.trim();
    if (!nome) {
        alert('Por favor, informe o nome do cliente!');
        document.getElementById('clienteNome').focus();
        return;
    }

    // Validar CPF/CNPJ se preenchido
    const cpfCnpj = document.getElementById('clienteCpfCnpj').value.trim();
    if (cpfCnpj && !validarCpfCnpjOnBlur('clienteCpfCnpj')) {
        validacaoOK = false;
    }

    // Validar telefone se preenchido
    const telefone = document.getElementById('clienteTelefone').value.trim();
    if (telefone && !validarTelefoneOnBlur('clienteTelefone')) {
        validacaoOK = false;
    }

    // Validar email se preenchido
    const email = document.getElementById('clienteEmail').value.trim();
    if (email && !validarEmailOnBlur('clienteEmail')) {
        validacaoOK = false;
    }

    // Validar CEP se preenchido
    const cep = document.getElementById('clienteCep').value.trim();
    if (cep && !validarCepOnBlur('clienteCep')) {
        validacaoOK = false;
    }

    if (!validacaoOK) {
        alert('Por favor, corrija os erros no formulário antes de salvar!');
        return;
    }

    const id = document.getElementById('clienteId').value;
    const data = {
        id: id,
        nome: nome,
        cpf_cnpj: cpfCnpj,
        telefone: telefone,
        email: email,
        endereco: document.getElementById('clienteEndereco').value,
        cidade: document.getElementById('clienteCidade').value,
        estado: document.getElementById('clienteEstado').value,
        cep: cep
    };

    try {
        const method = id ? 'PUT' : 'POST';
        const response = await fetch(`${API_URL}?endpoint=clientes`, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (result.success) {
            alert('Cliente salvo com sucesso!');
            fecharModal('modalCliente');
            carregarClientes();
            carregarDashboard();
        }
    } catch (error) {
        console.error('Erro ao salvar cliente:', error);
        alert('Erro ao salvar cliente!');
    }
}

async function excluirCliente(id) {
    if (!confirm('Deseja realmente excluir este cliente?')) return;

    try {
        const response = await fetch(`${API_URL}?endpoint=clientes&id=${id}`, {
            method: 'DELETE'
        });

        const result = await response.json();

        if (result.success) {
            alert('Cliente excluído com sucesso!');
            carregarClientes();
            carregarDashboard();
        }
    } catch (error) {
        console.error('Erro ao excluir cliente:', error);
        alert('Erro ao excluir cliente!');
    }
}

// FORNECEDORES
async function carregarFornecedores() {
    try {
        const response = await fetch(`${API_URL}?endpoint=fornecedores`);
        const fornecedores = await response.json();

        const tbody = document.getElementById('listaFornecedores');
        tbody.innerHTML = '';

        if (fornecedores.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" class="empty-state">
                        <i class="fas fa-truck"></i>
                        <p>Nenhum fornecedor cadastrado</p>
                    </td>
                </tr>
            `;
        } else {
            fornecedores.forEach(fornecedor => {
                tbody.innerHTML += `
                    <tr>
                        <td>
                            ${fornecedor.foto ?
                                `<img src="${fornecedor.foto}" class="produto-foto" alt="${fornecedor.nome}">` :
                                `<div class="produto-foto" style="background: #ecf0f1; display: flex; align-items: center; justify-content: center;">
                                    <i class="fas fa-building" style="color: #95a5a6;"></i>
                                </div>`
                            }
                        </td>
                        <td><strong>${fornecedor.nome}</strong></td>
                        <td>${fornecedor.cnpj || '-'}</td>
                        <td>${fornecedor.telefone || '-'}</td>
                        <td>${fornecedor.email || '-'}</td>
                        <td>${fornecedor.contato_responsavel || '-'}</td>
                        <td>
                            <button class="btn btn-sm btn-primary" onclick="editarFornecedor(${fornecedor.id})">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="excluirFornecedor(${fornecedor.id})">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
        }

        // Atualizar selects
        const selectProduto = document.getElementById('produtoFornecedor');
        selectProduto.innerHTML = '<option value="">Selecione...</option>';
        fornecedores.forEach(f => {
            selectProduto.innerHTML += `<option value="${f.id}">${f.nome}</option>`;
        });

        const selectMov = document.getElementById('movFornecedor');
        selectMov.innerHTML = '<option value="">Selecione...</option>';
        fornecedores.forEach(f => {
            selectMov.innerHTML += `<option value="${f.id}">${f.nome}</option>`;
        });

        // Populate fornecedor select no modal de reposição
        const selectReposicao = document.getElementById('reposicaoFornecedor');
        if (selectReposicao) {
            selectReposicao.innerHTML = '<option value="">Selecione...</option>';
            fornecedores.forEach(f => {
                selectReposicao.innerHTML += `<option value="${f.id}">${f.nome}</option>`;
            });
        }
    } catch (error) {
        console.error('Erro ao carregar fornecedores:', error);
    }
}

function filtrarFornecedores() {
    const busca = document.getElementById('searchFornecedor').value.toLowerCase();
    const linhas = document.querySelectorAll('#listaFornecedores tr');

    linhas.forEach(linha => {
        const texto = linha.textContent.toLowerCase();
        linha.style.display = texto.includes(busca) ? '' : 'none';
    });
}

function abrirModalFornecedor(id = null) {
    document.getElementById('modalFornecedorTitulo').textContent = id ? 'Editar Fornecedor' : 'Novo Fornecedor';

    // APENAS fazer reset se for NOVO fornecedor (id null)
    if (!id) {
        document.getElementById('formFornecedor').reset();
    }

    document.getElementById('fornecedorId').value = id || '';
    document.getElementById('modalFornecedor').classList.add('active');
}

async function editarFornecedor(id) {
    try {
        console.log('Editando fornecedor ID:', id);
        const response = await fetch(`${API_URL}?endpoint=fornecedores&id=${id}`);

        if (!response.ok) {
            throw new Error('Erro na resposta da API: ' + response.status);
        }

        const fornecedor = await response.json();
        console.log('Fornecedor recebido:', fornecedor);

        if (!fornecedor || !fornecedor.id) {
            throw new Error('Fornecedor não encontrado ou dados inválidos');
        }

        document.getElementById('fornecedorId').value = fornecedor.id;
        document.getElementById('fornecedorNome').value = fornecedor.nome || '';
        document.getElementById('fornecedorCnpj').value = fornecedor.cnpj || '';
        document.getElementById('fornecedorTelefone').value = fornecedor.telefone || '';
        document.getElementById('fornecedorEmail').value = fornecedor.email || '';
        document.getElementById('fornecedorContato').value = fornecedor.contato_responsavel || '';
        document.getElementById('fornecedorEndereco').value = fornecedor.endereco || '';
        document.getElementById('fornecedorCidade').value = fornecedor.cidade || '';
        document.getElementById('fornecedorEstado').value = fornecedor.estado || '';
        document.getElementById('fornecedorCep').value = fornecedor.cep || '';
        document.getElementById('fornecedorFotoPath').value = fornecedor.foto || '';

        // Exibir foto se existir
        if (fornecedor.foto) {
            const preview = document.getElementById('previewFornecedorFoto');
            preview.src = fornecedor.foto;
            preview.style.display = 'block';
        } else {
            document.getElementById('previewFornecedorFoto').style.display = 'none';
        }

        console.log('Abrindo modal fornecedor...');
        abrirModalFornecedor(id);
    } catch (error) {
        console.error('Erro ao carregar fornecedor:', error);
        alert('Erro ao carregar fornecedor: ' + error.message);
    }
}

async function salvarFornecedor(event) {
    event.preventDefault();

    // Validações antes de salvar
    let validacaoOK = true;

    // Validar nome (obrigatório)
    const nome = document.getElementById('fornecedorNome').value.trim();
    if (!nome) {
        alert('Por favor, informe o nome do fornecedor!');
        document.getElementById('fornecedorNome').focus();
        return;
    }

    // Validar CNPJ se preenchido
    const cnpj = document.getElementById('fornecedorCnpj').value.trim();
    if (cnpj && !validarCnpjOnBlur('fornecedorCnpj')) {
        validacaoOK = false;
    }

    // Validar telefone se preenchido
    const telefone = document.getElementById('fornecedorTelefone').value.trim();
    if (telefone && !validarTelefoneOnBlur('fornecedorTelefone')) {
        validacaoOK = false;
    }

    // Validar email se preenchido
    const email = document.getElementById('fornecedorEmail').value.trim();
    if (email && !validarEmailOnBlur('fornecedorEmail')) {
        validacaoOK = false;
    }

    // Validar CEP se preenchido
    const cep = document.getElementById('fornecedorCep').value.trim();
    if (cep && !validarCepOnBlur('fornecedorCep')) {
        validacaoOK = false;
    }

    if (!validacaoOK) {
        alert('Por favor, corrija os erros no formulário antes de salvar!');
        return;
    }

    const id = document.getElementById('fornecedorId').value;
    let fotoPath = document.getElementById('fornecedorFotoPath').value;

    // Upload da foto se houver nova foto
    const fotoInput = document.getElementById('fornecedorFoto');
    if (fotoInput.files.length > 0) {
        const formData = new FormData();
        formData.append('foto', fotoInput.files[0]);

        try {
            const uploadResponse = await fetch('upload.php', {
                method: 'POST',
                body: formData
            });
            const uploadResult = await uploadResponse.json();

            if (uploadResult.success) {
                fotoPath = uploadResult.path;
            }
        } catch (error) {
            console.error('Erro ao fazer upload da foto:', error);
        }
    }

    const data = {
        id: id,
        nome: nome,
        cnpj: cnpj,
        telefone: telefone,
        email: email,
        contato_responsavel: document.getElementById('fornecedorContato').value,
        endereco: document.getElementById('fornecedorEndereco').value,
        cidade: document.getElementById('fornecedorCidade').value,
        estado: document.getElementById('fornecedorEstado').value,
        cep: cep,
        foto: fotoPath
    };

    try {
        const method = id ? 'PUT' : 'POST';
        const response = await fetch(`${API_URL}?endpoint=fornecedores`, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (result.success) {
            alert('Fornecedor salvo com sucesso!');
            fecharModal('modalFornecedor');
            carregarFornecedores();
        }
    } catch (error) {
        console.error('Erro ao salvar fornecedor:', error);
        alert('Erro ao salvar fornecedor!');
    }
}

async function excluirFornecedor(id) {
    if (!confirm('Deseja realmente excluir este fornecedor?')) return;

    try {
        const response = await fetch(`${API_URL}?endpoint=fornecedores&id=${id}`, {
            method: 'DELETE'
        });

        const result = await response.json();

        if (result.success) {
            alert('Fornecedor excluído com sucesso!');
            carregarFornecedores();
        }
    } catch (error) {
        console.error('Erro ao excluir fornecedor:', error);
        alert('Erro ao excluir fornecedor!');
    }
}

// ALERTAS DE ESTOQUE BAIXO
async function carregarEstoqueBaixo() {
    try {
        const response = await fetch(`${API_URL}?endpoint=estoque_baixo`);
        const produtos = await response.json();

        const container = document.getElementById('listaAlertas');
        container.innerHTML = '';

        if (produtos.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-check-circle"></i>
                    <p>Todos os produtos estão com estoque adequado!</p>
                </div>
            `;
            return;
        }

        produtos.forEach(produto => {
            const fotoHtml = produto.foto ?
                `<img src="${produto.foto}" class="alerta-foto" alt="${produto.nome}">` :
                `<div class="alerta-foto" style="background: #ecf0f1; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-image" style="color: #95a5a6; font-size: 2rem;"></i>
                </div>`;

            container.innerHTML += `
                <div class="alerta-card" onclick="editarProdutoDoAlerta(${produto.id})" style="cursor: pointer; transition: all 0.3s;"
                     onmouseover="this.style.transform='scale(1.02)'; this.style.boxShadow='0 4px 12px rgba(0,0,0,0.15)';"
                     onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.1)';">
                    ${fotoHtml}
                    <div class="alerta-info">
                        <h4>${produto.nome}</h4>
                        <p><i class="fas fa-tag"></i> ${produto.categoria_nome || 'Sem categoria'}</p>
                        <p><i class="fas fa-barcode"></i> ${produto.codigo_barras || 'Sem código'}</p>
                        <div class="alerta-estoque">
                            <span class="estoque-info">Atual: ${produto.estoque_atual}</span>
                            <span class="estoque-info">Mínimo: ${produto.estoque_minimo}</span>
                        </div>
                    </div>
                    <div style="text-align: center; padding: 10px; background: #f8f9fa; border-radius: 0 0 8px 8px; margin-top: 10px;">
                        <small style="color: #666;"><i class="fas fa-hand-pointer"></i> Clique para editar</small>
                    </div>
                </div>
            `;
        });
    } catch (error) {
        console.error('Erro ao carregar alertas:', error);
    }
}

// Função para editar produto a partir do alerta
async function editarProdutoDoAlerta(id) {
    console.log('Editando produto ID:', id);

    // Mudar para a seção de produtos
    showSection('produtos');

    // Aguardar um momento para garantir que a seção carregou
    await new Promise(resolve => setTimeout(resolve, 300));

    // Editar o produto
    await editarProduto(id);
}

// LEITOR DE CÓDIGO DE BARRAS
function abrirLeitorBarras() {
    document.getElementById('modalBarcode').classList.add('active');

    Quagga.init({
        inputStream: {
            name: "Live",
            type: "LiveStream",
            target: document.querySelector('#barcode-scanner'),
            constraints: {
                width: 640,
                height: 480,
                facingMode: "environment"
            },
        },
        decoder: {
            readers: [
                "ean_reader",      // EAN-13 (mais comum no Brasil)
                "ean_8_reader",    // EAN-8
                "upc_reader",      // UPC-A
                "upc_e_reader",    // UPC-E
                "code_128_reader", // Code 128
                "code_39_reader",  // Code 39
                "codabar_reader",  // Codabar
                "i2of5_reader"     // Interleaved 2 of 5
            ],
            multiple: false  // Melhor precisão com um código por vez
        },
        locate: true,  // Melhor detecção automática
        numOfWorkers: 4,  // Performance melhorada
        frequency: 10  // Frequência de scan (10 vezes por segundo)
    }, function(err) {
        if (err) {
            console.error(err);
            alert('Erro ao iniciar câmera. Verifique as permissões.');
            fecharLeitorBarras();
            return;
        }
        Quagga.start();
    });

    Quagga.onDetected(async function(result) {
        const codigo = result.codeResult.code;

        // Buscar produto pelo código de barras
        try {
            const response = await fetch(`${API_URL}?endpoint=produtos&codigo_barras=${codigo}`);
            const produto = await response.json();

            if (produto && produto.id) {
                fecharLeitorBarras();
                editarProduto(produto.id);
            } else {
                if (confirm(`Código ${codigo} não encontrado. Deseja cadastrar um novo produto?`)) {
                    fecharLeitorBarras();
                    abrirModalProduto();
                    document.getElementById('produtoCodigoBarras').value = codigo;
                }
            }
        } catch (error) {
            console.error('Erro ao buscar produto:', error);
        }
    });
}

function fecharLeitorBarras() {
    Quagga.stop();
    fecharModal('modalBarcode');
}

// UTILITÁRIOS
function fecharModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

function formatarMoeda(valor) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(valor || 0);
}

function formatarData(data) {
    return new Date(data).toLocaleDateString('pt-BR', {
        timeZone: 'America/Sao_Paulo'
    });
}

function formatarDataHora(data) {
    return new Date(data).toLocaleString('pt-BR', {
        timeZone: 'America/Sao_Paulo'
    });
}

// Formatar data/hora considerando que o banco já está em horário de Brasília
function formatarDataHoraBrasil(data) {
    // O banco já salva em horário de Brasília (UTC-3)
    // Então apenas formatamos sem conversão adicional
    const date = new Date(data + 'Z'); // Adiciona Z para tratar como UTC
    return date.toLocaleString('pt-BR', {
        timeZone: 'America/Sao_Paulo',
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

// NÃO fechar modal ao clicar fora (removido para evitar fechamento acidental)
// Usuário deve usar o botão X ou Cancelar para fechar

// ============================================
// FUNÇÕES DE BACKUP E RESTORE
// ============================================

// Controlar visibilidade dos botões de backup/restore baseado no nível do admin
function controlarBotoesBackup() {
    // Obter dados do usuário
    fetch(`${API_URL}?endpoint=user_data`)
        .then(res => res.json())
        .then(data => {
            if (data.logado && data.usuario) {
                const nivelAdmin = data.usuario.nivel_admin;
                const btnBackup = document.querySelector('[onclick="fazerBackup()"]');
                const btnRestore = document.querySelector('[onclick="abrirModalRestore()"]');

                if (btnBackup && btnRestore) {
                    // Admin Master: pode backup E restore
                    if (nivelAdmin === 'master') {
                        btnBackup.style.display = '';
                        btnRestore.style.display = '';
                    }
                    // Admin Gerente: pode backup mas NÃO pode restore
                    else if (nivelAdmin === 'gerente') {
                        btnBackup.style.display = '';
                        btnRestore.style.display = 'none';
                    }
                    // Outros: sem acesso
                    else {
                        btnBackup.style.display = 'none';
                        btnRestore.style.display = 'none';
                    }
                }
            }
        })
        .catch(err => console.error('Erro ao controlar botões:', err));
}

function fazerBackup() {
    if (!confirm('Deseja fazer o backup completo do banco de dados?\n\nO arquivo será baixado com a data e hora atual.')) {
        return;
    }

    // Criar link para download
    const link = document.createElement('a');
    link.href = `${API_URL}?endpoint=backup`;
    // Usar horário de Brasília para nome do arquivo
    const agora = new Date();
    const dataHoraBrasilia = agora.toLocaleString('pt-BR', {
        timeZone: 'America/Sao_Paulo',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    }).replace(/\//g, '-').replace(/,/g, '').replace(/:/g, '-').replace(/ /g, '_');
    link.download = `backup-estoque-${dataHoraBrasilia}.db`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Registrar que foi feito backup hoje
    const hoje = new Date();
    const dia = hoje.getDate();

    if (dia === 25) {
        // Se fez backup no dia 25, registrar para não mostrar alerta novamente este mês
        const mesAno = `${hoje.getFullYear()}-${String(hoje.getMonth() + 1).padStart(2, '0')}`;
        localStorage.setItem('ultimoBackupMensal', mesAno);
    }

    mostrarNotificacao('Backup baixado com sucesso!', 'success');
}

function abrirModalRestore() {
    document.getElementById('modalRestore').classList.add('active');
    document.getElementById('formRestore').reset();
}

async function restaurarBackup(event) {
    event.preventDefault();

    const arquivoInput = document.getElementById('arquivoBackup');
    const arquivo = arquivoInput.files[0];

    if (!arquivo) {
        alert('Por favor, selecione um arquivo de backup.');
        return;
    }

    if (!arquivo.name.endsWith('.db')) {
        alert('Formato inválido! Por favor, selecione um arquivo .db');
        return;
    }

    if (!confirm('⚠️ ATENÇÃO!\n\nEsta ação irá SUBSTITUIR TODOS os dados atuais do sistema.\n\nUm backup de segurança será criado automaticamente antes da restauração.\n\nDeseja continuar?')) {
        return;
    }

    const formData = new FormData();
    formData.append('backup', arquivo);

    try {
        const response = await fetch(`${API_URL}?endpoint=restore`, {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (response.ok && result.success) {
            alert('✅ ' + result.message);
            fecharModal('modalRestore');

            // Fazer logout e redirecionar para login
            setTimeout(() => {
                window.location.href = 'logout.php';
            }, 1500);
        } else {
            throw new Error(result.error || 'Erro ao restaurar backup');
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('❌ Erro ao restaurar backup:\n' + error.message);
    }
}

// ============================================
// ALERTA MENSAL DE BACKUP - DIA 25
// ============================================

function verificarAlertaBackupMensal() {
    const hoje = new Date();
    const dia = hoje.getDate();
    const mesAno = `${hoje.getFullYear()}-${String(hoje.getMonth() + 1).padStart(2, '0')}`;
    const ultimoBackupMensal = localStorage.getItem('ultimoBackupMensal');

    // Verificar se é dia 25 e se ainda não foi feito backup este mês
    if (dia === 25 && ultimoBackupMensal !== mesAno) {
        // Aguardar 3 segundos após o login para mostrar o alerta
        setTimeout(() => {
            const resposta = confirm(
                '📅 LEMBRETE DE BACKUP MENSAL\n\n' +
                'Hoje é dia 25! Está na hora de fazer o backup mensal do sistema.\n\n' +
                'Deseja fazer o backup agora?\n\n' +
                '✅ SIM - Fará o backup e esta mensagem não aparecerá novamente este mês\n' +
                '❌ NÃO - A mensagem aparecerá novamente amanhã'
            );

            if (resposta) {
                // Se clicou em SIM, fazer o backup
                fazerBackup();
            }
        }, 3000);
    }
}

// Executar verificação quando a página carregar
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', verificarAlertaBackupMensal);
} else {
    verificarAlertaBackupMensal();
}

// =============================================
// GRÁFICO DE HISTÓRICO DE PREÇOS DO PRODUTO
// =============================================
let chartPrecos = null;
let chartVendas = null;

async function verGraficoPrecos(produtoId, nomeProduto) {
    document.getElementById('modalGraficoTitulo').textContent = '📊 ' + nomeProduto;
    document.getElementById('modalGrafico').classList.add('active');
    // Guarda id para aba de compras e reseta filtros
    document.getElementById('modalGrafico').dataset.produtoId = produtoId;
    const selAno = document.getElementById('filtroComprasAno');
    const selMes = document.getElementById('filtroComprasMes');
    if (selAno) selAno.innerHTML = '<option value="">Todos os anos</option>';
    if (selMes) selMes.value = '';
    carregarHistoricoCompras(produtoId, '', '');
    document.getElementById('graficoLoading').style.display = 'flex';
    document.getElementById('graficoConteudo').style.display = 'none';

    try {
        const response = await fetch(`${API_URL}?endpoint=historico_precos&produto_id=${produtoId}`);
        const data = await response.json();

        document.getElementById('graficoLoading').style.display = 'none';
        document.getElementById('graficoConteudo').style.display = 'block';

        const mesesNomes = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];

        // ---- GRÁFICO DE PREÇOS ----
        const labelsPrecos = data.historico.map(h => {
            return mesesNomes[parseInt(h.mes)-1] + '/' + h.ano.substring(2);
        });
        const custos = data.historico.map(h => parseFloat(h.preco_custo));
        const vendas = data.historico.map(h => parseFloat(h.preco_venda));

        if (chartPrecos) chartPrecos.destroy();
        const ctxP = document.getElementById('chartPrecos').getContext('2d');

        if (data.historico.length === 0) {
            document.getElementById('semDadosPrecos').style.display = 'block';
            document.getElementById('chartPrecos').style.display = 'none';
        } else {
            document.getElementById('semDadosPrecos').style.display = 'none';
            document.getElementById('chartPrecos').style.display = 'block';
            chartPrecos = new Chart(ctxP, {
                type: 'line',
                data: {
                    labels: labelsPrecos,
                    datasets: [
                        {
                            label: 'Preço de Custo (R$)',
                            data: custos,
                            borderColor: '#e74c3c',
                            backgroundColor: 'rgba(231,76,60,0.1)',
                            tension: 0.3,
                            pointRadius: 5,
                            pointHoverRadius: 7,
                            fill: true
                        },
                        {
                            label: 'Preço de Venda (R$)',
                            data: vendas,
                            borderColor: '#27ae60',
                            backgroundColor: 'rgba(39,174,96,0.1)',
                            tension: 0.3,
                            pointRadius: 5,
                            pointHoverRadius: 7,
                            fill: true
                        }
                    ]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { position: 'top' },
                        tooltip: {
                            callbacks: {
                                label: ctx => ' R$ ' + ctx.parsed.y.toFixed(2).replace('.',',')
                            }
                        }
                    },
                    scales: {
                        y: {
                            ticks: {
                                callback: v => 'R$ ' + v.toFixed(2).replace('.',',')
                            }
                        }
                    }
                }
            });
        }

        // ---- GRÁFICO DE VENDAS ----
        const labelsVendas = data.vendas.map(v => mesesNomes[parseInt(v.mes)-1] + '/' + v.ano.substring(2));
        const qtdVendida = data.vendas.map(v => parseInt(v.qtd_vendida));

        // Perspectiva de venda (média móvel dos últimos 3 meses projetada para próximos 3)
        let perspLables = [...labelsVendas];
        let perspData = qtdVendida.map(() => null);
        if (qtdVendida.length >= 2) {
            const ultimos = qtdVendida.slice(-3);
            const media = Math.round(ultimos.reduce((a,b) => a+b, 0) / ultimos.length);
            const hoje = new Date();
            for (let i = 1; i <= 3; i++) {
                const d = new Date(hoje.getFullYear(), hoje.getMonth() + i, 1);
                perspLables.push(mesesNomes[d.getMonth()] + '/' + String(d.getFullYear()).substring(2));
                perspData.push(media);
            }
        }

        if (chartVendas) chartVendas.destroy();
        const ctxV = document.getElementById('chartVendas').getContext('2d');

        if (data.vendas.length === 0) {
            document.getElementById('semDadosVendas').style.display = 'block';
            document.getElementById('chartVendas').style.display = 'none';
        } else {
            document.getElementById('semDadosVendas').style.display = 'none';
            document.getElementById('chartVendas').style.display = 'block';
            chartVendas = new Chart(ctxV, {
                type: 'bar',
                data: {
                    labels: perspLables,
                    datasets: [
                        {
                            label: 'Qtd Vendida',
                            data: qtdVendida.concat(perspData.slice(qtdVendida.length)),
                            backgroundColor: 'rgba(52,152,219,0.7)',
                            borderColor: '#2980b9',
                            borderWidth: 1
                        },
                        {
                            label: 'Perspectiva (média)',
                            data: perspData,
                            backgroundColor: 'rgba(243,156,18,0.5)',
                            borderColor: '#f39c12',
                            borderWidth: 2,
                            type: 'line',
                            borderDash: [6,4],
                            pointRadius: 5,
                            fill: false
                        }
                    ]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { position: 'top' },
                        tooltip: {
                            callbacks: {
                                label: ctx => ctx.dataset.label + ': ' + (ctx.parsed.y !== null ? ctx.parsed.y + ' un.' : '-')
                            }
                        }
                    }
                }
            });
        }

    } catch (error) {
        document.getElementById('graficoLoading').style.display = 'none';
        document.getElementById('graficoConteudo').style.display = 'block';
        console.error('Erro ao carregar histórico:', error);
        alert('Erro ao carregar histórico de preços.');
    }
}

function fecharModalGrafico() {
    document.getElementById('modalGrafico').classList.remove('active');
    if (chartPrecos) { chartPrecos.destroy(); chartPrecos = null; }
    if (chartVendas) { chartVendas.destroy(); chartVendas = null; }
}

// =============================================
// REPOSIÇÃO DE ESTOQUE
// =============================================
function abrirModalReposicao(produtoId, nomeProduto, precoCustoAtual, precoVendaAtual) {
    document.getElementById('reposicaoProdutoId').value = produtoId;
    document.getElementById('reposicaoProdutoNome').textContent = nomeProduto;
    document.getElementById('reposicaoPrecoCustoAtual').textContent = formatarMoeda(precoCustoAtual);
    document.getElementById('reposicaoPrecoCusto').value = precoCustoAtual.toFixed(2).replace('.', ',');
    document.getElementById('reposicaoPrecoVenda').value = precoVendaAtual.toFixed(2).replace('.', ',');
    document.getElementById('reposicaoQuantidade').value = '';
    document.getElementById('reposicaoObservacao').value = '';
    document.getElementById('modalReposicao').classList.add('active');
}

function fecharModalReposicao() {
    document.getElementById('modalReposicao').classList.remove('active');
}

async function salvarReposicao(event) {
    event.preventDefault();

    const produtoId  = document.getElementById('reposicaoProdutoId').value;
    const quantidade = parseInt(document.getElementById('reposicaoQuantidade').value);
    const precoCusto = parseMoeda(document.getElementById('reposicaoPrecoCusto').value);
    const precoVenda = parseMoeda(document.getElementById('reposicaoPrecoVenda').value);
    const fornecedorId = document.getElementById('reposicaoFornecedor').value;
    const observacao = document.getElementById('reposicaoObservacao').value;

    if (!quantidade || quantidade <= 0) {
        alert('Informe uma quantidade válida!');
        return;
    }
    if (!precoCusto || precoCusto <= 0) {
        alert('Informe o preço de custo!');
        return;
    }

    const btnSalvar = document.getElementById('btnSalvarReposicao');
    btnSalvar.disabled = true;
    btnSalvar.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Salvando...';

    try {
        const response = await fetch(API_URL + '?endpoint=repor_estoque', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ produto_id: produtoId, quantidade, preco_custo: precoCusto, preco_venda: precoVenda, fornecedor_id: fornecedorId || null, observacao })
        });

        // Se não for resposta 2xx, tenta ler texto para depuração
        if (!response.ok) {
            if (response.status === 401) {
                alert('Sessão expirada. Faça login novamente.');
                window.location.href = 'login.php';
                return;
            }
            const txt = await response.text();
            let errMsg = 'Falha ao repor estoque (HTTP ' + response.status + ')';
            try { const j = JSON.parse(txt); errMsg = j.error || errMsg; } catch(x) {}
            alert('Erro: ' + errMsg);
            return;
        }

        const txt = await response.text();
        let data;
        try {
            data = JSON.parse(txt);
        } catch(parseErr) {
            console.error('Resposta inválida do servidor:', txt);
            alert('Erro: Resposta inesperada do servidor. Verifique os logs.');
            return;
        }

        if (data.success) {
            fecharModalReposicao();
            carregarProdutos();
            mostrarNotificacao('Estoque reposto com sucesso! ✅', 'success');
        } else {
            alert('Erro: ' + (data.error || 'Falha ao repor estoque'));
        }
    } catch (e) {
        console.error('Erro ao repor estoque:', e);
        // Tenta mostrar a resposta real do servidor para depuração
        let detalhe = e && e.message ? e.message : String(e);
        alert('Erro ao salvar reposição: ' + detalhe + '\n\nVerifique o console do navegador (F12) para mais detalhes.');
    } finally {
        btnSalvar.disabled = false;
        btnSalvar.innerHTML = '<i class="fas fa-check"></i> Confirmar Reposição';
    }
}

function parseMoeda(valor) {
    if (!valor) return 0;
    return parseFloat(valor.toString().replace(/\./g, '').replace(',', '.')) || 0;
}

// Instância global do gráfico mensal de compras
let chartComprasMensal = null;

async function carregarHistoricoCompras(produtoId, ano = '', mes = '') {
    const tbody = document.getElementById('tbodyHistoricoCompras');
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#888;"><i class="fas fa-spinner fa-spin"></i> Carregando...</td></tr>';

    const mesesPT = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

    try {
        let url = `${API_URL}?endpoint=historico_compras&produto_id=${produtoId}`;
        if (ano) url += `&ano=${ano}`;
        if (mes) url += `&mes=${mes}`;

        const response = await fetch(url);
        if (!response.ok) {
            if (response.status === 401) { window.location.href = 'login.php'; return; }
            throw new Error('HTTP ' + response.status);
        }
        const data = await response.json();

        // Preenche o select de anos
        const selectAno = document.getElementById('filtroComprasAno');
        if (selectAno && data.anos) {
            const anoAtual = selectAno.value;
            selectAno.innerHTML = '<option value="">Todos os anos</option>';
            data.anos.forEach(a => {
                selectAno.innerHTML += `<option value="${a}" ${a == anoAtual ? 'selected' : ''}>${a}</option>`;
            });
        }

        // Renderiza gráfico mensal
        renderizarGraficoComprasMensal(data.mensal || [], mesesPT);
        // Salva dados mensais para o gráfico de meta
        document._historicoMensal = data.mensal || [];
        renderizarGraficoMetaCusto(data.mensal || [], mesesPT);

        if (!data.compras || data.compras.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#aaa;padding:20px;"><i class="fas fa-inbox"></i><br>Nenhuma compra registrada para este filtro.</td></tr>';
            return;
        }

        let lastLabel = '';
        let rows = '';
        data.compras.forEach(c => {
            let label = '';
            if (c.data_compra) {
                const d = new Date(c.data_compra.replace(' ', 'T'));
                if (!isNaN(d)) label = mesesPT[d.getMonth()] + ' de ' + d.getFullYear();
            }
            if (label && label !== lastLabel) {
                rows += `<tr><td colspan="5" style="background:#f3e8ff;color:#7c3aed;font-weight:bold;font-size:13px;padding:8px 12px;border-top:2px solid #d8b4fe;letter-spacing:0.5px;">
                    <i class="fas fa-calendar-alt" style="margin-right:6px;"></i>${label}
                </td></tr>`;
                lastLabel = label;
            }
            const variacao = c.preco_custo_anterior && parseFloat(c.preco_custo_anterior) > 0 && c.preco_custo_anterior != c.preco_custo
                ? (parseFloat(c.preco_custo) > parseFloat(c.preco_custo_anterior)
                    ? `<span style="color:#e74c3c;font-size:11px;">▲ +${formatarMoeda(c.preco_custo - c.preco_custo_anterior)}</span>`
                    : `<span style="color:#27ae60;font-size:11px;">▼ -${formatarMoeda(c.preco_custo_anterior - c.preco_custo)}</span>`)
                : '<span style="color:#aaa;font-size:11px;">= sem alteração</span>';
            rows += `<tr>
                <td>${formatarDataBR(c.data_compra)}</td>
                <td style="text-align:center;font-weight:bold;">${c.quantidade} un.</td>
                <td>${formatarMoeda(c.preco_custo)} ${variacao}</td>
                <td>${c.fornecedor_nome || '-'}</td>
                <td style="font-size:11px;color:#888;">${c.observacao || '-'}</td>
            </tr>`;
        });
        tbody.innerHTML = rows;

        // Guarda dados para exportação
        document._historicoComprasData = data.compras;
        document._historicoComprasProdutoId = produtoId;

    } catch(e) {
        console.error('Erro ao carregar histórico:', e);
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;color:#e74c3c;padding:20px;"><i class="fas fa-exclamation-triangle"></i> Erro ao carregar dados. Tente novamente.</td></tr>`;
    }
}

function renderizarGraficoComprasMensal(mensal, mesesPT) {
    const canvas = document.getElementById('chartComprasMensal');
    const container = document.getElementById('graficoComprasMensalContainer');
    if (!canvas || !container) return;

    if (!mensal || mensal.length === 0) {
        container.style.display = 'none';
        return;
    }
    container.style.display = 'block';

    const labels = mensal.map(m => {
        const [ano, mesNum] = m.mes_ano.split('-');
        return mesesPT[parseInt(mesNum) - 1].substring(0, 3) + '/' + ano.substring(2);
    });
    const precos = mensal.map(m => parseFloat(parseFloat(m.preco_medio).toFixed(2)));
    const qtds = mensal.map(m => parseInt(m.qtd_total));

    // Identificar pico MÁXIMO e MÍNIMO
    const maxPreco = Math.max(...precos);
    const minPreco = Math.min(...precos);
    const idxMax = precos.indexOf(maxPreco);
    const idxMin = precos.indexOf(minPreco);

    // Cores dos pontos: vermelho no pico alto, verde no pico baixo, laranja nos demais
    const pontoCores = precos.map((v, i) => {
        if (i === idxMax) return '#e74c3c';
        if (i === idxMin) return '#27ae60';
        return '#e67e22';
    });
    const pontoTamanhos = precos.map((v, i) => (i === idxMax || i === idxMin) ? 10 : 5);

    if (chartComprasMensal) {
        chartComprasMensal.destroy();
        chartComprasMensal = null;
    }

    chartComprasMensal = new Chart(canvas, {
        type: 'line',
        data: {
            labels,
            datasets: [
                {
                    label: 'Preço Médio de Custo (R$)',
                    data: precos,
                    borderColor: '#e67e22',
                    backgroundColor: 'rgba(230,126,34,0.08)',
                    fill: true,
                    tension: 0.3,
                    pointBackgroundColor: pontoCores,
                    pointBorderColor: pontoCores,
                    pointRadius: pontoTamanhos,
                    pointHoverRadius: 10,
                    yAxisID: 'yPreco'
                },
                {
                    label: 'Qtd. Comprada',
                    data: qtds,
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52,152,219,0.08)',
                    fill: false,
                    tension: 0.3,
                    borderDash: [5,3],
                    pointBackgroundColor: '#3498db',
                    pointRadius: 4,
                    yAxisID: 'yQtd'
                }
            ]
        },
        options: {
            responsive: true,
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: { position: 'top' },
                title: {
                    display: true,
                    text: '📈 Evolução Mensal — 🔴 Pico ALTO (caro) | 🟢 Pico BAIXO (barato) — avalie trocar fornecedor no mês caro',
                    font: { size: 12 },
                    color: '#555'
                },
                tooltip: {
                    callbacks: {
                        label: ctx => {
                            if (ctx.datasetIndex === 0) {
                                const v = parseFloat(ctx.raw).toFixed(2).replace('.',',');
                                const isMax = ctx.dataIndex === idxMax;
                                const isMin = ctx.dataIndex === idxMin;
                                let tag = isMax ? ' 🔴 PICO ALTO — considere trocar fornecedor!' : (isMin ? ' 🟢 PICO BAIXO — melhor preço!' : '');
                                return ` Preço médio: R$ ${v}${tag}`;
                            }
                            return ` Qtd comprada: ${ctx.raw} un.`;
                        }
                    }
                }
            },
            scales: {
                yPreco: {
                    type: 'linear',
                    position: 'left',
                    title: { display: true, text: 'Preço (R$)', color: '#e67e22' },
                    ticks: {
                        color: '#e67e22',
                        callback: v => 'R$ ' + parseFloat(v).toFixed(2).replace('.',',')
                    }
                },
                yQtd: {
                    type: 'linear',
                    position: 'right',
                    title: { display: true, text: 'Qtd', color: '#3498db' },
                    ticks: { color: '#3498db' },
                    grid: { drawOnChartArea: false }
                }
            }
        }
    });
}


// =============================================
// GRÁFICO: CUSTO REAL VS META DE CUSTO
// =============================================
let chartMetaCusto = null;

function renderizarGraficoMetaCusto(mensal, mesesPT) {
    const canvas  = document.getElementById('chartMetaCusto');
    const container = document.getElementById('graficoMetaCustoContainer');
    if (!canvas || !container) return;

    if (!mensal || mensal.length === 0) {
        container.style.display = 'none';
        return;
    }
    container.style.display = 'block';

    const meta = parseFloat(document.getElementById('inputMetaCusto')?.value) || null;

    const labels  = mensal.map(m => {
        const [ano, mesNum] = m.mes_ano.split('-');
        return (mesesPT[parseInt(mesNum)-1]||'').substring(0,3) + '/' + ano.substring(2);
    });
    const custos  = mensal.map(m => parseFloat(parseFloat(m.preco_medio).toFixed(2)));

    // Diferença em relação à meta (ou ao valor médio geral se sem meta)
    const baseMeta = meta !== null ? meta : (custos.reduce((a,b)=>a+b,0)/custos.length);

    const diferencas = custos.map(c => parseFloat((c - baseMeta).toFixed(2)));
    const cores = diferencas.map(d => d > 0 ? 'rgba(229,62,62,0.85)' : 'rgba(56,161,105,0.85)');
    const coresBorda = diferencas.map(d => d > 0 ? '#c53030' : '#276749');

    if (chartMetaCusto) { chartMetaCusto.destroy(); chartMetaCusto = null; }

    chartMetaCusto = new Chart(canvas, {
        type: 'bar',
        data: {
            labels,
            datasets: [
                {
                    label: meta !== null ? 'Diferença vs Meta (R$)' : 'Diferença vs Média (R$)',
                    data: diferencas,
                    backgroundColor: cores,
                    borderColor: coresBorda,
                    borderWidth: 1.5,
                    borderRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top' },
                title: {
                    display: true,
                    text: meta !== null
                        ? '📊 Custo Real vs Meta de R$ ' + baseMeta.toFixed(2).replace('.',',') + ' — barras acima = gastou demais | abaixo = economizou'
                        : '📊 Custo Real vs Média dos meses — defina uma meta acima para comparar',
                    font: { size: 11 },
                    color: '#555'
                },
                tooltip: {
                    callbacks: {
                        label: function(ctx) {
                            var v = ctx.raw;
                            var sinal = v >= 0 ? '+' : '';
                            var prefixo = v > 0 ? '🔴 Acima: ' : '🟢 Economia: ';
                            return prefixo + sinal + 'R$ ' + v.toFixed(2).replace('.',',');
                        },
                        afterLabel: function(ctx) {
                            var idx = ctx.dataIndex;
                            return 'Custo real: R$ ' + custos[idx].toFixed(2).replace('.',',') +
                                   ' | Meta: R$ ' + baseMeta.toFixed(2).replace('.',',');
                        }
                    }
                },
                annotation: {}
            },
            scales: {
                y: {
                    beginAtZero: false,
                    title: { display: true, text: 'Diferença (R$)' },
                    ticks: {
                        callback: function(v) {
                            return (v >= 0 ? '+' : '') + 'R$ ' + parseFloat(v).toFixed(2).replace('.',',');
                        }
                    },
                    grid: {
                        color: function(ctx) {
                            return ctx.tick && ctx.tick.value === 0 ? '#2b6cb0' : 'rgba(0,0,0,0.05)';
                        },
                        lineWidth: function(ctx) {
                            return ctx.tick && ctx.tick.value === 0 ? 2 : 1;
                        }
                    }
                }
            }
        }
    });
}

function aplicarMetaCusto() {
    // Re-renderiza com a nova meta usando os dados já carregados
    const dados = document._historicoMensal;
    if (!dados || dados.length === 0) {
        mostrarNotificacao('Carregue o histórico de um produto primeiro!', 'warning');
        return;
    }
    const mesesPT = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
    renderizarGraficoMetaCusto(dados, mesesPT);
    mostrarNotificacao('Meta atualizada no gráfico! ✅', 'success');
}
// =============================================

function exportarHistoricoComprasCSV() {
    const dados = document._historicoComprasData;
    if (!dados || dados.length === 0) { alert('Nenhum dado para exportar.'); return; }
    const mesesPT = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
    let csv = 'Data;Quantidade;Preco Custo;Preco Anterior;Fornecedor;Observacao\n';
    dados.forEach(c => {
        csv += `"${c.data_compra}";"${c.quantidade}";"${parseFloat(c.preco_custo).toFixed(2).replace('.',',')}";"${parseFloat(c.preco_custo_anterior||0).toFixed(2).replace('.',',')}";` +
               `"${(c.fornecedor_nome||'').replace(/"/g,'""')}";"${(c.observacao||'').replace(/"/g,'""')}"\n`;
    });
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'historico_compras.csv';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function importarHistoricoComprasCSV(event) {
    const file = event.target.files[0];
    if (!file) return;
    const produtoId = document._historicoComprasProdutoId;
    if (!produtoId) { alert('Erro: produto não identificado.'); return; }

    const reader = new FileReader();
    reader.onload = async e => {
        const text = e.target.result.replace(/^\uFEFF/, '');
        const linhas = text.split('\n').slice(1).filter(l => l.trim());
        const registros = linhas.map(l => {
            const cols = l.split(';').map(c => c.replace(/^"|"$/g,'').trim());
            return { data_compra: cols[0], quantidade: cols[1], preco_custo: cols[2], preco_custo_anterior: cols[3], observacao: cols[5] };
        }).filter(r => r.data_compra && r.preco_custo);

        if (registros.length === 0) { alert('Nenhum registro válido no arquivo.'); return; }

        try {
            const resp = await fetch(`${API_URL}?endpoint=historico_compras&acao=importar`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ produto_id: produtoId, linhas: registros })
            });
            const data = await resp.json();
            if (data.success) {
                mostrarNotificacao(`${data.importados} registros importados com sucesso! ✅`, 'success');
                // Recarrega com filtros atuais
                const ano = document.getElementById('filtroComprasAno')?.value || '';
                const mes = document.getElementById('filtroComprasMes')?.value || '';
                carregarHistoricoCompras(produtoId, ano, mes);
            } else {
                alert('Erro ao importar: ' + (data.error || 'Falha desconhecida'));
            }
        } catch(err) {
            console.error(err);
            alert('Erro de conexão ao importar.');
        }
    };
    reader.readAsText(file, 'UTF-8');
    event.target.value = ''; // reset para permitir reimportar mesmo arquivo
}

function formatarDataBR(dataStr) {
    if (!dataStr) return '-';
    const d = new Date(dataStr.replace(' ', 'T'));
    if (isNaN(d)) return dataStr;
    return d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR', {hour:'2-digit',minute:'2-digit'});
}

function aplicarFiltroCompras() {
    const produtoId = document.getElementById('modalGrafico')?.dataset?.produtoId;
    if (!produtoId) return;
    const ano = document.getElementById('filtroComprasAno')?.value || '';
    const mes = document.getElementById('filtroComprasMes')?.value || '';
    carregarHistoricoCompras(parseInt(produtoId), ano, mes);
}

function mudarAbaGrafico(aba) {
    const painelGrafico = document.getElementById('painelGrafico');
    const painelCompras = document.getElementById('painelCompras');
    const btnGrafico    = document.getElementById('abaGrafico');
    const btnCompras    = document.getElementById('abaCompras');
    if (aba === 'grafico') {
        painelGrafico.style.display = 'block';
        painelCompras.style.display = 'none';
        btnGrafico.style.color = '#8e44ad';
        btnGrafico.style.borderBottomColor = '#8e44ad';
        btnCompras.style.color = '#888';
        btnCompras.style.borderBottomColor = 'transparent';
    } else {
        painelGrafico.style.display = 'none';
        painelCompras.style.display = 'block';
        btnGrafico.style.color = '#888';
        btnGrafico.style.borderBottomColor = 'transparent';
        btnCompras.style.color = '#e67e22';
        btnCompras.style.borderBottomColor = '#e67e22';
    }
}
