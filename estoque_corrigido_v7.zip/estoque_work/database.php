<?php
// Configurar timezone para horário de Brasília (GMT-3)
date_default_timezone_set('America/Sao_Paulo');

class Database {
    private $db;

    public function __construct() {
        $this->db = new PDO('sqlite:' . __DIR__ . '/estoque.db');
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Criar função personalizada para obter data/hora no timezone de Brasília (GMT-3)
        // Subtrai 3 horas do UTC para obter horário de Brasília
        $this->db->sqliteCreateFunction('DATETIME_BR', function() {
            $utc_time = new DateTime('now', new DateTimeZone('UTC'));
            $utc_time->modify('-3 hours');
            return $utc_time->format('Y-m-d H:i:s');
        }, 0);

        $this->createTables();
    }

    private function createTables() {
        // Tabela de usuários - MODIFICADA para usar username ao invés de email
        $this->db->exec("CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            username TEXT UNIQUE NOT NULL,
            senha TEXT NOT NULL,
            tipo TEXT DEFAULT 'usuario', -- 'admin' ou 'usuario'
            nivel_admin TEXT DEFAULT NULL, -- NULL, 'master', 'gerente'
            ativo INTEGER DEFAULT 1,
            data_cadastro DATETIME DEFAULT (datetime('now', '-3 hours'))
        )");

        // Tabela de permissões
        $this->db->exec("CREATE TABLE IF NOT EXISTS permissoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            dashboard INTEGER DEFAULT 1,
            produtos INTEGER DEFAULT 1,
            movimentacoes INTEGER DEFAULT 1,
            clientes INTEGER DEFAULT 1,
            fornecedores INTEGER DEFAULT 1,
            alertas INTEGER DEFAULT 1,
            administracao INTEGER DEFAULT 0,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
        )");

        // Tabela de clientes
        $this->db->exec("CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            cpf_cnpj TEXT,
            telefone TEXT,
            email TEXT,
            endereco TEXT,
            cidade TEXT,
            estado TEXT,
            cep TEXT,
            data_cadastro DATETIME DEFAULT (datetime('now', '-3 hours'))
        )");

        // Tabela de fornecedores
        $this->db->exec("CREATE TABLE IF NOT EXISTS fornecedores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            cnpj TEXT,
            telefone TEXT,
            email TEXT,
            endereco TEXT,
            cidade TEXT,
            estado TEXT,
            cep TEXT,
            contato_responsavel TEXT,
            data_cadastro DATETIME DEFAULT (datetime('now', '-3 hours'))
        )");

        // Tabela de categorias
        $this->db->exec("CREATE TABLE IF NOT EXISTS categorias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            descricao TEXT
        )");

        // Tabela de produtos
        $this->db->exec("CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo_barras TEXT,
            nome TEXT NOT NULL,
            descricao TEXT,
            categoria_id INTEGER,
            fornecedor_id INTEGER,
            preco_custo REAL NOT NULL,
            preco_venda REAL NOT NULL,
            estoque_atual INTEGER DEFAULT 0,
            estoque_minimo INTEGER DEFAULT 0,
            foto TEXT,
            data_cadastro DATETIME DEFAULT (datetime('now', '-3 hours')),
            FOREIGN KEY (categoria_id) REFERENCES categorias(id),
            FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id)
        )");

        // Tabela de movimentações
        $this->db->exec("CREATE TABLE IF NOT EXISTS movimentacoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            produto_id INTEGER NOT NULL,
            tipo TEXT NOT NULL, -- 'entrada' ou 'saida'
            quantidade INTEGER NOT NULL,
            valor_unitario REAL,
            valor_total REAL,
            cliente_id INTEGER,
            fornecedor_id INTEGER,
            observacao TEXT,
            data_movimentacao DATETIME DEFAULT (datetime('now', '-3 hours')),
            FOREIGN KEY (produto_id) REFERENCES produtos(id),
            FOREIGN KEY (cliente_id) REFERENCES clientes(id),
            FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id)
        )");

        // Tabela de histórico de preços dos produtos
        $this->db->exec("CREATE TABLE IF NOT EXISTS historico_precos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            produto_id INTEGER NOT NULL,
            preco_custo REAL NOT NULL,
            preco_venda REAL NOT NULL,
            data_registro DATETIME,
            FOREIGN KEY (produto_id) REFERENCES produtos(id)
        )");

        // Tabela de histórico de compras (reposição de estoque)
        $this->db->exec("CREATE TABLE IF NOT EXISTS historico_compras (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            produto_id INTEGER NOT NULL,
            quantidade INTEGER NOT NULL,
            preco_custo REAL NOT NULL,
            preco_custo_anterior REAL,
            fornecedor_id INTEGER,
            observacao TEXT,
            data_compra DATETIME,
            FOREIGN KEY (produto_id) REFERENCES produtos(id),
            FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id)
        )");

        // Tabela de auditoria de backup/restore
        $this->db->exec("CREATE TABLE IF NOT EXISTS auditoria_backup (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            usuario_nome TEXT NOT NULL,
            tipo_acao TEXT NOT NULL, -- 'backup' ou 'restore'
            nome_arquivo TEXT,
            data_hora DATETIME DEFAULT (datetime('now', '-3 hours')),
            ip_address TEXT,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        )");

        // Inserir dados de exemplo
        $this->insertSampleData();
    }

    private function insertSampleData() {
        // Criar usuário admin padrão se não existir
        $stmt = $this->db->query("SELECT COUNT(*) FROM usuarios");
        if ($stmt->fetchColumn() == 0) {
            // Senha: Admin@2024!
            $senhaHash = password_hash('Admin@2024!', PASSWORD_DEFAULT);
            $stmt = $this->db->prepare("INSERT INTO usuarios (nome, username, senha, tipo, nivel_admin) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute(['Administrador do Sistema', 'admin', $senhaHash, 'admin', 'master']);

            // Criar permissões totais para admin
            $this->db->exec("INSERT INTO permissoes (usuario_id, dashboard, produtos, movimentacoes, clientes, fornecedores, alertas, administracao)
                VALUES (1, 1, 1, 1, 1, 1, 1, 1)
            ");

            // Criar um usuário de exemplo (vendedor com permissões limitadas)
            $senhaUsuario = password_hash('vendedor123', PASSWORD_DEFAULT);
            $stmt = $this->db->prepare("INSERT INTO usuarios (nome, username, senha, tipo) VALUES (?, ?, ?, ?)");
            $stmt->execute(['Vendedor Exemplo', 'vendedor', $senhaUsuario, 'usuario']);

            // Permissões limitadas: sem acesso a fornecedores e administração
            $this->db->exec("INSERT INTO permissoes (usuario_id, dashboard, produtos, movimentacoes, clientes, fornecedores, alertas, administracao)
                VALUES (2, 1, 1, 1, 1, 0, 1, 0)
            ");
        }

        // Verificar se já existem categorias
        $stmt = $this->db->query("SELECT COUNT(*) FROM categorias");
        if ($stmt->fetchColumn() == 0) {
            $this->db->exec("INSERT INTO categorias (nome, descricao) VALUES
                ('Eletrônicos', 'Produtos eletrônicos em geral'),
                ('Alimentos', 'Produtos alimentícios'),
                ('Bebidas', 'Bebidas diversas'),
                ('Limpeza', 'Produtos de limpeza'),
                ('Higiene', 'Produtos de higiene pessoal')
            ");
        }
    }

    public function getConnection() {
        return $this->db;
    }
}
?>
