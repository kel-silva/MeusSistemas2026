<!-- Seção Produtos -->
<div id="produtos" class="section">
    <div class="section-header">
        <div>
            <h2>Produtos</h2>
            <p>Gerencie seu catálogo de produtos</p>
        </div>
        <div class="section-actions">
            <input type="text" id="searchProduto" class="search-input" placeholder="Buscar produto..." onkeyup="filtrarProdutos()">
            <button class="btn btn-primary" onclick="abrirLeitorBarras()">
                <i class="fas fa-barcode"></i> Ler Código de Barras
            </button>
            <button class="btn btn-primary" onclick="abrirModalProduto()">
                <i class="fas fa-plus"></i> Novo Produto
            </button>
        </div>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th style="width: 80px;">Foto</th>
                    <th>Código de Barras</th>
                    <th>Nome</th>
                    <th>Categoria</th>
                    <th>Estoque</th>
                    <th>Preço Custo</th>
                    <th>Preço Venda</th>
                    <th style="width: 120px;">Ações</th>
                </tr>
            </thead>
            <tbody id="listaProdutos">
                <tr>
                    <td colspan="8" class="empty-state">
                        <i class="fas fa-box-open"></i>
                        <p>Carregando...</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Produto -->
<div id="modalProduto" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalProdutoTitulo">Novo Produto</h3>
            <span class="close" onclick="fecharModal('modalProduto')">&times;</span>
        </div>
        <form id="formProduto" onsubmit="salvarProduto(event)">
            <input type="hidden" id="produtoId">
            <input type="hidden" id="produtoFotoPath">

            <div class="form-row">
                <div class="form-group">
                    <label>Código de Barras</label>
                    <input type="text" id="produtoCodigoBarras" class="form-control" placeholder="Digite ou escaneie">
                </div>
                <div class="form-group">
                    <label>Nome *</label>
                    <input type="text" id="produtoNome" class="form-control" required>
                </div>
            </div>

            <div class="form-group">
                <label>Descrição</label>
                <textarea id="produtoDescricao" class="form-control" rows="2"></textarea>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Categoria</label>
                    <select id="produtoCategoria" class="form-control">
                        <option value="">Selecione...</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Fornecedor *</label>
                    <select id="produtoFornecedor" class="form-control" required>
                        <option value="">Selecione...</option>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Preço de Custo *</label>
                    <input type="text" id="produtoPrecoCusto" class="form-control" data-mask="dinheiro" required placeholder="0,00">
                </div>
                <div class="form-group">
                    <label>Preço de Venda *</label>
                    <input type="text" id="produtoPrecoVenda" class="form-control" data-mask="dinheiro" required placeholder="0,00">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Estoque Atual *</label>
                    <input type="number" id="produtoEstoqueAtual" class="form-control" min="0" required value="0">
                </div>
                <div class="form-group">
                    <label>Estoque Mínimo *</label>
                    <input type="number" id="produtoEstoqueMinimo" class="form-control" min="0" required value="10">
                </div>
            </div>

            <div class="form-group">
                <label>Foto do Produto</label>
                <input type="file" id="produtoFoto" class="form-control" accept="image/*" onchange="previewFoto(event)">
                <img id="previewProdutoFoto" style="display: none; max-width: 200px; margin-top: 10px; border-radius: 8px;">
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="fecharModal('modalProduto')">Cancelar</button>
                <button type="submit" class="btn btn-primary">Salvar</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Leitor de Código de Barras -->
<div id="modalBarcode" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Leitor de Código de Barras</h3>
            <span class="close" onclick="fecharLeitorBarras()">&times;</span>
        </div>
        <div style="padding: 20px;">
            <p style="margin-bottom: 15px; text-align: center; color: #666;">
                Posicione o código de barras na frente da câmera
            </p>
            <div id="barcode-scanner" style="width: 100%; height: 400px; background: #000; border-radius: 8px;"></div>
        </div>
    </div>
</div>

<!-- Modal Reposição de Estoque -->
<div id="modalReposicao" class="modal">
    <div class="modal-content" style="max-width: 550px; width: 95%;">
        <div class="modal-header" style="background: linear-gradient(135deg, #e67e22, #f39c12);">
            <h3 style="color:#fff;"><i class="fas fa-cart-plus"></i> Repor Estoque</h3>
            <span class="close" onclick="fecharModalReposicao()" style="color:#fff;">&times;</span>
        </div>
        <form id="formReposicao" onsubmit="salvarReposicao(event)">
            <input type="hidden" id="reposicaoProdutoId">
            <div style="padding: 20px;">
                <div style="background:#fff8f0; border-left:4px solid #f39c12; padding:12px 16px; border-radius:6px; margin-bottom:18px;">
                    <strong style="font-size:16px;" id="reposicaoProdutoNome"></strong><br>
                    <small style="color:#888;">Preço de custo atual: <strong id="reposicaoPrecoCustoAtual" style="color:#e67e22;"></strong></small>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Quantidade a Repor *</label>
                        <input type="number" id="reposicaoQuantidade" class="form-control" min="1" required placeholder="Ex: 50">
                    </div>
                    <div class="form-group">
                        <label>Novo Preço de Custo (R$) *</label>
                        <input type="text" id="reposicaoPrecoCusto" class="form-control" data-mask="dinheiro" required placeholder="0,00">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Novo Preço de Venda (R$)</label>
                        <input type="text" id="reposicaoPrecoVenda" class="form-control" data-mask="dinheiro" placeholder="0,00">
                    </div>
                    <div class="form-group">
                        <label>Fornecedor</label>
                        <select id="reposicaoFornecedor" class="form-control">
                            <option value="">Selecione...</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label>Observação</label>
                    <input type="text" id="reposicaoObservacao" class="form-control" placeholder="Ex: Nota fiscal 1234, promoção, etc.">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="fecharModalReposicao()">Cancelar</button>
                <button type="submit" id="btnSalvarReposicao" class="btn" style="background:#e67e22;color:#fff;">
                    <i class="fas fa-check"></i> Confirmar Reposição
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Gráfico de Preços -->
<div id="modalGrafico" class="modal">
    <div class="modal-content" style="max-width: 860px; width: 95%;">
        <div class="modal-header" style="background: linear-gradient(135deg, #8e44ad, #9b59b6);">
            <h3 id="modalGraficoTitulo" style="color:#fff;">Histórico de Preços</h3>
            <span class="close" onclick="fecharModalGrafico()" style="color:#fff;">&times;</span>
        </div>
        <div style="padding: 0;">
            <!-- Abas -->
            <div style="display:flex; border-bottom:2px solid #e0e0e0; background:#f8f9fa;">
                <button id="abaGrafico" onclick="mudarAbaGrafico('grafico')" style="padding:12px 24px; border:none; background:none; cursor:pointer; font-weight:bold; color:#8e44ad; border-bottom:3px solid #8e44ad; margin-bottom:-2px;">
                    <i class="fas fa-chart-line"></i> Evolução de Preços
                </button>
                <button id="abaCompras" onclick="mudarAbaGrafico('compras')" style="padding:12px 24px; border:none; background:none; cursor:pointer; font-weight:600; color:#888; border-bottom:3px solid transparent; margin-bottom:-2px;">
                    <i class="fas fa-shopping-basket"></i> Histórico de Compras
                </button>
            </div>

            <!-- Aba Gráfico -->
            <div id="painelGrafico" style="padding:20px;">
                <!-- Loading -->
                <div id="graficoLoading" style="display:flex; align-items:center; justify-content:center; height:200px; flex-direction:column; gap:12px;">
                    <i class="fas fa-spinner fa-spin fa-2x" style="color:#8e44ad;"></i>
                    <p style="color:#666;">Carregando dados...</p>
                </div>
                <!-- Conteúdo -->
                <div id="graficoConteudo" style="display:none;">
                    <div style="margin-bottom: 30px;">
                        <h4 style="margin-bottom: 12px; color:#444;"><i class="fas fa-tag" style="color:#e74c3c;"></i> Evolução dos Preços (Custo e Venda)</h4>
                        <p id="semDadosPrecos" style="display:none; color:#888; text-align:center; padding:20px; background:#f8f9fa; border-radius:8px;">
                            <i class="fas fa-info-circle"></i> Nenhum histórico de preços registrado ainda.<br>
                            <small>Os preços serão registrados ao salvar/editar este produto.</small>
                        </p>
                        <canvas id="chartPrecos" height="200"></canvas>
                    </div>
                    <hr style="margin: 20px 0; border-color:#eee;">
                    <div>
                        <h4 style="margin-bottom: 12px; color:#444;"><i class="fas fa-shopping-cart" style="color:#3498db;"></i> Perspectiva de Vendas por Mês</h4>
                        <p id="semDadosVendas" style="display:none; color:#888; text-align:center; padding:20px; background:#f8f9fa; border-radius:8px;">
                            <i class="fas fa-info-circle"></i> Nenhuma venda (saída) registrada para este produto ainda.
                        </p>
                        <canvas id="chartVendas" height="180"></canvas>
                        <p style="font-size:11px; color:#aaa; margin-top:8px; text-align:center;">
                            <i class="fas fa-info-circle"></i> Perspectiva calculada com base na média dos últimos meses com saídas registradas.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Aba Histórico de Compras -->
            <div id="painelCompras" style="padding:20px; display:none;">

                <!-- Barra de filtros + ações -->
                <div style="display:flex; flex-wrap:wrap; align-items:center; gap:10px; margin-bottom:14px;">
                    <h4 style="margin:0; color:#444; flex:1 1 auto;"><i class="fas fa-shopping-basket" style="color:#e67e22;"></i> Histórico de Compras / Reposições</h4>
                    <!-- Filtros -->
                    <select id="filtroComprasAno" onchange="aplicarFiltroCompras()"
                        style="padding:5px 10px; border:1px solid #ddd; border-radius:6px; font-size:13px; cursor:pointer;">
                        <option value="">Todos os anos</option>
                    </select>
                    <select id="filtroComprasMes" onchange="aplicarFiltroCompras()"
                        style="padding:5px 10px; border:1px solid #ddd; border-radius:6px; font-size:13px; cursor:pointer;">
                        <option value="">Todos os meses</option>
                        <option value="1">Janeiro</option><option value="2">Fevereiro</option>
                        <option value="3">Março</option><option value="4">Abril</option>
                        <option value="5">Maio</option><option value="6">Junho</option>
                        <option value="7">Julho</option><option value="8">Agosto</option>
                        <option value="9">Setembro</option><option value="10">Outubro</option>
                        <option value="11">Novembro</option><option value="12">Dezembro</option>
                    </select>
                    <!-- Botões exportar/importar -->
                    <button onclick="exportarHistoricoComprasCSV()" title="Exportar CSV"
                        style="padding:5px 12px; background:#27ae60; color:#fff; border:none; border-radius:6px; cursor:pointer; font-size:13px; display:flex; align-items:center; gap:5px;">
                        <i class="fas fa-file-csv"></i> Exportar CSV
                    </button>
                    <label title="Importar CSV" style="padding:5px 12px; background:#3498db; color:#fff; border:none; border-radius:6px; cursor:pointer; font-size:13px; display:flex; align-items:center; gap:5px; margin:0;">
                        <i class="fas fa-file-import"></i> Importar CSV
                        <input type="file" accept=".csv" onchange="importarHistoricoComprasCSV(event)" style="display:none;">
                    </label>
                </div>

                <!-- Gráfico mensal -->
                <div id="graficoComprasMensalContainer" style="display:none; background:#fff8f0; border:1px solid #fde8cc; border-radius:10px; padding:16px; margin-bottom:18px;">
                    <p style="font-size:12px; color:#888; margin:0 0 8px 0; text-align:right;">
                        <i class="fas fa-lightbulb" style="color:#e67e22;"></i>
                        <strong style="color:#e67e22;">Dica:</strong> Preços subindo? Avalie trocar de fornecedor ou reduzir pedidos.
                    </p>
                    <canvas id="chartComprasMensal" style="max-height:260px;"></canvas>
                    <div style="display:flex; gap:18px; justify-content:center; margin-top:10px; font-size:12px; flex-wrap:wrap;">
                        <span><span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:#e74c3c;margin-right:5px;"></span><strong style="color:#e74c3c;">Pico ALTO</strong> — mês mais caro (considere trocar fornecedor)</span>
                        <span><span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:#27ae60;margin-right:5px;"></span><strong style="color:#27ae60;">Pico BAIXO</strong> — mês mais barato (melhor condição)</span>
                        <span><span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:#e67e22;margin-right:5px;"></span>Meses normais</span>
                    </div>
                </div>


                <!-- ================================================== -->
                <!-- GRÁFICO: CUSTO REAL VS META DE CUSTO POR MÊS        -->
                <!-- ================================================== -->
                <div id="graficoMetaCustoContainer" style="display:none; background:#f0f7ff; border:1px solid #bee3f8; border-radius:10px; padding:16px; margin-bottom:18px;">
                    <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px; margin-bottom:12px;">
                        <div style="font-size:13px; font-weight:600; color:#2b6cb0;">
                            <i class="fas fa-bullseye" style="color:#3182ce; margin-right:6px;"></i>
                            Custo Real vs Meta de Custo por Mês
                        </div>
                        <div style="display:flex; align-items:center; gap:8px;">
                            <label style="font-size:12px; color:#555; font-weight:600;">Meta mensal (R$):</label>
                            <input type="number" id="inputMetaCusto" min="0" step="0.01" placeholder="Ex: 150,00"
                                style="width:110px; padding:5px 8px; border:1.5px solid #3182ce; border-radius:6px; font-size:13px; text-align:right;">
                            <button onclick="aplicarMetaCusto()"
                                style="background:#3182ce; color:#fff; border:none; border-radius:6px; padding:5px 12px; font-size:12px; cursor:pointer; font-weight:600;">
                                <i class="fas fa-check"></i> Aplicar
                            </button>
                        </div>
                    </div>
                    <p style="font-size:11px; color:#718096; margin:0 0 10px 0;">
                        <i class="fas fa-info-circle" style="color:#3182ce;"></i>
                        Barras <strong style="color:#e53e3e;">vermelhas acima</strong> = meses que <strong>ultrapassaram</strong> a meta (gastou demais) &nbsp;|&nbsp;
                        Barras <strong style="color:#38a169;">verdes abaixo</strong> = meses que ficaram <strong>abaixo</strong> da meta (economia!)
                    </p>
                    <canvas id="chartMetaCusto" style="max-height:280px;"></canvas>
                    <div style="display:flex; gap:18px; justify-content:center; margin-top:10px; font-size:12px; flex-wrap:wrap;">
                        <span><span style="display:inline-block;width:14px;height:14px;background:#e53e3e;border-radius:3px;margin-right:5px;"></span><strong style="color:#e53e3e;">Acima da meta</strong> — gastou mais que o planejado</span>
                        <span><span style="display:inline-block;width:14px;height:14px;background:#38a169;border-radius:3px;margin-right:5px;"></span><strong style="color:#38a169;">Abaixo da meta</strong> — economizou neste mês</span>
                        <span><span style="display:inline-block;width:14px;height:14px;background:#a0aec0;border-radius:3px;margin-right:5px;"></span>Linha da meta</span>
                    </div>
                </div>

                <!-- Tabela -->
                <div style="overflow-x:auto;">
                    <table style="width:100%; border-collapse:collapse; font-size:13px;">
                        <thead>
                            <tr style="background:#f8f9fa;">
                                <th style="padding:10px; text-align:left; border-bottom:2px solid #dee2e6;">Data</th>
                                <th style="padding:10px; text-align:center; border-bottom:2px solid #dee2e6;">Qtd</th>
                                <th style="padding:10px; text-align:left; border-bottom:2px solid #dee2e6;">Preço Custo</th>
                                <th style="padding:10px; text-align:left; border-bottom:2px solid #dee2e6;">Fornecedor</th>
                                <th style="padding:10px; text-align:left; border-bottom:2px solid #dee2e6;">Observação</th>
                            </tr>
                        </thead>
                        <tbody id="tbodyHistoricoCompras">
                            <tr><td colspan="5" style="text-align:center;color:#aaa;padding:20px;">Carregando...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
