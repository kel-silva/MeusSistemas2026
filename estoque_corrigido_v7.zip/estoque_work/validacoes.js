// Sistema de Validação em Tempo Real para Formulários

// Função para validar email
function validarEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

// Função para validar telefone (10 ou 11 dígitos)
function validarTelefone(telefone) {
    const digitos = telefone.replace(/\D/g, '');
    return digitos.length === 10 || digitos.length === 11;
}

// Função para validar CEP
function validarCEP(cep) {
    const digitos = cep.replace(/\D/g, '');
    return digitos.length === 8;
}

// Função para mostrar erro no campo
function mostrarErro(inputId, mensagem) {
    const input = document.getElementById(inputId);
    if (!input) return;

    // Remover mensagem de erro anterior
    const erroAnterior = input.parentElement.querySelector('.campo-erro');
    if (erroAnterior) {
        erroAnterior.remove();
    }

    // Adicionar classe de erro
    input.classList.add('input-erro');

    // Criar mensagem de erro
    const divErro = document.createElement('div');
    divErro.className = 'campo-erro';
    divErro.textContent = mensagem;
    divErro.style.color = '#e74c3c';
    divErro.style.fontSize = '12px';
    divErro.style.marginTop = '4px';
    divErro.style.fontWeight = '500';

    // Inserir mensagem após o input
    input.parentElement.appendChild(divErro);
}

// Função para limpar erro do campo
function limparErro(inputId) {
    const input = document.getElementById(inputId);
    if (!input) return;

    input.classList.remove('input-erro');
    const erroAnterior = input.parentElement.querySelector('.campo-erro');
    if (erroAnterior) {
        erroAnterior.remove();
    }
}

// Função para validar CPF/CNPJ ao sair do campo
function validarCpfCnpjOnBlur(inputId) {
    const input = document.getElementById(inputId);
    if (!input) return true;

    const valor = input.value.replace(/\D/g, '');

    // Se campo estiver vazio, apenas limpar erro
    if (valor === '') {
        limparErro(inputId);
        return true;
    }

    let valido = false;
    let mensagemErro = '';

    if (valor.length === 11) {
        // Validar CPF
        valido = validarCPF(input.value);
        mensagemErro = 'CPF inválido! Verifique os dados digitados.';
    } else if (valor.length === 14) {
        // Validar CNPJ
        valido = validarCNPJ(input.value);
        mensagemErro = 'CNPJ inválido! Verifique os dados digitados.';
    } else {
        mensagemErro = 'CPF deve ter 11 dígitos ou CNPJ 14 dígitos.';
    }

    if (!valido && valor.length > 0) {
        mostrarErro(inputId, mensagemErro);
        return false;
    } else {
        limparErro(inputId);
        return true;
    }
}

// Função para validar CNPJ ao sair do campo
function validarCnpjOnBlur(inputId) {
    const input = document.getElementById(inputId);
    if (!input) return true;

    const valor = input.value.replace(/\D/g, '');

    // Se campo estiver vazio, apenas limpar erro
    if (valor === '') {
        limparErro(inputId);
        return true;
    }

    if (valor.length !== 14) {
        mostrarErro(inputId, 'CNPJ deve ter 14 dígitos.');
        return false;
    }

    if (!validarCNPJ(input.value)) {
        mostrarErro(inputId, 'CNPJ inválido! Verifique os dados digitados.');
        return false;
    }

    limparErro(inputId);
    return true;
}

// Função para validar email ao sair do campo
function validarEmailOnBlur(inputId) {
    const input = document.getElementById(inputId);
    if (!input) return true;

    const valor = input.value.trim();

    // Se campo estiver vazio, apenas limpar erro
    if (valor === '') {
        limparErro(inputId);
        return true;
    }

    if (!validarEmail(valor)) {
        mostrarErro(inputId, 'Email inválido! Use o formato: exemplo@email.com');
        return false;
    }

    limparErro(inputId);
    return true;
}

// Função para validar telefone ao sair do campo
function validarTelefoneOnBlur(inputId) {
    const input = document.getElementById(inputId);
    if (!input) return true;

    const valor = input.value.replace(/\D/g, '');

    // Se campo estiver vazio, apenas limpar erro
    if (valor === '') {
        limparErro(inputId);
        return true;
    }

    if (!validarTelefone(input.value)) {
        mostrarErro(inputId, 'Telefone inválido! Use 10 ou 11 dígitos.');
        return false;
    }

    limparErro(inputId);
    return true;
}

// Função para validar CEP ao sair do campo
function validarCepOnBlur(inputId) {
    const input = document.getElementById(inputId);
    if (!input) return true;

    const valor = input.value.replace(/\D/g, '');

    // Se campo estiver vazio, apenas limpar erro
    if (valor === '') {
        limparErro(inputId);
        return true;
    }

    if (!validarCEP(input.value)) {
        mostrarErro(inputId, 'CEP inválido! Deve ter 8 dígitos.');
        return false;
    }

    limparErro(inputId);
    return true;
}

// Função para inicializar todas as validações
function inicializarValidacoes() {
    // Validação de CPF/CNPJ
    const cpfCnpjInputs = document.querySelectorAll('input[data-mask="cpf-cnpj"]');
    cpfCnpjInputs.forEach(input => {
        input.addEventListener('blur', function() {
            validarCpfCnpjOnBlur(input.id);
        });
    });

    // Validação de CNPJ
    const cnpjInputs = document.querySelectorAll('input[data-mask="cnpj"]');
    cnpjInputs.forEach(input => {
        input.addEventListener('blur', function() {
            validarCnpjOnBlur(input.id);
        });
    });

    // Validação de Email
    const emailInputs = document.querySelectorAll('input[type="email"]');
    emailInputs.forEach(input => {
        input.addEventListener('blur', function() {
            validarEmailOnBlur(input.id);
        });
    });

    // Validação de Telefone
    const telefoneInputs = document.querySelectorAll('input[data-mask="telefone"]');
    telefoneInputs.forEach(input => {
        input.addEventListener('blur', function() {
            validarTelefoneOnBlur(input.id);
        });
    });

    // Validação de CEP
    const cepInputs = document.querySelectorAll('input[data-mask="cep"]');
    cepInputs.forEach(input => {
        input.addEventListener('blur', function() {
            validarCepOnBlur(input.id);
        });
    });
}

// Exportar funções para uso global
window.validarEmail = validarEmail;
window.validarTelefone = validarTelefone;
window.validarCEP = validarCEP;
window.validarCpfCnpjOnBlur = validarCpfCnpjOnBlur;
window.validarCnpjOnBlur = validarCnpjOnBlur;
window.validarEmailOnBlur = validarEmailOnBlur;
window.validarTelefoneOnBlur = validarTelefoneOnBlur;
window.validarCepOnBlur = validarCepOnBlur;
window.mostrarErro = mostrarErro;
window.limparErro = limparErro;
window.inicializarValidacoes = inicializarValidacoes;
