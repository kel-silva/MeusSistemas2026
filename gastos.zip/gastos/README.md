# 💰 FinControl Pro - Sistema de Controle Financeiro

## 🚀 SISTEMA COMPLETAMENTE FUNCIONAL EM PORTUGUÊS

Um sistema completo de controle financeiro pessoal com banco de dados SQLite, suporte PWA e interface moderna.

## ✨ Novidades da Versão 2.0

### 🎯 Melhorias Implementadas:

✅ **Banco de Dados SQLite com PDO**
- Cada usuário tem seus dados isolados
- Conexão segura via PDO
- Suporte multi-usuário com cookies

✅ **Formatação Automática de Valores**
- Formatação automática de milhares (1.000, 10.000, etc)
- Casas decimais formatadas corretamente
- Suporte para múltiplos idiomas (PT, EN, DE)

✅ **Filtros Avançados no Extrato**
- Filtrar por mês específico
- Filtrar por categoria dentro do mês
- Resumo financeiro dos filtros aplicados
- Exemplo: "Quanto gastei em Gasolina em Março?"

✅ **Sistema de Backup e Importação**
- Exportar TODOS os dados em JSON
- Importar dados salvos
- Backup automático sugerido nos dias 25-27 de cada mês
- Proteção contra perda de dados

✅ **Dashboard com Gráficos Interativos**
- Gráfico de pizza mostrando despesas por categoria
- Gráfico de barras comparando receitas vs despesas
- Top 5 categorias com mais gastos
- Visualização clara e intuitiva

✅ **PWA - Funciona Offline**
- Instalável no celular como app nativo
- Service Worker para cache
- Funciona sem internet após instalação

## 📋 Instalação

### Requisitos:
- PHP 7.4 ou superior
- Apache/Nginx com mod_rewrite
- Extensão PDO SQLite habilitada

### Passos:

1. **Extrair arquivos**
   ```bash
   unzip fincontrol-pro.zip
   ```

2. **Copiar para o servidor web**
   - Laragon: `C:\laragon\www\fincontrol`
   - XAMPP: `C:\xampp\htdocs\fincontrol`
   - Linux: `/var/www/html/fincontrol`

3. **Dar permissões (Linux)**
   ```bash
   chmod 755 -R fincontrol/
   chmod 777 fincontrol/data/
   ```

4. **Acessar no navegador**
   ```
   http://localhost/fincontrol
   ```

## 🎨 Funcionalidades

### Gerenciamento Financeiro
- ✅ Adicionar receitas e despesas
- ✅ Categorias pré-definidas e personalizadas
- ✅ Contas (Crédito, Débito, Dinheiro)
- ✅ Calculadora integrada com formatação

### Relatórios e Análises
- ✅ Extrato mensal completo
- ✅ Filtros por mês e categoria
- ✅ Dashboard com gráficos interativos
- ✅ Resumo de receitas e despesas

### Backup e Segurança
- ✅ Exportar todos os dados (JSON)
- ✅ Importar dados salvos
- ✅ Lembrete automático de backup
- ✅ Dados isolados por usuário

### Interface
- ✅ Design moderno e responsivo
- ✅ Tema claro e escuro
- ✅ Suporte a 3 idiomas (PT, EN, DE)
- ✅ PWA - instalável como app

## 🔧 Estrutura de Arquivos

```
fincontrol-pro/
├── index.php           # Página principal
├── config.php          # Configuração do banco SQLite
├── api.php             # API REST para operações
├── app.js              # JavaScript principal
├── manifest.json       # Configuração PWA
├── sw.js               # Service Worker
├── .htaccess           # Configurações Apache
├── data/               # Banco de dados (criado automaticamente)
│   └── fincontrol.db
└── README.md           # Este arquivo
```

## 📊 Banco de Dados

### Tabelas:
- **users** - Dados dos usuários
- **transactions** - Todas as transações
- **custom_categories** - Categorias personalizadas
- **user_settings** - Configurações (tema, idioma, etc)

## 🌐 Compatibilidade

### Navegadores:
- ✅ Chrome/Edge (recomendado)
- ✅ Firefox
- ✅ Safari
- ✅ Opera

### Dispositivos:
- ✅ Desktop
- ✅ Tablet
- ✅ Smartphone (iOS e Android)

## 💡 Como Usar

### 1. Adicionar Transação
- Clique no botão "+"
- Escolha Receita ou Despesa
- Digite o valor usando o teclado numérico
- Preencha descrição, categoria, data e conta
- Salve

### 2. Ver Extrato Completo
- Clique em "Extrato"
- Use os filtros de mês e categoria
- Veja o resumo financeiro filtrado

### 3. Dashboard Analytics
- No extrato, clique no ícone de gráfico (topo direito)
- Veja gráficos interativos
- Analise suas despesas por categoria

### 4. Fazer Backup
- Clique em "Exportar" no dashboard
- Arquivo JSON será baixado
- Guarde em local seguro

### 5. Importar Backup
- Clique em "Importar" no dashboard
- Selecione o arquivo JSON salvo
- Confirme a importação

## 🎯 Dicas de Uso

1. **Faça backup regular** - Especialmente antes de formatar o PC
2. **Use categorias personalizadas** - Crie categorias específicas para seu controle
3. **Aproveite os filtros** - Analise gastos por categoria e mês
4. **Instale como PWA** - Use como app no celular
5. **Ative o tema escuro** - Economiza bateria em telas OLED

## 🔒 Segurança

- ✅ Dados isolados por usuário (cookie)
- ✅ Banco SQLite protegido via .htaccess
- ✅ Sem armazenamento de senhas
- ✅ Todos os dados salvos localmente

## 📱 Instalar como PWA

### Android (Chrome):
1. Abra o site no Chrome
2. Menu → "Adicionar à tela inicial"
3. Use como app nativo

### iOS (Safari):
1. Abra o site no Safari
2. Toque em "Compartilhar"
3. "Adicionar à Tela de Início"

## 🆘 Suporte

Em caso de problemas:

1. Verifique se a extensão PDO SQLite está habilitada
2. Verifique permissões da pasta `data/`
3. Limpe o cache do navegador
4. Verifique logs de erro do PHP

## 📜 Licença

Sistema gratuito para uso pessoal.

## ❤️ Desenvolvedor

Se este sistema te ajudou, considere fazer uma doação via PIX:
**f6c00e65-b267-45d0-a6da-9ac9ca57a131**

---

**FinControl Pro v2.0** - Controle financeiro simples e eficiente! 💰
