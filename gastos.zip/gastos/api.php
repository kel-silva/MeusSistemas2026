<?php
require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

// Obter user_id do cookie ou criar novo
function getUserId() {
    if (!isset($_COOKIE['fincontrol_user_id'])) {
        $userId = 'user_' . uniqid() . '_' . time();
        setcookie('fincontrol_user_id', $userId, time() + (365 * 24 * 60 * 60), '/');
        return $userId;
    }
    return $_COOKIE['fincontrol_user_id'];
}

$userId = getUserId();
$db = getDB();

// Obter action do GET, POST ou JSON body
$action = $_GET['action'] ?? $_POST['action'] ?? '';
if (empty($action)) {
    $inputData = json_decode(file_get_contents('php://input'), true);
    $action = $inputData['action'] ?? '';
}

try {
    switch ($action) {
        // ===== TRANSAÇÕES =====
        case 'get_transactions':
            $month = $_GET['month'] ?? date('Y-m');
            $stmt = $db->prepare("SELECT * FROM transactions WHERE user_id = ? AND month = ? ORDER BY date DESC");
            $stmt->execute([$userId, $month]);
            echo json_encode($stmt->fetchAll());
            break;

        case 'get_all_transactions':
            $stmt = $db->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY date DESC");
            $stmt->execute([$userId]);
            echo json_encode($stmt->fetchAll());
            break;

        case 'add_transaction':
            $data = json_decode(file_get_contents('php://input'), true);
            $stmt = $db->prepare("INSERT INTO transactions (user_id, amount, description, date, category, type, account, month) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $userId,
                $data['amount'],
                $data['description'],
                $data['date'],
                $data['category'],
                $data['type'],
                $data['account'],
                substr($data['date'], 0, 7)
            ]);
            echo json_encode(['success' => true, 'id' => $db->lastInsertId()]);
            break;

        case 'delete_transaction':
            $data = json_decode(file_get_contents('php://input'), true);
            $id = $data['id'] ?? $_POST['id'] ?? 0;
            $stmt = $db->prepare("DELETE FROM transactions WHERE id = ? AND user_id = ?");
            $stmt->execute([$id, $userId]);
            echo json_encode(['success' => true]);
            break;

        // ===== CATEGORIAS PERSONALIZADAS =====
        case 'get_custom_categories':
            $stmt = $db->prepare("SELECT * FROM custom_categories WHERE user_id = ?");
            $stmt->execute([$userId]);
            echo json_encode($stmt->fetchAll());
            break;

        case 'add_custom_category':
            $data = json_decode(file_get_contents('php://input'), true);

            // Verificar se a categoria já existe
            $checkStmt = $db->prepare("SELECT id FROM custom_categories WHERE user_id = ? AND category_id = ?");
            $checkStmt->execute([$userId, $data['category_id']]);
            $existing = $checkStmt->fetch();

            if ($existing) {
                echo json_encode(['success' => true, 'id' => $existing['id'], 'message' => 'Categoria já existe']);
                break;
            }

            $stmt = $db->prepare("INSERT INTO custom_categories (user_id, category_id, name_pt, name_en, name_de, icon, color, type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $userId,
                $data['category_id'],
                $data['name_pt'],
                $data['name_en'],
                $data['name_de'],
                $data['icon'],
                $data['color'],
                $data['type']
            ]);
            $insertedId = $db->lastInsertId();

            // Retornar a categoria completa
            $getStmt = $db->prepare("SELECT * FROM custom_categories WHERE id = ?");
            $getStmt->execute([$insertedId]);
            $newCategory = $getStmt->fetch();

            echo json_encode(['success' => true, 'id' => $insertedId, 'category' => $newCategory]);
            break;

        case 'delete_custom_category':
            $data = json_decode(file_get_contents('php://input'), true);
            $id = $data['id'] ?? $_POST['id'] ?? $_GET['id'] ?? 0;

            if (!$id) {
                echo json_encode(['error' => 'ID da categoria não fornecido']);
                break;
            }

            $stmt = $db->prepare("DELETE FROM custom_categories WHERE id = ? AND user_id = ?");
            $stmt->execute([$id, $userId]);

            if ($stmt->rowCount() > 0) {
                echo json_encode(['success' => true, 'message' => 'Categoria removida']);
            } else {
                echo json_encode(['error' => 'Categoria não encontrada ou já foi removida']);
            }
            break;

        // ===== CONFIGURAÇÕES DO USUÁRIO =====
        case 'get_user_settings':
            $stmt = $db->prepare("SELECT * FROM user_settings WHERE user_id = ?");
            $stmt->execute([$userId]);
            $settings = $stmt->fetch();
            if (!$settings) {
                $stmt = $db->prepare("INSERT INTO user_settings (user_id) VALUES (?)");
                $stmt->execute([$userId]);
                $settings = ['user_id' => $userId, 'theme' => 'light', 'language' => 'pt', 'is_supporter' => 0];
            }
            echo json_encode($settings);
            break;

        case 'update_user_settings':
            $data = json_decode(file_get_contents('php://input'), true);
            $stmt = $db->prepare("UPDATE user_settings SET theme = ?, language = ?, backup_reminder_date = ?, is_supporter = ? WHERE user_id = ?");
            $stmt->execute([
                $data['theme'] ?? 'light',
                $data['language'] ?? 'pt',
                $data['backup_reminder_date'] ?? null,
                $data['is_supporter'] ?? 0,
                $userId
            ]);
            echo json_encode(['success' => true]);
            break;

        case 'get_user':
            $stmt = $db->prepare("SELECT * FROM users WHERE user_id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            if (!$user) {
                $stmt = $db->prepare("INSERT INTO users (user_id, name) VALUES (?, ?)");
                $stmt->execute([$userId, 'Usuário']);
                $user = ['user_id' => $userId, 'name' => 'Usuário'];
            }
            echo json_encode($user);
            break;

        case 'update_user_name':
            $data = json_decode(file_get_contents('php://input'), true);
            $stmt = $db->prepare("UPDATE users SET name = ? WHERE user_id = ?");
            $stmt->execute([$data['name'], $userId]);
            echo json_encode(['success' => true]);
            break;

        // ===== BACKUP E IMPORTAÇÃO =====
        case 'export_all_data':
            $transactions = $db->prepare("SELECT * FROM transactions WHERE user_id = ?");
            $transactions->execute([$userId]);

            $categories = $db->prepare("SELECT * FROM custom_categories WHERE user_id = ?");
            $categories->execute([$userId]);

            $user = $db->prepare("SELECT * FROM users WHERE user_id = ?");
            $user->execute([$userId]);

            $settings = $db->prepare("SELECT * FROM user_settings WHERE user_id = ?");
            $settings->execute([$userId]);

            $exportData = [
                'version' => '2.0',
                'export_date' => date('Y-m-d H:i:s'),
                'user' => $user->fetch(),
                'transactions' => $transactions->fetchAll(),
                'custom_categories' => $categories->fetchAll(),
                'settings' => $settings->fetch()
            ];

            echo json_encode($exportData);
            break;

        case 'import_all_data':
            $data = json_decode(file_get_contents('php://input'), true);

            // Começar transação
            $db->beginTransaction();

            try {
                // Limpar dados existentes
                $db->prepare("DELETE FROM transactions WHERE user_id = ?")->execute([$userId]);
                $db->prepare("DELETE FROM custom_categories WHERE user_id = ?")->execute([$userId]);

                // Importar transações
                if (isset($data['transactions'])) {
                    $stmt = $db->prepare("INSERT INTO transactions (user_id, amount, description, date, category, type, account, month) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                    foreach ($data['transactions'] as $t) {
                        $stmt->execute([
                            $userId,
                            $t['amount'],
                            $t['description'],
                            $t['date'],
                            $t['category'],
                            $t['type'],
                            $t['account'],
                            $t['month']
                        ]);
                    }
                }

                // Importar categorias personalizadas
                if (isset($data['custom_categories'])) {
                    $stmt = $db->prepare("INSERT INTO custom_categories (user_id, category_id, name_pt, name_en, name_de, icon, color, type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                    foreach ($data['custom_categories'] as $c) {
                        $stmt->execute([
                            $userId,
                            $c['category_id'],
                            $c['name_pt'],
                            $c['name_en'],
                            $c['name_de'],
                            $c['icon'],
                            $c['color'],
                            $c['type']
                        ]);
                    }
                }

                // Atualizar nome do usuário
                if (isset($data['user']['name'])) {
                    $db->prepare("UPDATE users SET name = ? WHERE user_id = ?")->execute([$data['user']['name'], $userId]);
                }

                $db->commit();
                echo json_encode(['success' => true]);
            } catch (Exception $e) {
                $db->rollBack();
                throw $e;
            }
            break;

        case 'clear_all_data':
            $db->prepare("DELETE FROM transactions WHERE user_id = ?")->execute([$userId]);
            $db->prepare("DELETE FROM custom_categories WHERE user_id = ?")->execute([$userId]);
            echo json_encode(['success' => true]);
            break;

        default:
            echo json_encode(['error' => 'Ação inválida']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
