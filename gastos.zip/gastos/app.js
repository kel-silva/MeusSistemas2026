// ==================== CONFIGURAÇÃO GLOBAL ====================
let currentLang = 'pt';
let currentMonth = '';
let currentType = 'expense';
let selectedCategory = null;
let currentAmountValue = 0;
let isDarkTheme = false;
let transactions = [];
let customCategories = [];
let expenseChart = null;
let categoryPieChart = null;
let incomeExpenseChart = null;

// ==================== TRADUÇÕES ====================
const translations = {
    pt: {
        welcome_back: "Bem-vindo de volta,",
        total_balance: "Saldo do Mês",
        income: "Receitas",
        expenses: "Despesas",
        add: "Adicionar",
        statement: "Extrato",
        export: "Exportar",
        import: "Importar",
        month_summary: "Resumo do Mês",
        recent_transactions: "Transações do Mês",
        see_all: "Ver todas",
        transactions: "Transações",
        all: "Todas",
        income_only: "Receitas",
        expenses_only: "Despesas",
        new_transaction: "Nova Transação",
        expense: "Despesa",
        income_single: "Receita",
        amount: "Valor",
        description: "Descrição",
        ex_supermarket: "Ex: Supermercado",
        category: "Categoria",
        date: "Data",
        account: "Conta",
        credit_card: "Cartão Crédito",
        debit_card: "Cartão Débito",
        cash: "Dinheiro",
        save_transaction: "Salvar Transação",
        home: "Início",
        profile: "Perfil",
        donate: "Doar",
        currency: "R$",
        months: ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"],
        add_custom_category: "Adicionar Categoria",
        add_category: "+ Categoria",
        category_name: "Nome da Categoria",
        choose_icon: "Escolha um Ícone",
        choose_color: "Escolha uma Cor",
        preview: "Pré-visualização",
        add_category_btn: "Adicionar Categoria",
        no_transactions: "Nenhuma transação neste mês"
    },
    en: {
        welcome_back: "Welcome back,",
        total_balance: "Month Balance",
        income: "Income",
        expenses: "Expenses",
        add: "Add",
        statement: "Statement",
        export: "Export",
        import: "Import",
        month_summary: "Monthly Summary",
        recent_transactions: "Month Transactions",
        see_all: "See all",
        transactions: "Transactions",
        all: "All",
        income_only: "Income",
        expenses_only: "Expenses",
        new_transaction: "New Transaction",
        expense: "Expense",
        income_single: "Income",
        amount: "Amount",
        description: "Description",
        ex_supermarket: "Ex: Supermarket",
        category: "Category",
        date: "Date",
        account: "Account",
        credit_card: "Credit Card",
        debit_card: "Debit Card",
        cash: "Cash",
        save_transaction: "Save Transaction",
        home: "Home",
        profile: "Profile",
        donate: "Donate",
        currency: "$",
        months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
        add_custom_category: "Add Category",
        add_category: "+ Category",
        category_name: "Category Name",
        choose_icon: "Choose an Icon",
        choose_color: "Choose a Color",
        preview: "Preview",
        add_category_btn: "Add Category",
        no_transactions: "No transactions this month"
    },
    de: {
        welcome_back: "Willkommen zurück,",
        total_balance: "Monat Bilanz",
        income: "Einnahmen",
        expenses: "Ausgaben",
        add: "Hinzufügen",
        statement: "Auszug",
        export: "Exportieren",
        import: "Importieren",
        month_summary: "Monatsübersicht",
        recent_transactions: "Monat Transaktionen",
        see_all: "Alle anzeigen",
        transactions: "Transaktionen",
        all: "Alle",
        income_only: "Einnahmen",
        expenses_only: "Ausgaben",
        new_transaction: "Neue Transaktion",
        expense: "Ausgabe",
        income_single: "Einnahme",
        amount: "Betrag",
        description: "Beschreibung",
        ex_supermarket: "Bsp: Supermarkt",
        category: "Kategorie",
        date: "Datum",
        account: "Konto",
        credit_card: "Kreditkarte",
        debit_card: "Debitkarte",
        cash: "Bargeld",
        save_transaction: "Transaktion speichern",
        home: "Startseite",
        profile: "Profil",
        donate: "Spenden",
        currency: "€",
        months: ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"],
        add_custom_category: "Kategorie Hinzufügen",
        add_category: "+ Kategorie",
        category_name: "Kategoriename",
        choose_icon: "Symbol Wählen",
        choose_color: "Farbe Wählen",
        preview: "Vorschau",
        add_category_btn: "Kategorie Hinzufügen",
        no_transactions: "Keine Transaktionen diesen Monat"
    }
};

// ==================== CATEGORIAS PADRÃO ====================
const categories = {
    expense: [
        { id: 'food', name: { pt: 'Alimentação', en: 'Food', de: 'Essen' }, icon: 'fa-utensils', color: 'bg-orange-100 text-orange-600' },
        { id: 'transport', name: { pt: 'Transporte', en: 'Transport', de: 'Transport' }, icon: 'fa-bus', color: 'bg-blue-100 text-blue-600' },
        { id: 'housing', name: { pt: 'Moradia', en: 'Housing', de: 'Wohnen' }, icon: 'fa-home', color: 'bg-indigo-100 text-indigo-600' },
        { id: 'health', name: { pt: 'Saúde', en: 'Health', de: 'Gesundheit' }, icon: 'fa-heartbeat', color: 'bg-red-100 text-red-600' },
        { id: 'leisure', name: { pt: 'Lazer', en: 'Leisure', de: 'Freizeit' }, icon: 'fa-gamepad', color: 'bg-purple-100 text-purple-600' },
        { id: 'shopping', name: { pt: 'Compras', en: 'Shopping', de: 'Einkaufen' }, icon: 'fa-shopping-bag', color: 'bg-pink-100 text-pink-600' },
        { id: 'education', name: { pt: 'Educação', en: 'Education', de: 'Bildung' }, icon: 'fa-graduation-cap', color: 'bg-cyan-100 text-cyan-600' },
        { id: 'bills', name: { pt: 'Contas', en: 'Bills', de: 'Rechnungen' }, icon: 'fa-file-invoice-dollar', color: 'bg-yellow-100 text-yellow-600' }
    ],
    income: [
        { id: 'salary', name: { pt: 'Salário', en: 'Salary', de: 'Gehalt' }, icon: 'fa-money-bill-wave', color: 'bg-green-100 text-green-600' },
        { id: 'freelance', name: { pt: 'Freelance', en: 'Freelance', de: 'Freelance' }, icon: 'fa-laptop-code', color: 'bg-emerald-100 text-emerald-600' },
        { id: 'investments', name: { pt: 'Investimentos', en: 'Investments', de: 'Investitionen' }, icon: 'fa-chart-line', color: 'bg-teal-100 text-teal-600' },
        { id: 'gift', name: { pt: 'Presente', en: 'Gift', de: 'Geschenk' }, icon: 'fa-gift', color: 'bg-rose-100 text-rose-600' },
        { id: 'other_income', name: { pt: 'Outros', en: 'Others', de: 'Sonstiges' }, icon: 'fa-plus-circle', color: 'bg-gray-100 text-gray-600' }
    ]
};

// ==================== ÍCONES E CORES DISPONÍVEIS ====================
const availableIcons = [
    'fa-dumbbell', 'fa-gamepad', 'fa-book', 'fa-graduation-cap', 'fa-baby', 'fa-paw',
    'fa-car', 'fa-bicycle', 'fa-plane', 'fa-hotel', 'fa-coffee', 'fa-beer',
    'fa-cut', 'fa-spa', 'fa-tshirt', 'fa-mobile-alt', 'fa-laptop', 'fa-wifi',
    'fa-bolt', 'fa-tint', 'fa-gift', 'fa-heart', 'fa-music', 'fa-camera',
    'fa-futbol', 'fa-shopping-cart', 'fa-tools', 'fa-paint-brush'
];

const availableColors = [
    { bg: 'bg-red-500', text: 'text-red-600', light: 'bg-red-100' },
    { bg: 'bg-orange-500', text: 'text-orange-600', light: 'bg-orange-100' },
    { bg: 'bg-yellow-500', text: 'text-yellow-600', light: 'bg-yellow-100' },
    { bg: 'bg-green-500', text: 'text-green-600', light: 'bg-green-100' },
    { bg: 'bg-emerald-500', text: 'text-emerald-600', light: 'bg-emerald-100' },
    { bg: 'bg-cyan-500', text: 'text-cyan-600', light: 'bg-cyan-100' },
    { bg: 'bg-blue-500', text: 'text-blue-600', light: 'bg-blue-100' },
    { bg: 'bg-indigo-500', text: 'text-indigo-600', light: 'bg-indigo-100' },
    { bg: 'bg-purple-500', text: 'text-purple-600', light: 'bg-purple-100' },
    { bg: 'bg-pink-500', text: 'text-pink-600', light: 'bg-pink-100' },
    { bg: 'bg-rose-500', text: 'text-rose-600', light: 'bg-rose-100' },
    { bg: 'bg-slate-500', text: 'text-slate-600', light: 'bg-slate-100' }
];

let selectedIcon = '';
let selectedColor = null;

// ==================== SISTEMA DE FORMATAÇÃO DE VALOR ====================
function addDigit(digit) {
    currentAmountValue = currentAmountValue * 10 + parseInt(digit);
    updateAmountDisplay();
}

function removeDigit() {
    currentAmountValue = Math.floor(currentAmountValue / 10);
    updateAmountDisplay();
}

function clearAmount() {
    currentAmountValue = 0;
    updateAmountDisplay();
}

function updateAmountDisplay() {
    const valueInReais = currentAmountValue / 100;
    let formatted;

    if (currentLang === 'pt') {
        formatted = valueInReais.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    } else if (currentLang === 'en') {
        formatted = valueInReais.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    } else {
        formatted = valueInReais.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    document.getElementById('amount-display').value = formatted;
    document.getElementById('amount-input').value = valueInReais.toFixed(2);
}

function getAmountValue() {
    return parseFloat(document.getElementById('amount-input').value);
}

function focusAmountInput() {
    // Visual apenas
}

// ==================== SISTEMA DE TEMA ====================
function toggleTheme() {
    isDarkTheme = !isDarkTheme;
    applyTheme();
    saveUserSettings();
}

function applyTheme() {
    const body = document.body;
    const themeIcon = document.getElementById('theme-icon');
    const themeBtn = document.getElementById('theme-btn');

    if (isDarkTheme) {
        body.classList.add('dark-theme');
        themeIcon.className = 'fas fa-moon';
        themeBtn.className = 'theme-toggle w-8 h-8 rounded-full bg-gray-700 hover:bg-gray-600 flex items-center justify-center text-blue-400';
    } else {
        body.classList.remove('dark-theme');
        themeIcon.className = 'fas fa-sun';
        themeBtn.className = 'theme-toggle w-8 h-8 rounded-full bg-gray-700 hover:bg-gray-600 flex items-center justify-center text-yellow-400';
    }
}

// ==================== SISTEMA DE IDIOMAS ====================
function changeLanguage(lang) {
    currentLang = lang;

    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.lang === lang) btn.classList.add('active');
    });

    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (translations[lang][key]) el.textContent = translations[lang][key];
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
        const key = el.dataset.i18nPlaceholder;
        if (translations[lang][key]) el.placeholder = translations[lang][key];
    });

    document.getElementById('currency-symbol').textContent = translations[lang].currency;

    updateMonthSelects();
    updateMonthDisplay();
    renderCategories();
    updateUI();
    updateAmountDisplay();
    saveUserSettings();
}

// ==================== SISTEMA DE MÊS ====================
function initMonthFilter() {
    const now = new Date();
    currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    updateMonthSelects();
    updateMonthDisplay();
}

function changeMonth(value) {
    currentMonth = value;
    updateMonthDisplay();
    updateUI();
}

function updateMonthSelects() {
    const selects = ['month-select-dashboard', 'month-filter', 'dashboard-month-filter'];
    const months = translations[currentLang].months;
    const now = new Date();

    selects.forEach(selectId => {
        const select = document.getElementById(selectId);
        if (!select) return;

        const currentValue = select.value || currentMonth;
        select.innerHTML = '';

        for (let i = 0; i < 12; i++) {
            const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
            const value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
            const label = `${months[d.getMonth()]} ${d.getFullYear()}`;

            const option = document.createElement('option');
            option.value = value;
            option.textContent = label;
            if (value === currentValue) option.selected = true;

            select.appendChild(option);
        }
    });

    updateCategoryFilter();
}

function updateMonthDisplay() {
    const [year, month] = currentMonth.split('-');
    const monthIndex = parseInt(month) - 1;
    const monthName = translations[currentLang].months[monthIndex];
    const display = `${monthName} ${year}`;

    document.getElementById('current-month-display').textContent = display;
    document.getElementById('transactions-month-label').textContent = display;
}

// ==================== API CALLS ====================
async function apiRequest(action, data = null, method = 'GET') {
    try {
        const url = method === 'GET' ? `api.php?action=${action}` : 'api.php';

        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            }
        };

        if (method === 'POST' && data) {
            options.body = JSON.stringify({ action, ...data });
        }

        const response = await fetch(url, options);
        const result = await response.json();

        if (result.error) {
            console.error('API Error:', result.error);
            throw new Error(result.error);
        }

        return result;
    } catch (error) {
        console.error('Request failed:', error);
        throw error;
    }
}

async function loadTransactions() {
    try {
        const data = await apiRequest('get_all_transactions');
        transactions = Array.isArray(data) ? data : [];
        updateUI();
    } catch (error) {
        console.error('Erro ao carregar transações:', error);
        transactions = [];
    }
}

async function loadCustomCategories() {
    try {
        const data = await apiRequest('get_custom_categories');
        customCategories = Array.isArray(data) ? data : [];

        console.log('📦 Categorias customizadas carregadas do banco:', customCategories);

        // Limpar categorias customizadas antigas
        categories.expense = categories.expense.filter(c => !c.custom);
        categories.income = categories.income.filter(c => !c.custom);

        // Adicionar novas categorias customizadas
        customCategories.forEach(cat => {
            console.log('🔄 Processando categoria:', cat);

            const newCat = {
                id: cat.category_id,
                name: { pt: cat.name_pt, en: cat.name_en, de: cat.name_de },
                icon: cat.icon,
                color: cat.color,
                custom: true,
                dbId: cat.id
            };

            console.log('✨ Categoria formatada:', newCat);

            if (cat.type === 'expense' && !categories.expense.find(c => c.id === cat.category_id)) {
                categories.expense.push(newCat);
                console.log('➕ Adicionada a despesas');
            } else if (cat.type === 'income' && !categories.income.find(c => c.id === cat.category_id)) {
                categories.income.push(newCat);
                console.log('➕ Adicionada a receitas');
            }
        });

        console.log('📊 Categorias expense finais:', categories.expense);
        console.log('📊 Categorias income finais:', categories.income);

        renderCategories();
    } catch (error) {
        console.error('Erro ao carregar categorias:', error);
    }
}

async function loadUserData() {
    const user = await apiRequest('get_user');
    if (user && user.name) {
        document.getElementById('user-name').textContent = user.name;
        const initials = user.name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
        document.getElementById('user-avatar').textContent = initials;
    }
}

async function loadUserSettings() {
    const settings = await apiRequest('get_user_settings');
    if (settings) {
        isDarkTheme = settings.theme === 'dark';
        applyTheme();

        if (settings.language) {
            changeLanguage(settings.language);
        }
    }
}

async function saveUserSettings() {
    await apiRequest('update_user_settings', {
        theme: isDarkTheme ? 'dark' : 'light',
        language: currentLang
    }, 'POST');
}

// ==================== TRANSAÇÕES ====================
function getMonthTransactions() {
    return transactions.filter(t => t.month === currentMonth);
}

function calculateTotals() {
    const monthTransactions = getMonthTransactions();
    let income = 0;
    let expense = 0;

    monthTransactions.forEach(t => {
        if (t.type === 'income') income += parseFloat(t.amount);
        else expense += parseFloat(t.amount);
    });

    return { income, expense, balance: income - expense };
}

function updateUI() {
    const totals = calculateTotals();
    const currency = translations[currentLang].currency;

    const balanceEl = document.getElementById('total-balance');
    const incomeEl = document.getElementById('total-income');
    const expenseEl = document.getElementById('total-expense');

    balanceEl.textContent = `${currency} ${formatCurrency(totals.balance)}`;
    incomeEl.textContent = `${currency} ${formatCurrency(totals.income)}`;
    expenseEl.textContent = `${currency} ${formatCurrency(totals.expense)}`;

    // Ajustar tamanho de fonte baseado no comprimento do texto
    adjustFontSize(balanceEl, 'text-2xl sm:text-3xl', 'text-xl sm:text-2xl', 'text-lg sm:text-xl');
    adjustFontSize(incomeEl, 'text-sm sm:text-base', 'text-xs sm:text-sm', 'text-xs');
    adjustFontSize(expenseEl, 'text-sm sm:text-base', 'text-xs sm:text-sm', 'text-xs');

    updateExpenseChart(totals.income, totals.expense);
    renderRecentTransactions();
    renderAllTransactions();
    renderCategories();
}

function adjustFontSize(element, defaultSize, mediumSize, smallSize) {
    if (!element) return;

    const textLength = element.textContent.length;

    // Remover todas as classes de tamanho
    element.classList.remove('text-xs', 'text-sm', 'text-base', 'text-lg', 'text-xl', 'text-2xl', 'text-3xl');
    element.classList.remove('sm:text-xs', 'sm:text-sm', 'sm:text-base', 'sm:text-lg', 'sm:text-xl', 'sm:text-2xl', 'sm:text-3xl');

    if (textLength > 20) {
        // Texto muito longo - usar tamanho pequeno
        smallSize.split(' ').forEach(cls => element.classList.add(cls));
    } else if (textLength > 14) {
        // Texto médio - usar tamanho médio
        mediumSize.split(' ').forEach(cls => element.classList.add(cls));
    } else {
        // Texto curto - usar tamanho padrão
        defaultSize.split(' ').forEach(cls => element.classList.add(cls));
    }
}

function formatCurrency(value) {
    if (currentLang === 'pt') {
        return value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    } else if (currentLang === 'en') {
        return value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    } else {
        return value.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
}

function updateExpenseChart(income, expense) {
    const ctx = document.getElementById('expense-chart');
    if (!ctx) return;

    if (expenseChart) {
        expenseChart.destroy();
    }

    const total = income + expense;
    const incomePercent = total > 0 ? (income / total) * 100 : 50;
    const expensePercent = total > 0 ? (expense / total) * 100 : 50;

    expenseChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: [translations[currentLang].income, translations[currentLang].expenses],
            datasets: [{
                data: [incomePercent, expensePercent],
                backgroundColor: ['#10b981', '#ef4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed.toFixed(1) + '%';
                        }
                    }
                }
            }
        }
    });
}

function renderRecentTransactions() {
    const list = document.getElementById('recent-transactions-list');
    const monthTransactions = getMonthTransactions();

    if (monthTransactions.length === 0) {
        list.innerHTML = `<p class="text-center text-gray-400 py-4 text-sm">${translations[currentLang].no_transactions}</p>`;
        return;
    }

    const recent = monthTransactions.slice(-5).reverse();
    list.innerHTML = recent.map(t => createTransactionHTML(t, false, false)).join('');
}

function renderAllTransactions() {
    const list = document.getElementById('all-transactions-list');
    const monthTransactions = getMonthTransactions();

    if (monthTransactions.length === 0) {
        list.innerHTML = `<p class="text-center text-gray-400 py-8 text-sm">${translations[currentLang].no_transactions}</p>`;
        return;
    }

    const sorted = [...monthTransactions].sort((a, b) => new Date(b.date) - new Date(a.date));
    list.innerHTML = sorted.map(t => createTransactionHTML(t, true, true)).join('');
}

function createTransactionHTML(t, showDate = false, showDelete = false) {
    const currency = translations[currentLang].currency;
    const cat = getCategoryById(t.category, t.type);
    const isExpense = t.type === 'expense';
    const amountClass = isExpense ? 'text-red-500' : 'text-green-500';
    const sign = isExpense ? '-' : '+';

    const accountLabels = {
        'credit': translations[currentLang].credit_card,
        'debit': translations[currentLang].debit_card,
        'cash': translations[currentLang].cash
    };
    const accountLabel = accountLabels[t.account] || t.account;

    const accountIcons = {
        'credit': 'fa-credit-card',
        'debit': 'fa-credit-card',
        'cash': 'fa-money-bill-wave'
    };
    const accountIcon = accountIcons[t.account] || 'fa-wallet';

    let dateText = '';
    if (showDate) {
        const date = new Date(t.date);
        dateText = `<span class="text-xs text-gray-400">${date.toLocaleDateString(currentLang)}</span>`;
    }

    const deleteButton = showDelete ? `
        <button onclick="event.stopPropagation(); deleteTransaction(${t.id})"
            class="w-8 h-8 rounded-full bg-red-100 text-red-500 hover:bg-red-500 hover:text-white flex items-center justify-center transition-all ml-2"
            title="Excluir transação">
            <i class="fas fa-trash-alt text-xs"></i>
        </button>
    ` : '';

    return `
        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors group">
            <div class="flex items-center gap-3 flex-1 min-w-0">
                <div class="w-10 h-10 rounded-xl ${cat ? cat.color : 'bg-gray-200'} flex items-center justify-center flex-shrink-0">
                    <i class="fas ${cat ? cat.icon : 'fa-question'}"></i>
                </div>
                <div class="min-w-0 flex-1">
                    <p class="font-medium text-slate-800 text-sm truncate">${t.description}</p>
                    <div class="flex items-center gap-2 mt-1">
                        ${dateText}
                        <span class="text-xs text-gray-500 flex items-center gap-1 bg-gray-200 px-2 py-0.5 rounded-full">
                            <i class="fas ${accountIcon} text-xs"></i>
                            ${accountLabel}
                        </span>
                    </div>
                </div>
            </div>
            <div class="flex items-center flex-shrink-0">
                <span class="font-bold ${amountClass} text-sm whitespace-nowrap">${sign} ${currency} ${formatCurrency(parseFloat(t.amount))}</span>
                ${deleteButton}
            </div>
        </div>
    `;
}

function getCategoryById(id, type) {
    const list = categories[type] || [];
    const category = list.find(c => c.id === id);

    // Se encontrou a categoria, garantir que ela tem a estrutura name correta
    if (category && category.name) {
        return category;
    }

    // Se não encontrou ou a categoria está mal formada, retornar categoria padrão
    return null;
}

async function deleteTransaction(id) {
    if (!confirm('Tem certeza que deseja excluir esta transação?')) {
        return;
    }

    try {
        await apiRequest('delete_transaction', { id }, 'POST');
        await loadTransactions();
        alert('Transação excluída com sucesso!');
    } catch (error) {
        alert('Erro ao excluir transação: ' + error.message);
    }
}

// ==================== FILTROS AVANÇADOS ====================
function updateCategoryFilter() {
    const categoryFilter = document.getElementById('category-filter');
    if (!categoryFilter) return;

    // Salvar o valor selecionado atualmente
    const currentValue = categoryFilter.value;

    categoryFilter.innerHTML = '<option value="">Todas as Categorias</option>';

    // Categorias de Despesas (incluindo customizadas)
    const expenseCategories = (categories.expense || []).map(cat => {
        const name = cat.name ? (cat.name[currentLang] || cat.name.pt || cat.name.en || 'Sem Nome') : 'Sem Nome';
        return {
            id: cat.id,
            name: name,
            type: 'expense',
            custom: cat.custom || false
        };
    });

    // Categorias de Receitas (incluindo customizadas)
    const incomeCategories = (categories.income || []).map(cat => {
        const name = cat.name ? (cat.name[currentLang] || cat.name.pt || cat.name.en || 'Sem Nome') : 'Sem Nome';
        return {
            id: cat.id,
            name: name,
            type: 'income',
            custom: cat.custom || false
        };
    });

    // Criar optgroup para Despesas
    if (expenseCategories.length > 0) {
        const optgroupExpense = document.createElement('optgroup');
        optgroupExpense.label = '💸 Despesas';
        expenseCategories.forEach(cat => {
            const option = document.createElement('option');
            option.value = `expense:${cat.id}`;
            option.textContent = cat.custom ? `${cat.name} ⭐` : cat.name;
            optgroupExpense.appendChild(option);
        });
        categoryFilter.appendChild(optgroupExpense);
    }

    // Criar optgroup para Receitas
    if (incomeCategories.length > 0) {
        const optgroupIncome = document.createElement('optgroup');
        optgroupIncome.label = '💰 Receitas';
        incomeCategories.forEach(cat => {
            const option = document.createElement('option');
            option.value = `income:${cat.id}`;
            option.textContent = cat.custom ? `${cat.name} ⭐` : cat.name;
            optgroupIncome.appendChild(option);
        });
        categoryFilter.appendChild(optgroupIncome);
    }

    // Restaurar o valor selecionado anteriormente
    if (currentValue) {
        categoryFilter.value = currentValue;
    }
}

function applyFilters() {
    const monthFilter = document.getElementById('month-filter').value;
    const categoryFilter = document.getElementById('category-filter').value;
    const typeFilter = document.getElementById('type-filter') ? document.getElementById('type-filter').value : '';
    const accountFilter = document.getElementById('account-filter') ? document.getElementById('account-filter').value : '';

    let filtered = [...transactions];

    // Filtrar por mês
    if (monthFilter) {
        filtered = filtered.filter(t => t.month === monthFilter);
    }

    // Filtrar por categoria (corrigido para funcionar com categorias customizadas)
    if (categoryFilter) {
        const parts = categoryFilter.split(':');
        if (parts.length === 2) {
            const [type, categoryId] = parts;
            filtered = filtered.filter(t => t.type === type && t.category === categoryId);
        }
    }

    // Filtrar por tipo (receita/despesa)
    if (typeFilter) {
        filtered = filtered.filter(t => t.type === typeFilter);
    }

    // Filtrar por conta (cartão crédito/débito/dinheiro)
    if (accountFilter) {
        filtered = filtered.filter(t => t.account === accountFilter);
    }

    // Calcular totais filtrados
    let income = 0;
    let expense = 0;
    filtered.forEach(t => {
        if (t.type === 'income') income += parseFloat(t.amount);
        else expense += parseFloat(t.amount);
    });

    // Mostrar resumo
    const summary = document.getElementById('filter-summary');
    const currency = translations[currentLang].currency;
    if (monthFilter || categoryFilter || typeFilter || accountFilter) {
        if (summary) {
            summary.classList.remove('hidden');
            const incomeEl = document.getElementById('filter-income');
            const expenseEl = document.getElementById('filter-expense');
            const balanceEl = document.getElementById('filter-balance');

            if (incomeEl) incomeEl.textContent = `${currency} ${formatCurrency(income)}`;
            if (expenseEl) expenseEl.textContent = `${currency} ${formatCurrency(expense)}`;
            if (balanceEl) balanceEl.textContent = `${currency} ${formatCurrency(income - expense)}`;
        }
    } else {
        if (summary) summary.classList.add('hidden');
    }

    // Renderizar transações filtradas
    const list = document.getElementById('all-transactions-list');
    if (!list) return;

    if (filtered.length === 0) {
        list.innerHTML = `<p class="text-center text-gray-400 py-8 text-sm">${translations[currentLang].no_transactions}</p>`;
        return;
    }

    const sorted = [...filtered].sort((a, b) => new Date(b.date) - new Date(a.date));
    list.innerHTML = sorted.map(t => createTransactionHTML(t, true, true)).join('');
}

function filterTransactions(filter) {
    document.querySelectorAll('.filter-btn').forEach(btn => {
        if (btn.dataset.filter === filter) {
            btn.className = 'filter-btn px-4 py-2 bg-slate-800 text-white rounded-full text-xs sm:text-sm font-medium whitespace-nowrap';
        } else {
            btn.className = 'filter-btn px-4 py-2 bg-gray-100 text-gray-600 rounded-full text-xs sm:text-sm font-medium whitespace-nowrap hover:bg-gray-200 transition-colors';
        }
    });

    const monthFilter = document.getElementById('month-filter').value;
    let monthTransactions = monthFilter ? transactions.filter(t => t.month === monthFilter) : getMonthTransactions();

    let filtered = monthTransactions;

    if (filter !== 'all') {
        filtered = monthTransactions.filter(t => t.type === filter);
    }

    const list = document.getElementById('all-transactions-list');

    if (filtered.length === 0) {
        list.innerHTML = `<p class="text-center text-gray-400 py-8 text-sm">${translations[currentLang].no_transactions}</p>`;
        return;
    }

    const sorted = [...filtered].sort((a, b) => new Date(b.date) - new Date(a.date));
    list.innerHTML = sorted.map(t => createTransactionHTML(t, true, true)).join('');
}

// ==================== DASHBOARD COM GRÁFICOS ====================
function updateDashboardCharts() {
    const selectedMonth = document.getElementById('dashboard-month-filter').value;
    const monthTransactions = transactions.filter(t => t.month === selectedMonth);

    // Gráfico de pizza - Despesas por categoria
    updateCategoryPieChart(monthTransactions);

    // Gráfico de barras - Receitas vs Despesas
    updateIncomeExpenseChart(monthTransactions);

    // Top 5 categorias
    updateTopCategories(monthTransactions);
}

function updateCategoryPieChart(monthTransactions) {
    const ctx = document.getElementById('category-pie-chart');
    if (!ctx) return;

    const expenses = monthTransactions.filter(t => t.type === 'expense');
    const categoryTotals = {};

    expenses.forEach(t => {
        if (!categoryTotals[t.category]) {
            categoryTotals[t.category] = 0;
        }
        categoryTotals[t.category] += parseFloat(t.amount);
    });

    const labels = [];
    const data = [];
    const colors = [];

    Object.entries(categoryTotals).forEach(([catId, total]) => {
        const cat = getCategoryById(catId, 'expense');
        if (cat) {
            labels.push(cat.name[currentLang]);
            data.push(total);
            colors.push(cat.color.includes('red') ? '#ef4444' :
                       cat.color.includes('orange') ? '#f97316' :
                       cat.color.includes('yellow') ? '#eab308' :
                       cat.color.includes('green') ? '#10b981' :
                       cat.color.includes('blue') ? '#3b82f6' :
                       cat.color.includes('purple') ? '#a855f7' :
                       cat.color.includes('pink') ? '#ec4899' : '#6b7280');
        }
    });

    if (categoryPieChart) {
        categoryPieChart.destroy();
    }

    categoryPieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: colors,
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const currency = translations[currentLang].currency;
                            return context.label + ': ' + currency + ' ' + formatCurrency(context.parsed);
                        }
                    }
                }
            }
        }
    });
}

function updateIncomeExpenseChart(monthTransactions) {
    const ctx = document.getElementById('income-expense-bar-chart');
    if (!ctx) return;

    let income = 0;
    let expense = 0;

    monthTransactions.forEach(t => {
        if (t.type === 'income') income += parseFloat(t.amount);
        else expense += parseFloat(t.amount);
    });

    if (incomeExpenseChart) {
        incomeExpenseChart.destroy();
    }

    incomeExpenseChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [translations[currentLang].income, translations[currentLang].expenses],
            datasets: [{
                label: `Valor (${currency})`,
                data: [income, expense],
                backgroundColor: ['#10b981', '#ef4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const currency = translations[currentLang].currency;
                            return currency + ' ' + formatCurrency(context.parsed.y);
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

function updateTopCategories(monthTransactions) {
    const expenses = monthTransactions.filter(t => t.type === 'expense');
    const categoryTotals = {};

    expenses.forEach(t => {
        if (!categoryTotals[t.category]) {
            categoryTotals[t.category] = 0;
        }
        categoryTotals[t.category] += parseFloat(t.amount);
    });

    const sorted = Object.entries(categoryTotals)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5);

    const list = document.getElementById('top-categories-list');
    const currency = translations[currentLang].currency;

    if (sorted.length === 0) {
        list.innerHTML = '<p class="text-center text-gray-400 text-sm">Nenhuma despesa neste período</p>';
        return;
    }

    list.innerHTML = sorted.map(([catId, total], index) => {
        const cat = getCategoryById(catId, 'expense');
        const percentage = (total / sorted.reduce((sum, [, val]) => sum + val, 0)) * 100;

        return `
            <div class="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                <span class="text-lg font-bold text-gray-400">#${index + 1}</span>
                <div class="w-10 h-10 rounded-lg ${cat.color} flex items-center justify-center">
                    <i class="fas ${cat.icon}"></i>
                </div>
                <div class="flex-1">
                    <p class="font-medium text-slate-800 text-sm">${cat.name[currentLang]}</p>
                    <div class="w-full bg-gray-200 rounded-full h-2 mt-1">
                        <div class="bg-red-500 h-2 rounded-full" style="width: ${percentage}%"></div>
                    </div>
                </div>
                <span class="font-bold text-red-500 text-sm">${currency} ${formatCurrency(total)}</span>
            </div>
        `;
    }).join('');
}

// ==================== CATEGORIAS PERSONALIZADAS ====================
function showAddCategoryModal() {
    selectedIcon = availableIcons[0];
    selectedColor = availableColors[0];

    const iconGrid = document.getElementById('icon-selector');
    iconGrid.innerHTML = '';
    availableIcons.forEach((icon, idx) => {
        const div = document.createElement('div');
        div.className = `icon-option ${idx === 0 ? 'selected' : ''}`;
        div.innerHTML = `<i class="fas ${icon}"></i>`;
        div.onclick = () => selectIcon(icon, div);
        iconGrid.appendChild(div);
    });

    const colorGrid = document.getElementById('color-selector');
    colorGrid.innerHTML = '';
    availableColors.forEach((color, idx) => {
        const div = document.createElement('div');
        div.className = `color-option ${color.bg} ${idx === 0 ? 'selected' : ''}`;
        div.onclick = () => selectColor(color, div);
        colorGrid.appendChild(div);
    });

    updatePreview();

    const modal = document.getElementById('add-category-modal');
    const content = document.getElementById('add-category-content');
    modal.classList.remove('hidden');
    setTimeout(() => {
        content.classList.remove('scale-95', 'opacity-0');
        content.classList.add('scale-100', 'opacity-100');
    }, 10);
}

function closeAddCategoryModal() {
    const modal = document.getElementById('add-category-modal');
    const content = document.getElementById('add-category-content');
    content.classList.remove('scale-100', 'opacity-100');
    content.classList.add('scale-95', 'opacity-0');
    setTimeout(() => {
        modal.classList.add('hidden');
        document.getElementById('new-category-name').value = '';
    }, 300);
}

function selectIcon(icon, element) {
    selectedIcon = icon;
    document.querySelectorAll('.icon-option').forEach(el => el.classList.remove('selected'));
    element.classList.add('selected');
    updatePreview();
}

function selectColor(color, element) {
    selectedColor = color;
    document.querySelectorAll('.color-option').forEach(el => el.classList.remove('selected'));
    element.classList.add('selected');
    updatePreview();
}

function updatePreview() {
    const nameInput = document.getElementById('new-category-name');
    const name = nameInput ? nameInput.value || '...' : '...';

    const previewName = document.getElementById('preview-name');
    if (previewName) {
        previewName.textContent = name;
    }

    const preview = document.getElementById('category-preview');
    if (preview && selectedColor) {
        preview.className = `w-10 h-10 rounded-xl ${selectedColor.light} ${selectedColor.text} flex items-center justify-center text-sm`;
        preview.innerHTML = `<i class="fas ${selectedIcon}"></i>`;
    }
}


async function deleteCategory(catId, dbId) {
    if (!confirm('⚠️ Tem certeza que deseja remover esta categoria?\n\nEsta ação não pode ser desfeita!')) {
        return;
    }

    try {
        const result = await apiRequest('delete_custom_category', {
            id: dbId
        }, 'POST');

        if (result.success) {
            // Recarregar categorias do servidor
            await loadCustomCategories();

            // Se a categoria deletada estava selecionada, limpar seleção
            if (selectedCategory === catId) {
                selectedCategory = null;
            }

            // Re-renderizar categorias
            renderCategories();

            // Atualizar filtro de categorias
            updateCategoryFilter();

            alert('✅ Categoria removida com sucesso!');
        } else {
            throw new Error(result.error || 'Erro desconhecido');
        }
    } catch (error) {
        console.error('Erro ao remover categoria:', error);
        alert('❌ Erro ao remover categoria: ' + error.message);
    }
}

async function saveNewCategory() {
    const name = document.getElementById('new-category-name').value.trim();
    if (!name) {
        alert('Digite um nome para a categoria');
        return;
    }

    const newCategoryId = 'custom_' + Date.now();
    const colorClass = `${selectedColor.light} ${selectedColor.text}`;

    try {
        const result = await apiRequest('add_custom_category', {
            category_id: newCategoryId,
            name_pt: name,
            name_en: name,
            name_de: name,
            icon: selectedIcon,
            color: colorClass,
            type: currentType
        }, 'POST');

        console.log('Categoria salva:', result);

        // Recarregar categorias do servidor para garantir sincronização
        await loadCustomCategories();

        // Fechar modal
        closeAddCategoryModal();

        // Selecionar automaticamente a categoria recém-criada
        selectedCategory = newCategoryId;

        // Re-renderizar as categorias com a nova selecionada
        renderCategories();

        // Atualizar filtro de categorias na tela de transações
        updateCategoryFilter();

        // Destacar a categoria recém-adicionada com scroll suave
        setTimeout(() => {
            const categoryButtons = document.querySelectorAll('.category-btn');
            categoryButtons.forEach(btn => {
                const onclickAttr = btn.getAttribute('onclick');
                if (onclickAttr && onclickAttr.includes(newCategoryId)) {
                    btn.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
                    // Adicionar efeito visual de destaque
                    btn.classList.add('ring-4', 'ring-green-300');
                    setTimeout(() => {
                        btn.classList.remove('ring-4', 'ring-green-300');
                    }, 2000);
                }
            });
        }, 150);

        alert('✅ Categoria "' + name + '" adicionada com sucesso!');
    } catch (error) {
        console.error('Erro ao salvar categoria:', error);
        alert('❌ Erro ao salvar categoria: ' + error.message);
    }
}

function highlightSelectedCategory(catId) {
    const buttons = document.querySelectorAll('.category-btn');
    buttons.forEach(btn => {
        btn.className = 'category-btn p-2 sm:p-3 rounded-2xl bg-gray-50 border-2 border-transparent text-gray-600 flex flex-col items-center gap-1 transition-all';
    });

    if (buttons.length > 0) {
        const lastBtn = buttons[buttons.length - 1];
        lastBtn.className = 'category-btn p-2 sm:p-3 rounded-2xl bg-blue-50 border-2 border-blue-500 text-blue-600 flex flex-col items-center gap-1 transition-all';
    }
}

function renderCategories() {
    const grid = document.getElementById('category-grid');
    if (!grid) return;

    const list = categories[currentType] || [];

    console.log(`🎨 Renderizando ${list.length} categorias do tipo ${currentType}:`, list);

    grid.innerHTML = list.map((cat, index) => {
        const isSelected = selectedCategory === cat.id;

        // Obter nome da categoria no idioma atual
        const categoryName = cat.name ? (cat.name[currentLang] || cat.name.pt || cat.name.en || 'Sem Nome') : 'Sem Nome';

        console.log(`   [${index}] Nome: ${categoryName}, Ícone: ${cat.icon}, Cor: ${cat.color}, Custom: ${cat.custom}`);

        // Botão de deletar para categorias customizadas
        const deleteBtn = cat.custom ? `
            <button onclick="event.stopPropagation(); deleteCategory('${cat.id}', ${cat.dbId})"
                    class="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 hover:bg-red-600 text-white flex items-center justify-center shadow-lg transition-all z-50"
                    title="Remover categoria">
                <i class="fas fa-times text-xs"></i>
            </button>
        ` : '';

        return `
            <div class="relative">
                ${deleteBtn}
                <button onclick="selectCategory('${cat.id}')"
                    class="category-btn w-full aspect-square p-2 rounded-2xl ${cat.color} border-2 ${isSelected ? 'border-blue-500 ring-2 ring-blue-300 shadow-lg' : 'border-transparent'} flex flex-col items-center justify-center gap-1 transition-all group hover:scale-105 hover:shadow-md">
                    <i class="fas ${cat.icon} text-lg"></i>
                    <span class="text-[10px] font-medium text-center leading-tight mt-1">${categoryName}</span>
                </button>
            </div>
        `;
    }).join('') + `
        <button onclick="showAddCategoryModal()"
            class="category-btn w-full aspect-square p-2 rounded-2xl bg-gray-50 border-2 border-dashed border-gray-300 text-gray-400 flex flex-col items-center justify-center gap-1 transition-all hover:border-blue-500 hover:text-blue-500 hover:scale-105 hover:bg-blue-50">
            <i class="fas fa-plus text-lg"></i>
            <span class="text-[10px] font-medium text-center leading-tight mt-1">${translations[currentLang].add_category || '+ Cat'}</span>
        </button>
    `;
}

function selectCategory(id) {
    selectedCategory = id;
    renderCategories();
}

function selectType(type) {
    currentType = type;
    selectedCategory = null;

    const btnExpense = document.getElementById('btn-expense');
    const btnIncome = document.getElementById('btn-income');

    if (type === 'expense') {
        btnExpense.className = 'flex-1 py-3 rounded-xl bg-white text-red-500 font-semibold shadow-sm transition-all text-sm sm:text-base';
        btnIncome.className = 'flex-1 py-3 rounded-xl text-gray-500 font-medium transition-all text-sm sm:text-base';
    } else {
        btnExpense.className = 'flex-1 py-3 rounded-xl text-gray-500 font-medium transition-all text-sm sm:text-base';
        btnIncome.className = 'flex-1 py-3 rounded-xl bg-white text-green-500 font-semibold shadow-sm transition-all text-sm sm:text-base';
    }

    renderCategories();
}

async function saveTransaction() {
    const amount = getAmountValue();
    const description = document.getElementById('description-input').value.trim();
    const date = document.getElementById('date-input').value;
    const account = document.getElementById('account-input').value;

    if (!amount || amount <= 0) {
        alert('Digite um valor válido');
        return;
    }
    if (!description) {
        alert('Digite uma descrição');
        return;
    }
    if (!selectedCategory) {
        alert('Selecione uma categoria');
        return;
    }
    if (!date) {
        alert('Selecione uma data');
        return;
    }
    if (!account) {
        alert('Selecione a forma de pagamento');
        return;
    }

    try {
        const transactionData = {
            action: 'add_transaction',
            amount: amount,
            description: description,
            date: date,
            category: selectedCategory,
            type: currentType,
            account: account
        };

        const response = await fetch('api.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(transactionData)
        });

        const result = await response.json();

        if (result.error) {
            throw new Error(result.error);
        }

        console.log('Transaction saved:', result);

        // Resetar formulário
        currentAmountValue = 0;
        updateAmountDisplay();
        document.getElementById('description-input').value = '';
        selectedCategory = null;

        // Recarregar transações e atualizar UI
        await loadTransactions();

        showScreen('dashboard');

        alert(currentType === 'expense' ? 'Despesa salva com sucesso!' : 'Receita salva com sucesso!');
    } catch (error) {
        console.error('Erro ao salvar transação:', error);
        alert('Erro ao salvar transação: ' + error.message);
    }
}

// ==================== NAVEGAÇÃO ====================
function showScreen(screenName) {
    document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));

    const target = document.getElementById(screenName);
    if (target) {
        target.classList.remove('hidden');
        target.classList.add('fade-in');
    }

    document.querySelectorAll('.nav-btn').forEach(btn => {
        if (btn.dataset.screen === screenName) {
            btn.className = 'nav-btn flex flex-col items-center gap-1 text-blue-600';
        } else {
            btn.className = 'nav-btn flex flex-col items-center gap-1 text-gray-400';
        }
    });

    if (screenName === 'add') {
        document.getElementById('date-input').valueAsDate = new Date();
        selectType('expense');
        currentAmountValue = 0;
        updateAmountDisplay();
    }

    if (screenName === 'dashboard-chart') {
        setTimeout(() => updateDashboardCharts(), 100);
    }

    if (screenName === 'transactions') {
        document.getElementById('month-filter').value = currentMonth;
        applyFilters();
    }
}

// ==================== BACKUP E IMPORTAÇÃO ====================
async function exportAllData() {
    const data = await apiRequest('export_all_data');

    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = `FinControl_Backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    alert('✅ Backup exportado com sucesso!');
}

function showImportModal() {
    const modal = document.getElementById('import-modal');
    modal.classList.remove('hidden');
}

function closeImportModal() {
    const modal = document.getElementById('import-modal');
    modal.classList.add('hidden');
}

async function handleImportFile(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async function(e) {
        try {
            const data = JSON.parse(e.target.result);

            if (!confirm('⚠️ ATENÇÃO: Isto irá SUBSTITUIR todos os seus dados atuais!\n\nDeseja continuar?')) {
                return;
            }

            await apiRequest('import_all_data', data, 'POST');

            closeImportModal();
            await loadTransactions();
            await loadCustomCategories();
            await loadUserData();

            alert('✅ Dados importados com sucesso!');
        } catch (error) {
            alert('❌ Erro ao importar dados: ' + error.message);
        }
    };
    reader.readAsText(file);
}

// ==================== LEMBRETE DE BACKUP ====================
function checkBackupReminder() {
    const today = new Date();
    const day = today.getDate();

    // Mostrar lembrete nos dias 25, 26 ou 27
    if (day >= 25 && day <= 27) {
        const lastReminder = localStorage.getItem('last_backup_reminder');
        const currentMonth = today.toISOString().substring(0, 7);

        if (lastReminder !== currentMonth) {
            setTimeout(() => {
                document.getElementById('backup-reminder-modal').classList.remove('hidden');
            }, 3000);
        }
    }
}

function closeBackupReminderModal() {
    document.getElementById('backup-reminder-modal').classList.add('hidden');
    const today = new Date();
    const currentMonth = today.toISOString().substring(0, 7);
    localStorage.setItem('last_backup_reminder', currentMonth);
}

function remindBackupLater() {
    closeBackupReminderModal();
}

// ==================== DOAÇÃO ====================
function showDonateModal() {
    const modal = document.getElementById('donate-modal');
    const content = document.getElementById('donate-content');
    modal.classList.remove('hidden');
    setTimeout(() => {
        content.classList.remove('scale-95', 'opacity-0');
        content.classList.add('scale-100', 'opacity-100');
    }, 10);
}

function closeDonateModal() {
    const modal = document.getElementById('donate-modal');
    const content = document.getElementById('donate-content');
    content.classList.remove('scale-100', 'opacity-100');
    content.classList.add('scale-95', 'opacity-0');
    setTimeout(() => modal.classList.add('hidden'), 300);
}

function copyPixKey() {
    const pixKey = 'f6c00e65-b267-45d0-a6da-9ac9ca57a131';

    if (navigator.clipboard) {
        navigator.clipboard.writeText(pixKey).then(() => {
            alert('✅ Chave PIX copiada!\n\nObrigado pelo seu apoio! 💚');
        });
    } else {
        const textArea = document.createElement('textarea');
        textArea.value = pixKey;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        alert('✅ Chave PIX copiada!\n\nObrigado pelo seu apoio! 💚');
    }
}

function copyNubankLink() {
    const nubankLink = 'https://nubank.com.br/cobrar/11e4sv/69bcb0bc-4666-4e8d-a4b3-c504a18ad767';

    if (navigator.clipboard) {
        navigator.clipboard.writeText(nubankLink).then(() => {
            alert('✅ Link do Nubank copiado!\n\nObrigado pelo seu apoio! 💚');
        });
    } else {
        const textArea = document.createElement('textarea');
        textArea.value = nubankLink;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        alert('✅ Link do Nubank copiado!\n\nObrigado pelo seu apoio! 💚');
    }
}

// ==================== EDITAR NOME ====================
async function editName() {
    const currentName = document.getElementById('user-name').textContent;
    const newName = prompt('Digite seu nome:', currentName);
    if (newName && newName.trim()) {
        document.getElementById('user-name').textContent = newName.trim();
        const initials = newName.trim().split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
        document.getElementById('user-avatar').textContent = initials;

        await apiRequest('update_user_name', { name: newName.trim() }, 'POST');
    }
}

// ==================== RELÓGIO ====================
function updateClock() {
    const now = new Date();
    document.getElementById('clock').textContent =
        `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
}
setInterval(updateClock, 1000);
updateClock();

// ==================== INICIALIZAÇÃO ====================
document.addEventListener('DOMContentLoaded', async function() {
    console.log('🚀 Inicializando FinControl Pro...');

    await loadUserSettings();
    await loadUserData();
    await loadCustomCategories();

    initMonthFilter();

    await loadTransactions();

    checkBackupReminder();

    console.log('✅ FinControl Pro inicializado!');
});
