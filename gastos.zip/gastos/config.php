<?php
// Configuração do Banco de Dados SQLite
define('DB_PATH', __DIR__ . '/data/fincontrol.db');

// Criar diretório de dados se não existir
if (!file_exists(__DIR__ . '/data')) {
    mkdir(__DIR__ . '/data', 0755, true);
}

// Função para obter conexão PDO
function getDB() {
    try {
        $db = new PDO('sqlite:' . DB_PATH);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $db;
    } catch (PDOException $e) {
        die('Erro ao conectar ao banco de dados: ' . $e->getMessage());
    }
}

// Criar tabelas se não existirem
function initDatabase() {
    $db = getDB();

    // Tabela de usuários
    $db->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // Tabela de transações
    $db->exec("CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        amount REAL NOT NULL,
        description TEXT NOT NULL,
        date TEXT NOT NULL,
        category TEXT NOT NULL,
        type TEXT NOT NULL,
        account TEXT NOT NULL,
        month TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id)
    )");

    // Tabela de categorias personalizadas
    $db->exec("CREATE TABLE IF NOT EXISTS custom_categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        category_id TEXT NOT NULL,
        name_pt TEXT NOT NULL,
        name_en TEXT NOT NULL,
        name_de TEXT NOT NULL,
        icon TEXT NOT NULL,
        color TEXT NOT NULL,
        type TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id)
    )");

    // Tabela de configurações do usuário
    $db->exec("CREATE TABLE IF NOT EXISTS user_settings (
        user_id TEXT PRIMARY KEY,
        theme TEXT DEFAULT 'light',
        language TEXT DEFAULT 'pt',
        backup_reminder_date TEXT,
        is_supporter INTEGER DEFAULT 0,
        FOREIGN KEY (user_id) REFERENCES users(user_id)
    )");

    // Índices para melhor performance
    $db->exec("CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_transactions_month ON transactions(month)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(date)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_custom_categories_user ON custom_categories(user_id)");
}

// Inicializar banco de dados
initDatabase();
