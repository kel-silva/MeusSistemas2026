<?php
// Script para gerar ícones PNG simples

function createIcon($size, $filename) {
    $image = imagecreatetruecolor($size, $size);
    
    // Fundo gradiente azul
    $blue1 = imagecolorallocate($image, 59, 130, 246);
    $blue2 = imagecolorallocate($image, 147, 51, 234);
    
    for ($i = 0; $i < $size; $i++) {
        $color = imagecolorallocate($image, 
            59 + ($i * 88 / $size), 
            130 - ($i * 79 / $size), 
            246 - ($i * 12 / $size)
        );
        imagefilledrectangle($image, 0, $i, $size, $i + 1, $color);
    }
    
    // Texto
    $white = imagecolorallocate($image, 255, 255, 255);
    
    $fontSize = $size / 8;
    $text = "$";
    
    $bbox = imagettfbbox($fontSize, 0, __DIR__ . '/arial.ttf', $text);
    if (!$bbox) {
        // Fallback sem fonte TrueType
        $text = "FC";
        imagestring($image, 5, $size/2 - 15, $size/2 - 10, $text, $white);
    } else {
        $x = ($size - ($bbox[2] - $bbox[0])) / 2;
        $y = ($size - ($bbox[7] - $bbox[1])) / 2;
        imagettftext($image, $fontSize, 0, $x, $y, $white, __DIR__ . '/arial.ttf', $text);
    }
    
    // Círculo branco ao redor
    imagesetthickness($image, $size / 32);
    imagearc($image, $size/2, $size/2, $size - $size/8, $size - $size/8, 0, 360, $white);
    
    imagepng($image, $filename);
    imagedestroy($image);
}

// Criar ícones
createIcon(192, 'icon-192.png');
createIcon(512, 'icon-512.png');

echo "✅ Ícones criados com sucesso!\n";
?>
