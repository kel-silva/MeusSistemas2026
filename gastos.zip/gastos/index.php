<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#1e293b">
    <title>FinControl Pro</title>

    <!-- PWA Meta Tags -->
    <link rel="manifest" href="manifest.json">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="FinControl Pro">

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

        * {
            font-family: 'Inter', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        .hide-scrollbar::-webkit-scrollbar { display: none; }
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }

        .slide-up { animation: slideUp 0.3s ease-out; }
        @keyframes slideUp { from { transform: translateY(100%); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

        .fade-in { animation: fadeIn 0.3s ease-out; }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

        .pulse { animation: pulse 2s infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.7; } }

        @media (max-width: 640px) {
            .mobile-container {
                width: 100%;
                height: 100vh;
                border-radius: 0;
                border: none;
                max-width: 100%;
            }
        }

        @media (min-width: 641px) {
            .mobile-container {
                max-width: 480px;
                height: 90vh;
                margin: auto;
                border-radius: 2rem;
                border: 8px solid #1f2937;
            }
        }

        .lang-btn {
            transition: all 0.3s ease;
        }
        .lang-btn.active {
            background: #3b82f6;
            color: white;
            transform: scale(1.05);
        }

        .modal-overlay {
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(4px);
        }

        .theme-toggle {
            transition: all 0.3s ease;
        }
        .theme-toggle:hover {
            transform: scale(1.1);
        }

        /* TEMA ESCURO */
        body.dark-theme {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%);
        }

        body.dark-theme .mobile-container {
            background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
            border-color: #334155;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }

        body.dark-theme .bg-white {
            background: linear-gradient(145deg, #1e293b 0%, #334155 100%) !important;
            border: 1px solid rgba(148, 163, 184, 0.1);
        }

        body.dark-theme .bg-gray-50 {
            background: #0f172a !important;
        }

        body.dark-theme .bg-gray-100 {
            background: #1e293b !important;
        }

        body.dark-theme .text-slate-800 {
            color: #f1f5f9 !important;
        }

        body.dark-theme .text-gray-600 {
            color: #94a3b8 !important;
        }

        body.dark-theme .text-gray-500 {
            color: #64748b !important;
        }

        body.dark-theme input,
        body.dark-theme select {
            background: #334155 !important;
            color: #f1f5f9 !important;
            border-color: #475569 !important;
        }

        body.dark-theme input::placeholder {
            color: #64748b !important;
        }

        .color-option {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            cursor: pointer;
            border: 3px solid transparent;
            transition: all 0.2s;
            flex-shrink: 0;
        }
        .color-option.selected {
            border-color: #1f2937;
            transform: scale(1.15);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.3);
        }

        .icon-option {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            background: #f3f4f6;
            transition: all 0.2s;
            font-size: 16px;
            flex-shrink: 0;
        }
        .icon-option.selected {
            background: #3b82f6;
            color: white;
            transform: scale(1.1);
        }

        .category-btn {
            transition: all 0.2s;
        }
        .category-btn:hover {
            transform: translateY(-2px);
        }
    </style>
</head>
<body class="bg-gray-200 min-h-screen flex items-center justify-center p-0 sm:p-4">

    <!-- APP PRINCIPAL -->
    <div id="main-app" class="mobile-container relative w-full bg-gray-50 overflow-hidden shadow-2xl flex flex-col">

        <!-- Botão Doar -->
        <div class="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-4 py-2 text-center text-sm font-medium flex-shrink-0 flex items-center justify-center gap-2">
            <span>☕ Gostou do app?</span>
            <button onclick="showDonateModal()" class="bg-white/20 px-3 py-1 rounded-full text-xs hover:bg-white/30 transition-all font-bold">
                ❤️ Doe um café
            </button>
        </div>

        <!-- Status Bar -->
        <div class="h-12 bg-slate-900 flex items-center justify-between px-4 sm:px-6 z-50 text-white text-xs flex-shrink-0">
            <span id="clock">9:41</span>

            <div class="flex items-center gap-2">
                <button onclick="changeLanguage('pt')" class="lang-btn px-2 py-1 rounded text-xs font-medium bg-gray-700 hover:bg-gray-600 active" data-lang="pt">PT</button>
                <button onclick="changeLanguage('en')" class="lang-btn px-2 py-1 rounded text-xs font-medium bg-gray-700 hover:bg-gray-600" data-lang="en">EN</button>
                <button onclick="changeLanguage('de')" class="lang-btn px-2 py-1 rounded text-xs font-medium bg-gray-700 hover:bg-gray-600" data-lang="de">DE</button>
            </div>

            <div class="flex items-center gap-3">
                <button onclick="toggleTheme()" class="theme-toggle w-8 h-8 rounded-full bg-gray-700 hover:bg-gray-600 flex items-center justify-center text-yellow-400" id="theme-btn" title="Alternar tema">
                    <i class="fas fa-sun" id="theme-icon"></i>
                </button>
                <div class="flex gap-2">
                    <i class="fas fa-signal"></i>
                    <i class="fas fa-wifi"></i>
                    <i class="fas fa-battery-full"></i>
                </div>
            </div>
        </div>

        <!-- Conteúdo -->
        <div id="screen-content" class="flex-1 overflow-y-auto hide-scrollbar pb-20">

            <!-- DASHBOARD -->
            <div id="dashboard" class="screen px-4 sm:px-6 py-4 fade-in">
                <div class="flex justify-between items-center mb-6">
                    <div>
                        <p class="text-gray-500 text-sm" data-i18n="welcome_back">Bem-vindo de volta,</p>
                        <div class="flex items-center gap-2">
                            <h1 id="user-name" class="text-xl sm:text-2xl font-bold text-slate-800 cursor-pointer hover:text-blue-600 transition-colors" onclick="editName()">Digite seu Nome</h1>
                            <i class="fas fa-pencil-alt text-gray-400 text-xs cursor-pointer" onclick="editName()"></i>
                        </div>
                    </div>
                    <div class="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-semibold text-sm sm:text-base" id="user-avatar">U</div>
                </div>

                <!-- Balance Card -->
                <div class="bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl p-5 sm:p-6 text-white mb-6 shadow-lg">
                    <div class="flex justify-between items-start mb-1">
                        <p class="text-gray-300 text-sm" data-i18n="total_balance">Saldo do Mês</p>
                        <span id="current-month-display" class="text-xs bg-white/20 px-2 py-1 rounded-full">Março 2026</span>
                    </div>
                    <h2 class="text-2xl sm:text-3xl font-bold mb-4" id="total-balance">R$ 0,00</h2>
                    <div class="flex justify-between">
                        <div class="flex items-center gap-2">
                            <div class="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center">
                                <i class="fas fa-arrow-down text-green-400 text-sm"></i>
                            </div>
                            <div>
                                <p class="text-xs text-gray-400" data-i18n="income">Receitas</p>
                                <p class="font-semibold text-green-400 text-sm sm:text-base" id="total-income">R$ 0,00</p>
                            </div>
                        </div>
                        <div class="flex items-center gap-2">
                            <div class="w-8 h-8 rounded-full bg-red-500/20 flex items-center justify-center">
                                <i class="fas fa-arrow-up text-red-400 text-sm"></i>
                            </div>
                            <div>
                                <p class="text-xs text-gray-400" data-i18n="expenses">Despesas</p>
                                <p class="font-semibold text-red-400 text-sm sm:text-base" id="total-expense">R$ 0,00</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="grid grid-cols-4 gap-2 sm:gap-4 mb-6">
                    <button onclick="showScreen('add')" class="flex flex-col items-center gap-1 sm:gap-2 group">
                        <div class="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center text-lg sm:text-xl group-hover:bg-blue-600 group-hover:text-white transition-all shadow-sm">
                            <i class="fas fa-plus"></i>
                        </div>
                        <span class="text-xs text-gray-600 font-medium" data-i18n="add">Adicionar</span>
                    </button>
                    <button onclick="showScreen('transactions')" class="flex flex-col items-center gap-1 sm:gap-2 group">
                        <div class="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-purple-100 text-purple-600 flex items-center justify-center text-lg sm:text-xl group-hover:bg-purple-600 group-hover:text-white transition-all shadow-sm">
                            <i class="fas fa-list"></i>
                        </div>
                        <span class="text-xs text-gray-600 font-medium" data-i18n="statement">Extrato</span>
                    </button>
                    <button onclick="exportAllData()" class="flex flex-col items-center gap-1 sm:gap-2 group">
                        <div class="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-green-100 text-green-600 flex items-center justify-center text-lg sm:text-xl group-hover:bg-green-600 group-hover:text-white transition-all shadow-sm">
                            <i class="fas fa-download"></i>
                        </div>
                        <span class="text-xs text-gray-600 font-medium" data-i18n="export">Exportar</span>
                    </button>
                    <button onclick="showImportModal()" class="flex flex-col items-center gap-1 sm:gap-2 group">
                        <div class="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center text-lg sm:text-xl group-hover:bg-amber-600 group-hover:text-white transition-all shadow-sm">
                            <i class="fas fa-upload"></i>
                        </div>
                        <span class="text-xs text-gray-600 font-medium" data-i18n="import">Importar</span>
                    </button>
                </div>

                <!-- Monthly Chart -->
                <div class="bg-white rounded-3xl p-4 sm:p-6 mb-6 shadow-sm">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="font-bold text-slate-800 text-sm sm:text-base" data-i18n="month_summary">Resumo do Mês</h3>
                        <select id="month-select-dashboard" onchange="changeMonth(this.value)" class="text-xs bg-gray-100 rounded-lg px-3 py-2 border-none outline-none cursor-pointer hover:bg-gray-200 transition-colors font-medium text-slate-800">
                        </select>
                    </div>
                    <div class="flex items-center justify-center">
                        <canvas id="expense-chart" width="250" height="250"></canvas>
                    </div>
                </div>

                <!-- Recent Transactions -->
                <div class="bg-white rounded-3xl p-4 sm:p-6 shadow-sm">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="font-bold text-slate-800 text-sm sm:text-base" data-i18n="recent_transactions">Transações do Mês</h3>
                        <button onclick="showScreen('transactions')" class="text-blue-600 text-xs sm:text-sm font-medium hover:underline" data-i18n="see_all">Ver todas</button>
                    </div>
                    <div id="recent-transactions-list" class="space-y-3"></div>
                </div>
            </div>

            <!-- TRANSACTIONS SCREEN COM FILTROS AVANÇADOS -->
            <div id="transactions" class="screen px-4 sm:px-6 py-4 hidden">
                <div class="flex items-center gap-4 mb-6">
                    <button onclick="showScreen('dashboard')" class="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 hover:bg-gray-200 transition-colors">
                        <i class="fas fa-arrow-left"></i>
                    </button>
                    <div class="flex-1">
                        <h1 class="text-xl sm:text-2xl font-bold text-slate-800" data-i18n="transactions">Transações</h1>
                        <p id="transactions-month-label" class="text-xs text-gray-500">Março 2026</p>
                    </div>
                    <button onclick="showScreen('dashboard-chart')" class="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center hover:bg-blue-600 hover:text-white transition-all" title="Ver Dashboard">
                        <i class="fas fa-chart-pie"></i>
                    </button>
                </div>

                <!-- FILTROS AVANÇADOS -->
                <div class="bg-white rounded-2xl p-4 mb-4 shadow-sm">
                    <div class="grid grid-cols-1 gap-3">
                        <!-- Filtro de Mês -->
                        <div>
                            <label class="block text-xs font-medium text-gray-700 mb-1">Filtrar por Mês</label>
                            <select id="month-filter" onchange="applyFilters()" class="w-full text-sm bg-gray-50 rounded-lg px-3 py-2 border border-gray-200 outline-none cursor-pointer hover:bg-gray-100 transition-colors font-medium text-slate-800">
                            </select>
                        </div>

                        <!-- Filtro de Categoria -->
                        <div>
                            <label class="block text-xs font-medium text-gray-700 mb-1">Filtrar por Categoria</label>
                            <select id="category-filter" onchange="applyFilters()" class="w-full text-sm bg-gray-50 rounded-lg px-3 py-2 border border-gray-200 outline-none cursor-pointer hover:bg-gray-100 transition-colors font-medium text-slate-800">
                                <option value="">Todas as Categorias</option>
                            </select>
                        </div>

                        <!-- Filtro de Tipo (Receita/Despesa) -->
                        <div>
                            <label class="block text-xs font-medium text-gray-700 mb-1">Filtrar por Tipo</label>
                            <select id="type-filter" onchange="applyFilters()" class="w-full text-sm bg-gray-50 rounded-lg px-3 py-2 border border-gray-200 outline-none cursor-pointer hover:bg-gray-100 transition-colors font-medium text-slate-800">
                                <option value="">Todos os Tipos</option>
                                <option value="income">💰 Receitas</option>
                                <option value="expense">💸 Despesas</option>
                            </select>
                        </div>

                        <!-- Filtro de Forma de Pagamento -->
                        <div>
                            <label class="block text-xs font-medium text-gray-700 mb-1">Filtrar por Forma de Pagamento</label>
                            <select id="account-filter" onchange="applyFilters()" class="w-full text-sm bg-gray-50 rounded-lg px-3 py-2 border border-gray-200 outline-none cursor-pointer hover:bg-gray-100 transition-colors font-medium text-slate-800">
                                <option value="">Todas as Formas</option>
                                <option value="credit">💳 Cartão de Crédito</option>
                                <option value="debit">💳 Cartão de Débito</option>
                                <option value="cash">💵 Dinheiro</option>
                            </select>
                        </div>
                    </div>

                    <!-- Resumo do Filtro -->
                    <div id="filter-summary" class="mt-3 p-3 bg-blue-50 rounded-lg hidden">
                        <p class="text-xs font-medium text-blue-800 mb-2">Resultado do Filtro:</p>
                        <div class="grid grid-cols-3 gap-2">
                            <div>
                                <p class="text-xs text-blue-600">Receitas</p>
                                <p class="text-sm font-bold text-green-600" id="filter-income">R$ 0,00</p>
                            </div>
                            <div>
                                <p class="text-xs text-blue-600">Despesas</p>
                                <p class="text-sm font-bold text-red-600" id="filter-expense">R$ 0,00</p>
                            </div>
                            <div>
                                <p class="text-xs text-blue-600">Saldo</p>
                                <p class="text-sm font-bold text-blue-600" id="filter-balance">R$ 0,00</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="flex gap-2 mb-4 overflow-x-auto hide-scrollbar pb-1">
                    <button onclick="filterTransactions('all')" class="filter-btn px-4 py-2 bg-slate-800 text-white rounded-full text-xs sm:text-sm font-medium whitespace-nowrap" data-filter="all" data-i18n="all">Todas</button>
                    <button onclick="filterTransactions('income')" class="filter-btn px-4 py-2 bg-gray-100 text-gray-600 rounded-full text-xs sm:text-sm font-medium whitespace-nowrap hover:bg-gray-200 transition-colors" data-filter="income" data-i18n="income_only">Receitas</button>
                    <button onclick="filterTransactions('expense')" class="filter-btn px-4 py-2 bg-gray-100 text-gray-600 rounded-full text-xs sm:text-sm font-medium whitespace-nowrap hover:bg-gray-200 transition-colors" data-filter="expense" data-i18n="expenses_only">Despesas</button>
                </div>

                <div id="all-transactions-list" class="space-y-4 pb-20"></div>
            </div>

            <!-- NOVA TELA: DASHBOARD COM GRÁFICOS -->
            <div id="dashboard-chart" class="screen px-4 sm:px-6 py-4 hidden">
                <div class="flex items-center gap-4 mb-6">
                    <button onclick="showScreen('transactions')" class="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 hover:bg-gray-200 transition-colors">
                        <i class="fas fa-arrow-left"></i>
                    </button>
                    <h1 class="text-xl sm:text-2xl font-bold text-slate-800">Dashboard Analytics</h1>
                </div>

                <!-- Seletor de Mês para Dashboard -->
                <div class="bg-white rounded-2xl p-4 mb-4 shadow-sm">
                    <label class="block text-xs font-medium text-gray-700 mb-2">Período</label>
                    <select id="dashboard-month-filter" onchange="updateDashboardCharts()" class="w-full text-sm bg-gray-50 rounded-lg px-3 py-2 border border-gray-200 outline-none cursor-pointer font-medium text-slate-800">
                    </select>
                </div>

                <!-- Gráfico de Pizza - Despesas por Categoria -->
                <div class="bg-white rounded-3xl p-4 sm:p-6 mb-4 shadow-sm">
                    <h3 class="font-bold text-slate-800 text-sm sm:text-base mb-4">Despesas por Categoria</h3>
                    <div class="flex items-center justify-center">
                        <canvas id="category-pie-chart" width="300" height="300"></canvas>
                    </div>
                </div>

                <!-- Gráfico de Barras - Receitas vs Despesas -->
                <div class="bg-white rounded-3xl p-4 sm:p-6 mb-4 shadow-sm">
                    <h3 class="font-bold text-slate-800 text-sm sm:text-base mb-4">Receitas vs Despesas</h3>
                    <div>
                        <canvas id="income-expense-bar-chart" width="300" height="200"></canvas>
                    </div>
                </div>

                <!-- Top 5 Categorias com Mais Gastos -->
                <div class="bg-white rounded-3xl p-4 sm:p-6 shadow-sm">
                    <h3 class="font-bold text-slate-800 text-sm sm:text-base mb-4">Top 5 - Maiores Gastos</h3>
                    <div id="top-categories-list" class="space-y-2"></div>
                </div>
            </div>

            <!-- ADD TRANSACTION SCREEN -->
            <div id="add" class="screen px-4 sm:px-6 py-4 hidden slide-up">
                <div class="flex items-center gap-4 mb-6">
                    <button onclick="showScreen('dashboard')" class="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 hover:bg-gray-200 transition-colors">
                        <i class="fas fa-arrow-left"></i>
                    </button>
                    <h1 class="text-xl sm:text-2xl font-bold text-slate-800" data-i18n="new_transaction">Nova Transação</h1>
                </div>

                <div class="bg-gray-100 p-1 rounded-2xl flex mb-6">
                    <button onclick="selectType('expense')" id="btn-expense" class="flex-1 py-3 rounded-xl bg-white text-red-500 font-semibold shadow-sm transition-all text-sm sm:text-base">
                        <i class="fas fa-arrow-up mr-1 sm:mr-2"></i><span data-i18n="expense">Despesa</span>
                    </button>
                    <button onclick="selectType('income')" id="btn-income" class="flex-1 py-3 rounded-xl text-gray-500 font-medium transition-all text-sm sm:text-base">
                        <i class="fas fa-arrow-down mr-1 sm:mr-2"></i><span data-i18n="income_single">Receita</span>
                    </button>
                </div>

                <div class="text-center mb-6 sm:mb-8">
                    <p class="text-gray-500 text-sm mb-2" data-i18n="amount">Valor</p>
                    <div class="flex items-center justify-center gap-1">
                        <span class="text-2xl sm:text-3xl text-gray-400" id="currency-symbol">R$</span>
                        <input type="text"
                               id="amount-display"
                               placeholder="0,00"
                               readonly
                               class="text-4xl sm:text-5xl font-bold text-slate-800 bg-transparent border-none outline-none w-48 text-center cursor-pointer"
                               onclick="focusAmountInput()">
                        <input type="hidden" id="amount-input" value="0">
                    </div>

                    <!-- Teclado numérico -->
                    <div class="mt-4 grid grid-cols-3 gap-2 max-w-xs mx-auto">
                        <button onclick="addDigit('1')" class="p-4 bg-white rounded-xl text-xl font-semibold text-slate-800 hover:bg-gray-50 active:scale-95 transition-all shadow-sm">1</button>
                        <button onclick="addDigit('2')" class="p-4 bg-white rounded-xl text-xl font-semibold text-slate-800 hover:bg-gray-50 active:scale-95 transition-all shadow-sm">2</button>
                        <button onclick="addDigit('3')" class="p-4 bg-white rounded-xl text-xl font-semibold text-slate-800 hover:bg-gray-50 active:scale-95 transition-all shadow-sm">3</button>
                        <button onclick="addDigit('4')" class="p-4 bg-white rounded-xl text-xl font-semibold text-slate-800 hover:bg-gray-50 active:scale-95 transition-all shadow-sm">4</button>
                        <button onclick="addDigit('5')" class="p-4 bg-white rounded-xl text-xl font-semibold text-slate-800 hover:bg-gray-50 active:scale-95 transition-all shadow-sm">5</button>
                        <button onclick="addDigit('6')" class="p-4 bg-white rounded-xl text-xl font-semibold text-slate-800 hover:bg-gray-50 active:scale-95 transition-all shadow-sm">6</button>
                        <button onclick="addDigit('7')" class="p-4 bg-white rounded-xl text-xl font-semibold text-slate-800 hover:bg-gray-50 active:scale-95 transition-all shadow-sm">7</button>
                        <button onclick="addDigit('8')" class="p-4 bg-white rounded-xl text-xl font-semibold text-slate-800 hover:bg-gray-50 active:scale-95 transition-all shadow-sm">8</button>
                        <button onclick="addDigit('9')" class="p-4 bg-white rounded-xl text-xl font-semibold text-slate-800 hover:bg-gray-50 active:scale-95 transition-all shadow-sm">9</button>
                        <button onclick="clearAmount()" class="p-4 bg-red-100 rounded-xl text-lg font-semibold text-red-600 hover:bg-red-200 active:scale-95 transition-all shadow-sm">C</button>
                        <button onclick="addDigit('0')" class="p-4 bg-white rounded-xl text-xl font-semibold text-slate-800 hover:bg-gray-50 active:scale-95 transition-all shadow-sm">0</button>
                        <button onclick="removeDigit()" class="p-4 bg-gray-200 rounded-xl text-lg font-semibold text-gray-700 hover:bg-gray-300 active:scale-95 transition-all shadow-sm">
                            <i class="fas fa-backspace"></i>
                        </button>
                    </div>
                </div>

                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2" data-i18n="description">Descrição</label>
                        <input type="text" id="description-input" data-i18n-placeholder="ex_supermarket" placeholder="Ex: Supermercado" class="w-full px-4 py-3 sm:py-4 rounded-2xl bg-white border-2 border-gray-100 focus:border-blue-500 focus:outline-none transition-colors text-slate-800">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2" data-i18n="category">Categoria</label>
                        <div class="grid grid-cols-4 gap-2" id="category-grid"></div>
                    </div>

                    <div class="grid grid-cols-2 gap-3 sm:gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2" data-i18n="date">Data</label>
                            <input type="date" id="date-input" class="w-full px-3 sm:px-4 py-3 sm:py-4 rounded-2xl bg-white border-2 border-gray-100 focus:border-blue-500 focus:outline-none transition-colors text-slate-800 text-sm sm:text-base">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2" data-i18n="account">Conta</label>
                            <select id="account-input" class="w-full px-3 sm:px-4 py-3 sm:py-4 rounded-2xl bg-white border-2 border-gray-100 focus:border-blue-500 focus:outline-none transition-colors text-slate-800 text-sm sm:text-base">
                                <option value="credit" data-i18n="credit_card">Cartão Crédito</option>
                                <option value="debit" data-i18n="debit_card">Cartão Débito</option>
                                <option value="cash" data-i18n="cash">Dinheiro</option>
                            </select>
                        </div>
                    </div>

                    <button onclick="saveTransaction()" class="w-full py-3 sm:py-4 bg-slate-800 text-white rounded-2xl font-semibold text-base sm:text-lg mt-4 sm:mt-6 hover:bg-slate-700 active:scale-[0.98] transition-all shadow-lg" data-i18n="save_transaction">Salvar Transação</button>
                </div>
            </div>

        </div>

        <!-- Bottom Navigation -->
        <div class="absolute bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-4 sm:px-6 py-3 sm:py-4 flex justify-between items-center z-50">
            <button onclick="showScreen('dashboard')" class="nav-btn flex flex-col items-center gap-1 text-blue-600" data-screen="dashboard">
                <i class="fas fa-home text-lg sm:text-xl"></i>
                <span class="text-xs font-medium" data-i18n="home">Início</span>
            </button>
            <button onclick="showScreen('transactions')" class="nav-btn flex flex-col items-center gap-1 text-gray-400" data-screen="transactions">
                <i class="fas fa-list text-lg sm:text-xl"></i>
                <span class="text-xs font-medium" data-i18n="statement">Extrato</span>
            </button>
            <button onclick="showScreen('add')" class="w-12 h-12 sm:w-14 sm:h-14 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl sm:text-2xl shadow-lg shadow-blue-600/30 -mt-6 sm:-mt-8 hover:scale-110 transition-transform">
                <i class="fas fa-plus"></i>
            </button>
            <button onclick="showDonateModal()" class="nav-btn flex flex-col items-center gap-1 text-green-500 hover:text-green-600 transition-colors">
                <i class="fas fa-heart text-lg sm:text-xl"></i>
                <span class="text-xs font-medium" data-i18n="donate">Doar</span>
            </button>
            <button onclick="editName()" class="nav-btn flex flex-col items-center gap-1 text-gray-400">
                <i class="fas fa-user text-lg sm:text-xl"></i>
                <span class="text-xs font-medium" data-i18n="profile">Perfil</span>
            </button>
        </div>

        <div class="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-28 sm:w-32 h-1 bg-gray-300 rounded-full z-50"></div>
    </div>

    <!-- MODAL: IMPORTAR DADOS -->
    <div id="import-modal" class="fixed inset-0 modal-overlay hidden z-[100] flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold text-slate-800">Importar Dados</h2>
                <button onclick="closeImportModal()" class="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 hover:bg-gray-200">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <p class="text-sm text-gray-600 mb-4">Selecione um arquivo JSON exportado anteriormente para restaurar seus dados.</p>

            <input type="file" id="import-file-input" accept=".json" class="hidden" onchange="handleImportFile(event)">

            <button onclick="document.getElementById('import-file-input').click()" class="w-full py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-all flex items-center justify-center gap-2">
                <i class="fas fa-file-upload"></i>
                Selecionar Arquivo JSON
            </button>

            <p class="text-xs text-gray-400 mt-3 text-center">⚠️ Isto substituirá todos os seus dados atuais!</p>
        </div>
    </div>

    <!-- MODAL: LEMBRETE DE BACKUP -->
    <div id="backup-reminder-modal" class="fixed inset-0 modal-overlay hidden z-[100] flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl">
            <div class="text-center mb-6">
                <div class="w-20 h-20 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-3xl animate-pulse">
                    💾
                </div>
                <h2 class="text-2xl font-bold text-slate-800 mb-2">Hora do Backup!</h2>
                <p class="text-gray-600 text-sm mb-4">
                    Já estamos próximos do fim do mês!<br>
                    Não esqueça de fazer backup dos seus dados 🔒
                </p>
            </div>

            <div class="space-y-3">
                <button onclick="exportAllData(); closeBackupReminderModal();" class="w-full py-4 bg-gradient-to-r from-amber-500 to-orange-600 text-white rounded-2xl font-bold text-lg shadow-lg hover:from-amber-600 hover:to-orange-700 transition-all flex items-center justify-center gap-2">
                    <i class="fas fa-download"></i>
                    <span>Fazer Backup Agora</span>
                </button>
                <button onclick="remindBackupLater()" class="w-full py-3 bg-gray-100 text-gray-600 rounded-2xl font-medium hover:bg-gray-200 transition-all">
                    Lembrar Amanhã
                </button>
            </div>

            <p class="text-center text-gray-400 text-xs mt-4">
                Recomendamos fazer backup regularmente!
            </p>
        </div>
    </div>

    <!-- MODAL: DOAÇÃO PIX -->
    <div id="donate-modal" class="fixed inset-0 modal-overlay hidden z-[100] flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl transform scale-95 opacity-0 transition-all duration-300" id="donate-content">
            <div class="text-center mb-6">
                <div class="w-16 h-16 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl">
                    <i class="fas fa-heart"></i>
                </div>
                <h2 class="text-2xl font-bold text-slate-800 mb-2">Apoie o Desenvolvedor</h2>
                <p class="text-gray-500 text-sm mb-6">Se este app te ajudou, doe qualquer valor!</p>
            </div>

            <div class="space-y-3 mb-6">
                <button onclick="copyPixKey()" class="w-full py-3 bg-orange-100 text-orange-800 rounded-xl font-medium hover:bg-orange-200 transition-all">
                    ☕ Café & Bolo — R$ 5,99
                </button>
                <button onclick="copyPixKey()" class="w-full py-3 bg-yellow-100 text-yellow-800 rounded-xl font-medium hover:bg-yellow-200 transition-all">
                    🍽️ Almoço — R$ 9,99
                </button>
                <button onclick="copyPixKey()" class="w-full py-3 bg-purple-100 text-purple-800 rounded-xl font-medium hover:bg-purple-200 transition-all">
                    🍖 Jantar — R$ 19,99
                </button>
            </div>

            <div class="bg-green-50 rounded-2xl p-4 mb-4 border-2 border-green-200">
                <p class="text-center text-green-800 font-semibold mb-2">Chave PIX:</p>
                <div class="bg-white rounded-xl p-3 mb-3">
                    <p class="text-center text-xs font-mono text-slate-800 select-all break-all">f6c00e65-b267-45d0-a6da-9ac9ca57a131</p>
                </div>
                <button onclick="copyPixKey()" class="w-full py-2 bg-green-500 hover:bg-green-600 text-white rounded-xl font-medium transition-all flex items-center justify-center gap-2 mb-2">
                    <i class="fas fa-copy"></i>
                    <span>Copiar Chave PIX</span>
                </button>
                <div class="grid grid-cols-2 gap-2">
                    <button onclick="copyNubankLink()" class="py-2 bg-purple-100 hover:bg-purple-200 text-purple-800 rounded-xl font-medium transition-all flex items-center justify-center gap-1 text-sm">
                        <i class="fas fa-copy"></i>
                        <span>Copiar Link</span>
                    </button>
                    <a href="https://nubank.com.br/cobrar/11e4sv/69bcb0bc-4666-4e8d-a4b3-c504a18ad767" target="_blank" class="py-2 bg-purple-500 hover:bg-purple-600 text-white rounded-xl font-medium transition-all text-center flex items-center justify-center gap-1 text-sm">
                        <i class="fas fa-external-link-alt"></i>
                        <span>Abrir Nubank</span>
                    </a>
                </div>
            </div>

            <div class="space-y-3">
                <button onclick="closeDonateModal()" class="w-full py-3 text-gray-500 font-medium hover:text-gray-700 transition-colors">
                    Fechar
                </button>
            </div>
        </div>
    </div>

    <!-- MODAL: ADICIONAR CATEGORIA PERSONALIZADA -->
    <div id="add-category-modal" class="fixed inset-0 modal-overlay hidden z-[150] flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl p-5 max-w-sm w-full shadow-2xl transform scale-95 opacity-0 transition-all duration-300" id="add-category-content" style="max-height: 85vh; overflow-y: auto;">
            <div class="flex justify-between items-center mb-4 sticky top-0 bg-white pb-2">
                <h2 class="text-lg font-bold text-slate-800" data-i18n="add_custom_category">Adicionar Categoria</h2>
                <button onclick="closeAddCategoryModal()" class="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 hover:bg-gray-200">
                    <i class="fas fa-times text-sm"></i>
                </button>
            </div>

            <div class="mb-3">
                <label class="block text-xs font-medium text-gray-700 mb-1" data-i18n="category_name">Nome da Categoria</label>
                <input type="text" id="new-category-name" placeholder="Ex: Academia" oninput="updatePreview()" class="w-full px-3 py-2 rounded-xl bg-white border-2 border-gray-100 focus:border-blue-500 focus:outline-none text-slate-800 text-sm">
            </div>

            <div class="mb-3">
                <label class="block text-xs font-medium text-gray-700 mb-2" data-i18n="choose_icon">Escolha um Ícone</label>
                <div class="grid grid-cols-7 gap-1" id="icon-selector"></div>
            </div>

            <div class="mb-3">
                <label class="block text-xs font-medium text-gray-700 mb-2" data-i18n="choose_color">Escolha uma Cor</label>
                <div class="flex gap-2 overflow-x-auto hide-scrollbar pb-1" id="color-selector"></div>
            </div>

            <div class="flex items-center gap-3 p-3 bg-gray-50 rounded-xl mb-4">
                <span class="text-xs text-gray-500" data-i18n="preview">Pré-visualização:</span>
                <div id="category-preview" class="w-10 h-10 rounded-xl bg-gray-200 flex items-center justify-center text-gray-400 text-sm">
                    <i class="fas fa-question"></i>
                </div>
                <span id="preview-name" class="text-sm font-medium text-slate-800 truncate flex-1">...</span>
            </div>

            <button onclick="saveNewCategory()" class="w-full py-3 bg-blue-600 text-white rounded-xl font-bold text-base shadow-lg hover:bg-blue-700 transition-all" data-i18n="add_category_btn">Adicionar Categoria</button>
        </div>
    </div>

    <script src="app.js"></script>

    <!-- Registrar Service Worker para PWA -->
    <script>
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('sw.js')
                .then(reg => console.log('✅ Service Worker registrado'))
                .catch(err => console.log('❌ Erro ao registrar SW:', err));
        }
    </script>
</body>
</html>
