# Pet Shop ERP - Sistema Completo PHP + SQLite

## 📋 Descrição

Sistema completo de gestão para Pet Shops desenvolvido em PHP com banco de dados SQLite. Possui todas as funcionalidades do sistema original, agora com persistência de dados no servidor.

## ✨ Funcionalidades

### 🔐 Autenticação e Gerenciamento
- Sistema de login com autenticação segura
- Gerenciador de múltiplas lojas (Admin)
- Salvamento automático do nome da loja

### 🐾 Cadastro de Pets
- Cadastro completo de animais
- Informações do dono (telefone, email)
- Prontuário médico
- Histórico completo

### 📅 Agenda de Serviços
- Agendamento com data e hora
- Múltiplos serviços por agendamento
- Controle de produtos utilizados
- Alertas de agendamentos do dia
- Filtro por data

### 📦 Controle de Estoque
- Cadastro de produtos
- Controle de quantidade
- Alerta de estoque baixo
- Custo e preço de venda
- Atualização automática ao usar produtos

### 👥 Gerenciamento de Funcionários
- Cadastro completo
- Controle de comissões
- Salários
- Datas de admissão

### 💰 Financeiro
- Lançamento de despesas
- Lançamento de receitas extras
- Relatórios por mês
- Gráficos de desempenho
- Cálculo automático de lucro

### 🛠️ Serviços Personalizados
- Adicionar serviços customizados
- Definir valores padrão
- Gerenciar lista de serviços

### 💾 Backup e Restauração
- Exportar todos os dados em JSON
- Importar backup completo
- Limpar todos os dados

## 🚀 Instalação

### Requisitos
- PHP 7.4 ou superior
- Extensão PDO SQLite habilitada
- Servidor web (Apache, Nginx, ou Laragon)

### Instalação com Laragon

1. **Baixe e instale o Laragon**
   - Download: https://laragon.org/download/

2. **Extraia os arquivos do sistema**
   - Extraia a pasta `petshop-erp-completo` para:
   - `C:\laragon\www\petshop-erp-completo`

3. **Inicie o Laragon**
   - Abra o Laragon
   - Clique em "Start All"

4. **Acesse o sistema**
   - Abra seu navegador
   - Acesse: `http://localhost/petshop-erp-completo`

### Instalação Manual (Servidor Apache/Nginx)

1. **Copie os arquivos**
   ```bash
   cp -r petshop-erp-completo /var/www/html/
   ```

2. **Configure permissões**
   ```bash
   chmod -R 755 /var/www/html/petshop-erp-completo
   chmod -R 777 /var/www/html/petshop-erp-completo/database
   ```

3. **Acesse o sistema**
   - Navegador: `http://localhost/petshop-erp-completo`

## 🔑 Login Padrão

**Usuário:** admin
**Senha:** admin123

## 📁 Estrutura de Arquivos

```
petshop-erp-completo/
├── index.php           # Interface principal do sistema
├── config.php          # Configuração e inicialização do banco
├── api.php             # API backend (todas as operações)
├── app.js              # JavaScript principal da aplicação
├── database/           # Pasta do banco de dados SQLite
│   └── petshop.db     # Banco de dados (criado automaticamente)
└── README.md           # Este arquivo
```

## 🎯 Como Usar

### 1. Primeiro Acesso
- Faça login com as credenciais padrão
- Digite o nome da sua loja
- Clique em "Fixar" para salvar o nome

### 2. Cadastrar Pets
- Vá em "Pets" no menu principal
- Clique em "Cadastrar Novo Pet"
- Preencha os dados e salve

### 3. Criar Agendamento
- Vá em "Agenda"
- Clique em "Novo Agendamento"
- Selecione o pet, data e horário
- Adicione os serviços
- Opcionalmente adicione produtos utilizados
- Confirme o agendamento

### 4. Controlar Estoque
- Vá em "Estoque"
- Cadastre produtos
- O sistema alerta quando o estoque está baixo
- Atualização automática ao usar em agendamentos

### 5. Lançamentos Financeiros
- Vá em "Financeiro"
- Escolha tipo (Despesa ou Receita)
- Preencha descrição, valor e data
- Lance o registro

### 6. Ver Dashboard
- O painel principal mostra:
  - Receitas do mês
  - Despesas do mês
  - Lucro líquido
  - Gráfico dos últimos 6 meses
  - Alertas de agendamentos do dia

## 🔧 Funcionalidades Avançadas

### Modo Admin (F12)
- Pressione F12 na tela de login
- Acesse o gerenciador de lojas
- Crie múltiplas lojas com credenciais diferentes

### Serviços Personalizados
- Durante um agendamento, clique no botão "+"
- Adicione serviços customizados com valores
- Exclua serviços que não usa mais

### Backup e Restauração
- Vá em "Backup"
- Baixe backup em JSON
- Importe backup para restaurar dados
- Use em caso de troca de servidor

## 🐛 Solução de Problemas

### Banco de dados não é criado
```bash
# Verifique permissões da pasta database
chmod 777 database/
```

### Erro de conexão
- Verifique se a extensão PDO SQLite está habilitada no PHP
- Edite php.ini e descomente: `extension=pdo_sqlite`

### Sessão expira rapidamente
- Aumente session.gc_maxlifetime no php.ini
- Padrão: 1440 (24 minutos)

## 📊 Características Técnicas

- **Backend:** PHP 7.4+ com PDO
- **Banco de Dados:** SQLite 3
- **Frontend:** HTML5, Bootstrap 5.3, JavaScript ES6
- **Gráficos:** Chart.js 4.4
- **Ícones:** Bootstrap Icons 1.11
- **Autenticação:** Sessões PHP + BCrypt
- **API:** REST com JSON

## 🔒 Segurança

- Senhas criptografadas com BCrypt
- Proteção contra SQL Injection (PDO Prepared Statements)
- Validação de sessão em todas as operações
- Separação de dados por loja
- Backup local dos dados

## 📝 Notas Importantes

1. **Primeiro uso:** O sistema cria automaticamente o usuário admin
2. **Multi-loja:** Cada loja tem seus dados isolados
3. **Banco único:** Todas as lojas compartilham o mesmo banco SQLite
4. **Backup regular:** Faça backup periódico dos dados
5. **Desenvolvimento:** Este sistema foi desenvolvido para uso em ambiente local (Laragon)

## 🆘 Suporte

Em caso de problemas:
1. Verifique os requisitos do sistema
2. Confira as permissões das pastas
3. Veja os logs de erro do PHP
4. Certifique-se que o SQLite está habilitado

## 📄 Licença

Sistema desenvolvido para gestão de Pet Shops.

---

**Desenvolvido com ❤️ para facilitar a gestão do seu Pet Shop!**
