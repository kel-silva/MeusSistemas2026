# 🐾 Pet Shop ERP - Sistema Single-Tenant

## 📋 Sobre esta Versão

Este sistema foi **otimizado para arquitetura de subdomínios**, onde cada cliente tem sua própria instalação independente.

### ✅ Vantagens desta Arquitetura:

1. **Segurança Máxima**: Cada cliente tem banco de dados separado
2. **Performance Superior**: Bancos pequenos e rápidos
3. **Personalização**: Cada cliente pode ter customizações
4. **Backup Independente**: Restaure apenas o cliente afetado
5. **Escalabilidade**: Distribua em servidores diferentes

## 🏗️ Arquitetura Recomendada

### Modelo de Subdomínios:

```
petshop1.seudominio.com → Instalação 1 (Banco próprio)
petshop2.seudominio.com → Instalação 2 (Banco próprio)
petshop3.seudominio.com → Instalação 3 (Banco próprio)
```

Cada subdomínio aponta para uma pasta com instalação completa do sistema.

## 📁 Estrutura de Pastas no Servidor

```
/var/www/
├── petshop1/           ← Instalação Cliente 1
│   ├── api.php
│   ├── index.php
│   └── database/
│       └── petshop.db  ← Banco de dados do Cliente 1
│
├── petshop2/           ← Instalação Cliente 2
│   ├── api.php
│   ├── index.php
│   └── database/
│       └── petshop.db  ← Banco de dados do Cliente 2
│
└── petshop3/           ← Instalação Cliente 3
    ├── api.php
    ├── index.php
    └── database/
        └── petshop.db  ← Banco de dados do Cliente 3
```

## ⚙️ Configuração de Subdomínios (cPanel/Apache)

### 1. Criar Subdomínio no cPanel:

1. Acesse **Domínios** ou **Subdomínios**
2. Adicione: `petshop1.seudominio.com`
3. Direcione para: `/public_html/petshop1`
4. Repita para cada cliente

### 2. Configuração Apache (VirtualHost):

```apache
<VirtualHost *:80>
    ServerName petshop1.seudominio.com
    DocumentRoot /var/www/petshop1

    <Directory /var/www/petshop1>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

### 3. Configuração Nginx:

```nginx
server {
    listen 80;
    server_name petshop1.seudominio.com;
    root /var/www/petshop1;
    index index.php index.html;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
    }
}
```

## 🚀 Instalação para Novo Cliente

### Passo 1: Copiar Arquivos

```bash
# Fazer upload via FTP/SSH para /var/www/petshopNOVO/
# ou copiar de uma instalação existente:
cp -r /var/www/petshop1 /var/www/petshopNOVO
```

### Passo 2: Limpar Dados

```bash
cd /var/www/petshopNOVO/database
rm petshop.db
```

### Passo 3: Criar Banco Novo

Execute o script de instalação (via navegador ou terminal):
```bash
php setup_password.php
```

Ou manualmente:
```sql
sqlite3 petshop.db < schema.sql
```

### Passo 4: Configurar Senha

Edite `setup_password.php` e defina uma senha única:
```php
$password = 'SenhaDoCliente123!';
```

Execute:
```bash
php setup_password.php
```

### Passo 5: Testar

Acesse: `https://petshopNOVO.seudominio.com`

Credenciais padrão:
- Usuário: `admin`
- Senha: `admin123` (ou a que você definiu)

## 🔐 Segurança

### ⚠️ IMPORTANTE - Primeiros Passos:

1. **Altere a senha padrão** imediatamente após login
2. **Delete o arquivo** `setup_password.php` após configuração
3. **Configure HTTPS** (SSL/TLS obrigatório)
4. **Permissões da pasta database**: `chmod 755 database/`
5. **Permissões do banco**: `chmod 644 database/petshop.db`

### Proteção do Banco de Dados:

Adicione ao `.htaccess`:
```apache
<FilesMatch "\.db$">
    Order allow,deny
    Deny from all
</FilesMatch>
```

## 🔄 Backup e Restore

### Backup Simples:

```bash
# Backup completo de um cliente
tar -czf petshop1-backup-$(date +%Y%m%d).tar.gz /var/www/petshop1/

# Apenas o banco de dados
cp /var/www/petshop1/database/petshop.db ~/backups/petshop1-$(date +%Y%m%d).db
```

### Restore:

```bash
# Restaurar banco
cp ~/backups/petshop1-20240327.db /var/www/petshop1/database/petshop.db
chmod 644 /var/www/petshop1/database/petshop.db
```

## 🛠️ Manutenção

### Atualizar Sistema de Todos os Clientes:

```bash
#!/bin/bash
for dir in /var/www/petshop*/; do
    echo "Atualizando $dir"
    cp api.php "$dir"
    cp app.js "$dir"
    cp index.php "$dir"
    # NÃO copie o database/ para não sobrescrever dados!
done
```

## 📊 Monitoramento

Monitore cada instalação separadamente:
- Tamanho do banco de dados
- Logs de erro
- Performance

## 💡 Dicas

1. **Nomenclatura**: Use nomes descritivos (petshop-centro, petshop-sul)
2. **Documentação**: Mantenha lista de quais clientes usam quais subdomínios
3. **Versionamento**: Teste atualizações em uma instalação teste primeiro
4. **Backup Automatizado**: Configure cron jobs para backup diário

## 📞 Suporte

Para cada cliente, você pode:
- Restaurar dados sem afetar outros
- Personalizar funcionalidades
- Testar em ambiente isolado
- Migrar para servidor dedicado se crescer

---

## 🎯 Resumo: Por que Single-Tenant é Melhor

| Aspecto | Multi-Tenant (Isolamento por ID) | Single-Tenant (Subdomínios) |
|---------|----------------------------------|------------------------------|
| Segurança | ⚠️ Risco de vazamento | ✅ Totalmente isolado |
| Performance | ⚠️ Banco único cresce | ✅ Bancos pequenos |
| Backup | ⚠️ Tudo ou nada | ✅ Individual |
| Personalização | ❌ Difícil | ✅ Fácil |
| Escalabilidade | ⚠️ Servidor único | ✅ Distribua servidores |
| Manutenção | ⚠️ Update afeta todos | ✅ Update controlado |

---

**Desenvolvido com foco em escalabilidade e segurança** 🚀
