<?php
// ===================================================
// CONFIGURAÇÃO DO SISTEMA PET SHOP ERP
// ===================================================

// Iniciar sessão
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Configurações do banco de dados
define('DB_PATH', __DIR__ . '/database/petshop.db');

// Função para criar conexão com o banco
function getDBConnection() {
    try {
        $pdo = new PDO('sqlite:' . DB_PATH);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    } catch (PDOException $e) {
        die('Erro ao conectar ao banco: ' . $e->getMessage());
    }
}

// Função para retornar JSON
function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Criar tabelas se não existirem
function initDatabase() {
    $pdo = getDBConnection();

    // Tabela de lojas
    $pdo->exec("CREATE TABLE IF NOT EXISTS stores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        display_name TEXT,
        active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // Tabela de pets
    $pdo->exec("CREATE TABLE IF NOT EXISTS pets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        store_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        owner TEXT NOT NULL,
        species TEXT,
        breed TEXT,
        gender TEXT,
        phone TEXT,
        email TEXT,
        birth DATE,
        medical TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE
    )");

    // Tabela de funcionários
    $pdo->exec("CREATE TABLE IF NOT EXISTS staff (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        store_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        cpf TEXT,
        role TEXT,
        commission REAL DEFAULT 0,
        salary REAL DEFAULT 0,
        phone TEXT,
        email TEXT,
        admission_date DATE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE
    )");

    // Tabela de estoque
    $pdo->exec("CREATE TABLE IF NOT EXISTS stock (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        store_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        category TEXT,
        quantity INTEGER DEFAULT 0,
        cost REAL DEFAULT 0,
        price REAL DEFAULT 0,
        min_stock INTEGER DEFAULT 5,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE
    )");

    // Tabela de serviços customizados
    $pdo->exec("CREATE TABLE IF NOT EXISTS custom_services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        store_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        default_value REAL NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE
    )");

    // Tabela de agendamentos
    $pdo->exec("CREATE TABLE IF NOT EXISTS appointments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        store_id INTEGER NOT NULL,
        pet_id INTEGER NOT NULL,
        staff_id INTEGER,
        appointment_date DATE NOT NULL,
        appointment_time TIME NOT NULL,
        services TEXT NOT NULL,
        products TEXT,
        total_value REAL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
        FOREIGN KEY (pet_id) REFERENCES pets(id) ON DELETE CASCADE,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE SET NULL
    )");

    // Tabela financeira
    $pdo->exec("CREATE TABLE IF NOT EXISTS finances (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        store_id INTEGER NOT NULL,
        type TEXT NOT NULL,
        description TEXT NOT NULL,
        value REAL NOT NULL,
        transaction_date DATE NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE
    )");

    // Adicionar coluna 'active' se não existir (para bancos antigos)
    try {
        $pdo->exec("ALTER TABLE stores ADD COLUMN active INTEGER DEFAULT 1");
    } catch (PDOException $e) {
        // Coluna já existe, ignore
    }

    // Criar usuário admin padrão se não existir
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM stores WHERE name = 'admin'");
    $result = $stmt->fetch();

    if ($result['count'] == 0) {
        $hashedPassword = password_hash('admin123', PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("INSERT INTO stores (name, password, display_name, active) VALUES (?, ?, ?, ?)");
        $stmt->execute(['admin', $hashedPassword, 'Administrador', 1]);
    }
}

// Inicializar banco de dados
initDatabase();
?>
