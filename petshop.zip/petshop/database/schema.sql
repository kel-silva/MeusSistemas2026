-- ===================================================
-- SCHEMA DO BANCO DE DADOS - PET SHOP ERP
-- VERSÃO SINGLE-TENANT (SEM ISOLAMENTO DE DADOS)
-- ===================================================

-- Tabela de Autenticação (Login Único)
CREATE TABLE IF NOT EXISTS stores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    display_name TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Inserir usuário padrão (admin)
INSERT OR IGNORE INTO stores (name, password, display_name)
VALUES ('admin', '$2y$10$YourHashedPasswordHere', 'Pet Shop');

-- Tabela de Pets
CREATE TABLE IF NOT EXISTS pets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    owner TEXT NOT NULL,
    species TEXT,
    breed TEXT,
    gender TEXT,
    phone TEXT,
    email TEXT,
    birth DATE,
    medical TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Funcionários
CREATE TABLE IF NOT EXISTS staff (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    cpf TEXT,
    role TEXT,
    commission REAL DEFAULT 0,
    salary REAL DEFAULT 0,
    phone TEXT,
    email TEXT,
    admission_date DATE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Estoque/Produtos
CREATE TABLE IF NOT EXISTS stock (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT,
    quantity INTEGER DEFAULT 0,
    cost REAL DEFAULT 0,
    price REAL DEFAULT 0,
    min_stock INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Serviços Personalizados
CREATE TABLE IF NOT EXISTS custom_services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    default_value REAL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Agendamentos
CREATE TABLE IF NOT EXISTS appointments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pet_id INTEGER,
    staff_id INTEGER,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    services TEXT,
    products TEXT,
    total_value REAL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (pet_id) REFERENCES pets(id) ON DELETE CASCADE,
    FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE SET NULL
);

-- Tabela de Finanças
CREATE TABLE IF NOT EXISTS finances (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL CHECK(type IN ('income', 'expense')),
    description TEXT NOT NULL,
    value REAL NOT NULL,
    transaction_date DATE NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_pets_name ON pets(name);
CREATE INDEX IF NOT EXISTS idx_pets_owner ON pets(owner);
CREATE INDEX IF NOT EXISTS idx_staff_name ON staff(name);
CREATE INDEX IF NOT EXISTS idx_stock_name ON stock(name);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date);
CREATE INDEX IF NOT EXISTS idx_finances_date ON finances(transaction_date);
CREATE INDEX IF NOT EXISTS idx_finances_type ON finances(type);
