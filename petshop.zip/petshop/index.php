<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Shop ERP - Sistema Completo PHP</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #34495e;
            --accent: #27ae60;
            --warning: #f39c12;
            --danger: #c0392b;
            --light: #f8f9fa;
        }

        body {
            background-color: var(--light);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }

        .screen {
            display: none;
            min-height: 100vh;
            padding: 20px;
        }

        .screen.active {
            display: block;
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .login-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--primary), var(--accent));
        }

        .login-card {
            background: white;
            border-radius: 20px;
            padding: 40px;
            max-width: 450px;
            width: 100%;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }

        .pet-icon {
            font-size: 4rem;
            text-align: center;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 800;
            color: var(--primary);
        }

        .menu-card {
            background: white;
            border-radius: 12px;
            padding: 30px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border: 2px solid transparent;
        }

        .menu-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
            border-color: var(--accent);
        }

        .menu-icon {
            font-size: 3rem;
            margin-bottom: 15px;
        }

        .list-item {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border-left: 5px solid var(--accent);
        }

        .list-item.low-stock {
            border-left-color: var(--danger);
        }

        .list-item.today-appointment {
            border-left-color: var(--warning);
            background: #fff9e6;
        }

        .chart-container {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .btn-admin {
            display: none;
            animation: pulse 2s infinite;
        }

        .btn-admin.visible {
            display: block;
        }

        @keyframes pulse {
            0%, 100% { opacity: 0.8; }
            50% { opacity: 1; box-shadow: 0 0 20px var(--danger); }
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }

        .empty-icon {
            font-size: 4rem;
            margin-bottom: 20px;
        }

        .form-section {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .badge-store {
            background: var(--primary);
            color: white;
            padding: 8px 16px;
            border-radius: 25px;
            font-size: 0.85rem;
            text-transform: uppercase;
            font-weight: 700;
        }

        .alert-today {
            position: sticky;
            top: 20px;
            z-index: 100;
            animation: slideDown 0.5s ease;
        }

        @keyframes slideDown {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .service-item, .product-item {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 10px;
        }

        .service-grid, .product-grid {
            max-height: 300px;
            overflow-y: auto;
        }

        .custom-service-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 12px;
            margin-bottom: 8px;
            background: #f8f9fa;
            border-radius: 6px;
            border: 1px solid #dee2e6;
        }

        .custom-service-item:hover {
            background: #e9ecef;
        }

        @media (max-width: 768px) {
            .login-card {
                padding: 30px 20px;
                margin: 15px;
            }

            .stat-value {
                font-size: 1.5rem;
            }

            .menu-icon {
                font-size: 2rem;
            }

            .menu-card {
                padding: 20px 10px;
            }

            .form-section {
                padding: 15px;
            }

            h2 {
                font-size: 1.5rem;
            }

            h4 {
                font-size: 1.2rem;
            }
        }

        @media (max-width: 576px) {
            .stat-value {
                font-size: 1.3rem;
            }

            .list-item {
                padding: 15px;
            }
        }
    </style>
</head>
<body>

    <!-- MODAL ADICIONAR SERVIÇO -->
    <div class="modal fade" id="addServiceModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-plus-circle"></i> Gerenciar Serviços</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <h6 class="mb-3">Adicionar Novo Serviço</h6>
                    <div class="row mb-4">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nome do Serviço *</label>
                            <input type="text" class="form-control" id="new-service-name" placeholder="Ex: Banho Especial">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Valor Padrão (R$) *</label>
                            <input type="text" class="form-control" id="new-service-value" placeholder="0,00" onkeyup="app.formatCurrency(this)">
                        </div>
                        <div class="col-md-2 mb-3 d-flex align-items-end">
                            <button type="button" class="btn btn-success w-100" onclick="app.saveNewService()">
                                <i class="bi bi-check-circle"></i> Adicionar
                            </button>
                        </div>
                    </div>

                    <hr>

                    <h6 class="mb-3">Serviços Personalizados</h6>
                    <div id="custom-services-list"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- TOAST NOTIFICATION -->
    <div class="position-fixed bottom-0 end-0 p-3" style="z-index: 9999">
        <div id="toast" class="toast align-items-center text-white bg-success border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body" id="toast-message"></div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    </div>

    <!-- LOGIN SCREEN -->
    <div id="login-screen" class="screen active">
        <div class="login-wrapper">
            <div class="login-card">
                <div class="pet-icon"><i class="bi bi-shop text-success"></i></div>
                <h1 class="text-center mb-2">Pet Shop ERP</h1>
                <p class="text-center text-muted mb-4">Sistema Completo PHP + SQLite</p>

                <div class="mb-3">
                    <label class="form-label">Nome da Loja</label>
                    <div class="input-group">
                        <input type="text" class="form-control form-control-lg" id="login-store-name" placeholder="Ex: Pet Amigo">
                        <button class="btn btn-outline-success" type="button" id="btn-save-store-name" onclick="app.saveStoreName()">
                            <i class="bi bi-pin-angle-fill"></i> Fixar
                        </button>
                        <button class="btn btn-outline-secondary d-none" type="button" id="btn-edit-store-name" onclick="app.editStoreName()">
                            <i class="bi bi-pencil"></i> Editar
                        </button>
                    </div>
                    <small class="text-muted">Salve o nome da loja para não precisar digitar toda vez</small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Login</label>
                    <input type="text" class="form-control form-control-lg" id="login-user" placeholder="Usuário" value="admin">
                </div>

                <div class="mb-3">
                    <label class="form-label">Senha</label>
                    <div class="input-group">
                        <input type="password" class="form-control form-control-lg" id="login-pass" placeholder="Senha" value="">
                        <button class="btn btn-outline-secondary" type="button" onclick="app.togglePassword('login-pass', this)">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                </div>

                <button class="btn btn-success btn-lg w-100 mb-3" onclick="app.login()">
                    <i class="bi bi-box-arrow-in-right"></i> ENTRAR NO SISTEMA
                </button>

                <p id="login-msg" class="text-danger text-center small"></p>

                <button id="btn-super-admin" class="btn btn-danger btn-admin w-100 mt-3" onclick="app.nav('admin-screen')">
                    <i class="bi bi-shield-lock"></i> SUPER ADMIN
                </button>

                <p class="text-center text-muted small mt-3">Sistema pet Shop....</p>
            </div>
        </div>
    </div>

    <!-- ADMIN SCREEN -->
    <div id="admin-screen" class="screen">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                <h2><i class="bi bi-building"></i> Gerenciador de Lojas</h2>
                <button class="btn btn-outline-primary" onclick="app.nav('login-screen')">
                    <i class="bi bi-arrow-left"></i> Sair do Admin
                </button>
            </div>

            <div class="form-section">
                <h4 id="admin-form-title">Cadastrar Nova Loja</h4>
                <p class="text-muted small">Crie credenciais para novos clientes</p>
                <input type="hidden" id="admin-edit-id">

                <div class="row">
                    <div class="col-md-5 mb-3">
                        <input type="text" class="form-control" id="admin-new-store" placeholder="Nome da Loja (ex: pet_amigo)">
                    </div>
                    <div class="col-md-5 mb-3">
                        <div class="input-group">
                            <input type="text" class="form-control" id="admin-new-pass" placeholder="Senha (deixe vazio para manter)">
                            <button class="btn btn-outline-secondary" type="button" onclick="app.togglePassword('admin-new-pass', this)">
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>
                    </div>
                    <div class="col-md-2 mb-3">
                        <button class="btn btn-success w-100" id="btn-save-store" onclick="app.saveStore()">
                            <i class="bi bi-plus-circle"></i> CRIAR
                        </button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <button class="btn btn-secondary d-none" id="btn-cancel-edit-store" onclick="app.cancelEditStore()">
                            <i class="bi bi-x-circle"></i> Cancelar Edição
                        </button>
                    </div>
                </div>
            </div>

            <h4>Lojas Cadastradas</h4>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>Loja</th>
                            <th>Criada em</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="admin-stores-list"></tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- MAIN DASHBOARD -->
    <div id="main-screen" class="screen">
        <div class="container-fluid">
            <!-- ALERTA DE AGENDAMENTOS DO DIA -->
            <div id="today-alert" class="alert alert-warning alert-today d-none" role="alert">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-1"><i class="bi bi-exclamation-triangle-fill"></i> Agendamentos de Hoje</h5>
                        <div id="today-appointments-summary"></div>
                    </div>
                    <button class="btn btn-warning" onclick="app.nav('agenda-screen')">
                        <i class="bi bi-calendar-check"></i> Ver Agenda
                    </button>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                <div>
                    <h2><i class="bi bi-speedometer2"></i> Painel Geral</h2>
                    <span id="badge-store" class="badge-store">LOJA</span>
                </div>
                <button class="btn btn-outline-danger" onclick="app.logout()">
                    <i class="bi bi-box-arrow-right"></i> Sair
                </button>
            </div>

            <div class="row mb-4">
                <div class="col-md-6 col-lg-4">
                    <label class="form-label fw-bold">Filtrar por Mês:</label>
                    <select class="form-select" id="month-filter" onchange="app.updateDashboard()"></select>
                </div>
            </div>

            <h4 class="mb-3">Resumo Financeiro</h4>
            <div class="row mb-4">
                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="stat-card">
                        <div class="stat-value text-success" id="dash-revenue">R$ 0,00</div>
                        <div class="text-muted small text-uppercase">Receita Total</div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="stat-card">
                        <div class="stat-value text-danger" id="dash-expenses">R$ 0,00</div>
                        <div class="text-muted small text-uppercase">Despesas Total</div>
                    </div>
                </div>
                <div class="col-md-12 col-lg-4 mb-3">
                    <div class="stat-card border-success border-3">
                        <div class="stat-value text-success" id="dash-profit">R$ 0,00</div>
                        <div class="text-muted small text-uppercase">Lucro Líquido</div>
                    </div>
                </div>
            </div>

            <h4 class="mb-3">Desempenho Mensal (Últimos 6 Meses)</h4>
            <div class="chart-container mb-4">
                <canvas id="financeChart" style="max-height: 350px;"></canvas>
            </div>

            <h4 class="mb-3">Menu de Gestão</h4>
            <div class="row">
                <div class="col-6 col-md-4 col-lg-2 mb-3">
                    <div class="menu-card" onclick="app.nav('agenda-screen')">
                        <div class="menu-icon"><i class="bi bi-calendar-check text-primary"></i></div>
                        <div class="fw-bold">Agenda</div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-2 mb-3">
                    <div class="menu-card" onclick="app.nav('pets-screen')">
                        <div class="menu-icon"><i class="bi bi-heart-pulse text-danger"></i></div>
                        <div class="fw-bold">Pets</div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-2 mb-3">
                    <div class="menu-card" onclick="app.nav('stock-screen')">
                        <div class="menu-icon"><i class="bi bi-box-seam text-warning"></i></div>
                        <div class="fw-bold">Estoque</div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-2 mb-3">
                    <div class="menu-card" onclick="app.nav('staff-screen')">
                        <div class="menu-icon"><i class="bi bi-people text-info"></i></div>
                        <div class="fw-bold">Funcionários</div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-2 mb-3">
                    <div class="menu-card" onclick="app.nav('finance-screen')">
                        <div class="menu-icon"><i class="bi bi-cash-coin text-success"></i></div>
                        <div class="fw-bold">Financeiro</div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-2 mb-3">
                    <div class="menu-card" onclick="app.nav('settings-screen')">
                        <div class="menu-icon"><i class="bi bi-gear text-secondary"></i></div>
                        <div class="fw-bold">Backup</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- AGENDA SCREEN -->
    <div id="agenda-screen" class="screen">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                <h2><i class="bi bi-calendar-check"></i> Agenda de Serviços</h2>
                <button class="btn btn-outline-primary" onclick="app.nav('main-screen')">
                    <i class="bi bi-arrow-left"></i> Voltar
                </button>
            </div>

            <!-- FILTRO POR DATA -->
            <div class="form-section">
                <div class="row align-items-end">
                    <div class="col-md-4 mb-3 mb-md-0">
                        <label class="form-label fw-bold"><i class="bi bi-funnel"></i> Filtrar por Data</label>
                        <input type="date" class="form-control" id="agenda-filter-date" onchange="app.filterAgendaByDate()">
                    </div>
                    <div class="col-md-4 mb-3 mb-md-0">
                        <button class="btn btn-secondary w-100" onclick="app.clearAgendaFilter()">
                            <i class="bi bi-x-circle"></i> Limpar Filtro
                        </button>
                    </div>
                    <div class="col-md-4">
                        <button class="btn btn-info w-100" onclick="app.showTodayAppointments()">
                            <i class="bi bi-calendar-day"></i> Ver Hoje
                        </button>
                    </div>
                </div>
            </div>

            <!-- LISTAGEM PRIMEIRO -->
            <h4 class="mb-3">Próximos Agendamentos</h4>
            <div id="agenda-list" class="mb-4"></div>

            <button class="btn btn-success mb-3" onclick="app.prepareForm('agenda')">
                <i class="bi bi-plus-circle"></i> Novo Agendamento
            </button>

            <!-- FORMULÁRIO -->
            <div id="agenda-form-container" class="form-section d-none">
                <h5>Dados do Agendamento</h5>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Pet Cliente *</label>
                        <select class="form-select" id="ag-pet">
                            <option value="">Selecione o Pet...</option>
                        </select>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Profissional</label>
                        <select class="form-select" id="ag-staff">
                            <option value="">Selecione Profissional...</option>
                        </select>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Data *</label>
                        <input type="date" class="form-control" id="ag-date">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Horário *</label>
                        <input type="time" class="form-control" id="ag-time" value="09:00">
                    </div>
                </div>

                <hr>

                <!-- SERVIÇOS MÚLTIPLOS -->
                <div class="mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h6 class="mb-0"><i class="bi bi-scissors"></i> Serviços</h6>
                        <button class="btn btn-sm btn-primary" onclick="app.addService()">
                            <i class="bi bi-plus-circle"></i> Adicionar Serviço
                        </button>
                    </div>

                    <div id="services-grid" class="service-grid"></div>

                    <div class="mt-3 p-3 bg-light rounded">
                        <strong>Total Serviços: R$ <span id="total-services">0,00</span></strong>
                    </div>
                </div>

                <hr>

                <!-- PRODUTOS MÚLTIPLOS -->
                <div class="mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h6 class="mb-0"><i class="bi bi-box-seam"></i> Produtos Utilizados (Opcional)</h6>
                        <button class="btn btn-sm btn-warning" onclick="app.addProduct()">
                            <i class="bi bi-plus-circle"></i> Adicionar Produto
                        </button>
                    </div>

                    <div id="products-grid" class="product-grid"></div>
                </div>

                <div class="d-flex gap-2">
                    <button class="btn btn-success flex-fill" onclick="app.saveAppointment()">
                        <i class="bi bi-check-circle"></i> CONFIRMAR AGENDAMENTO
                    </button>
                    <button class="btn btn-secondary" onclick="app.cancelEdit('agenda')">
                        <i class="bi bi-x-circle"></i> Cancelar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- PETS SCREEN -->
    <div id="pets-screen" class="screen">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                <h2><i class="bi bi-heart-pulse"></i> Cadastro de Pets</h2>
                <button class="btn btn-outline-primary" onclick="app.nav('main-screen')">
                    <i class="bi bi-arrow-left"></i> Voltar
                </button>
            </div>

            <!-- LISTAGEM PRIMEIRO -->
            <h4 class="mb-3">Pets Cadastrados</h4>
            <div id="pets-list" class="mb-4"></div>

            <button class="btn btn-success mb-3" onclick="app.prepareForm('pet')">
                <i class="bi bi-plus-circle"></i> Cadastrar Novo Pet
            </button>

            <div id="pet-form-container" class="form-section d-none">
                <input type="hidden" id="pet-id">
                <h5>Cadastro de Pet</h5>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Nome do Pet *</label>
                        <input type="text" class="form-control" id="pet-name" placeholder="Ex: Rex">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Nome do Dono *</label>
                        <input type="text" class="form-control" id="pet-owner" placeholder="Ex: João Silva">
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Espécie</label>
                        <select class="form-select" id="pet-species">
                            <option value="Cão">Cão</option>
                            <option value="Gato">Gato</option>
                            <option value="Pássaro">Pássaro</option>
                            <option value="Coelho">Coelho</option>
                            <option value="Hamster">Hamster</option>
                            <option value="Outro">Outro</option>
                        </select>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Raça / Porte</label>
                        <input type="text" class="form-control" id="pet-breed" placeholder="Ex: Labrador">
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Sexo</label>
                        <select class="form-select" id="pet-gender">
                            <option value="">Não informado</option>
                            <option value="Macho">Macho</option>
                            <option value="Fêmea">Fêmea</option>
                        </select>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Telefone</label>
                        <input type="text" class="form-control phone-mask" id="pet-phone" placeholder="(00) 00000-0000" maxlength="15">
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">E-mail do Dono</label>
                        <input type="email" class="form-control" id="pet-email" placeholder="email@exemplo.com">
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Data de Nascimento</label>
                        <input type="date" class="form-control" id="pet-birth">
                    </div>

                    <div class="col-12 mb-3">
                        <label class="form-label">Prontuário Médico / Observações</label>
                        <textarea class="form-control" id="pet-medical" rows="3" placeholder="Alergias, vacinas, observações médicas..."></textarea>
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <button class="btn btn-success flex-fill" onclick="app.savePet()">
                        <i class="bi bi-check-circle"></i> SALVAR PET
                    </button>
                    <button class="btn btn-secondary" onclick="app.cancelEdit('pet')">
                        <i class="bi bi-x-circle"></i> Cancelar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- STOCK SCREEN -->
    <div id="stock-screen" class="screen">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                <h2><i class="bi bi-box-seam"></i> Controle de Estoque</h2>
                <button class="btn btn-outline-primary" onclick="app.nav('main-screen')">
                    <i class="bi bi-arrow-left"></i> Voltar
                </button>
            </div>

            <!-- LISTAGEM PRIMEIRO -->
            <h4 class="mb-3">Produtos em Estoque</h4>
            <div id="stock-list" class="mb-4"></div>

            <button class="btn btn-success mb-3" onclick="app.prepareForm('stock')">
                <i class="bi bi-plus-circle"></i> Novo Produto
            </button>

            <div id="stock-form-container" class="form-section d-none">
                <input type="hidden" id="stk-id">
                <h5>Cadastro de Produto</h5>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Nome do Produto *</label>
                        <input type="text" class="form-control" id="stk-name" placeholder="Ex: Shampoo Neutro">
                    </div>

                    <div class="col-md-3 mb-3">
                        <label class="form-label">Categoria</label>
                        <select class="form-select" id="stk-category">
                            <option value="Higiene">Higiene</option>
                            <option value="Alimentação">Alimentação</option>
                            <option value="Medicamento">Medicamento</option>
                            <option value="Acessório">Acessório</option>
                            <option value="Brinquedo">Brinquedo</option>
                            <option value="Outros">Outros</option>
                        </select>
                    </div>

                    <div class="col-md-3 mb-3">
                        <label class="form-label">Quantidade Inicial *</label>
                        <input type="number" class="form-control" id="stk-qty" placeholder="0">
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Custo Unitário (R$)</label>
                        <input type="text" class="form-control" id="stk-cost" placeholder="0,00" onkeyup="app.formatCurrency(this)">
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Preço de Venda (R$)</label>
                        <input type="text" class="form-control" id="stk-price" placeholder="0,00" onkeyup="app.formatCurrency(this)">
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Estoque Mínimo</label>
                        <input type="number" class="form-control" id="stk-min" placeholder="5" value="5">
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <button class="btn btn-success flex-fill" onclick="app.saveProduct()">
                        <i class="bi bi-check-circle"></i> SALVAR PRODUTO
                    </button>
                    <button class="btn btn-secondary" onclick="app.cancelEdit('stock')">
                        <i class="bi bi-x-circle"></i> Cancelar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- STAFF SCREEN -->
    <div id="staff-screen" class="screen">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                <h2><i class="bi bi-people"></i> Equipe e Profissionais</h2>
                <button class="btn btn-outline-primary" onclick="app.nav('main-screen')">
                    <i class="bi bi-arrow-left"></i> Voltar
                </button>
            </div>

            <!-- LISTAGEM PRIMEIRO -->
            <h4 class="mb-3">Funcionários Cadastrados</h4>
            <div id="staff-list" class="mb-4"></div>

            <button class="btn btn-success mb-3" onclick="app.prepareForm('staff')">
                <i class="bi bi-plus-circle"></i> Cadastrar Funcionário
            </button>

            <div id="staff-form-container" class="form-section d-none">
                <input type="hidden" id="stf-id">
                <h5>Cadastro de Funcionário</h5>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Nome Completo *</label>
                        <input type="text" class="form-control" id="stf-name" placeholder="Ex: Maria Santos">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label d-flex justify-content-between align-items-center">
                            <span id="doc-label">CPF</span>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="toggle-doc-type" onclick="app.toggleDocumentType()">
                                <i class="bi bi-arrow-left-right"></i> Trocar para CNPJ
                            </button>
                        </label>
                        <input type="text" class="form-control" id="stf-cpf" placeholder="000.000.000-00" maxlength="18">
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Cargo</label>
                        <select class="form-select" id="stf-role">
                            <option value="Banhista">Banhista</option>
                            <option value="Tosador">Tosador</option>
                            <option value="Veterinário">Veterinário</option>
                            <option value="Auxiliar Veterinário">Auxiliar Veterinário</option>
                            <option value="Atendente">Atendente</option>
                            <option value="Caixa">Caixa</option>
                            <option value="Gerente">Gerente</option>
                            <option value="Adestrador">Adestrador</option>
                            <option value="Estoquista">Estoquista</option>
                            <option value="Vendedor">Vendedor</option>
                            <option value="Serviços Gerais">Serviços Gerais</option>
                        </select>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Comissão (%)</label>
                        <input type="number" class="form-control" id="stf-comm" placeholder="10" min="0" max="100">
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Salário (R$)</label>
                        <input type="text" class="form-control" id="stf-salary" placeholder="0,00" onkeyup="app.formatCurrency(this)">
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Telefone</label>
                        <input type="text" class="form-control phone-mask" id="stf-phone" placeholder="(00) 00000-0000" maxlength="15">
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">E-mail</label>
                        <input type="email" class="form-control" id="stf-email" placeholder="email@exemplo.com">
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Data de Admissão</label>
                        <input type="date" class="form-control" id="stf-admission">
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <button class="btn btn-success flex-fill" onclick="app.saveStaff()">
                        <i class="bi bi-check-circle"></i> SALVAR FUNCIONÁRIO
                    </button>
                    <button class="btn btn-secondary" onclick="app.cancelEdit('staff')">
                        <i class="bi bi-x-circle"></i> Cancelar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- FINANCE SCREEN -->
    <div id="finance-screen" class="screen">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                <h2><i class="bi bi-cash-coin"></i> Lançamento Financeiro</h2>
                <button class="btn btn-outline-primary" onclick="app.nav('main-screen')">
                    <i class="bi bi-arrow-left"></i> Voltar
                </button>
            </div>

            <!-- LISTAGEM PRIMEIRO -->
            <h4 class="mb-3">Histórico Financeiro</h4>
            <div id="expense-list" class="mb-4"></div>

            <div class="form-section">
                <input type="hidden" id="fin-id">
                <h5>Novo Lançamento</h5>

                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Tipo de Lançamento *</label>
                        <select class="form-select" id="fin-type" onchange="app.updateFinanceButton()">
                            <option value="expense">Despesa (Saída)</option>
                            <option value="income">Receita Extra (Entrada)</option>
                        </select>
                    </div>

                    <div class="col-md-5 mb-3">
                        <label class="form-label">Descrição *</label>
                        <input type="text" class="form-control" id="fin-desc" placeholder="Ex: Venda de Coleira / Conta de Luz">
                    </div>

                    <div class="col-md-2 mb-3">
                        <label class="form-label">Valor (R$) *</label>
                        <input type="text" class="form-control" id="fin-value" placeholder="0,00" onkeyup="app.formatCurrency(this)">
                    </div>

                    <div class="col-md-2 mb-3">
                        <label class="form-label">Data *</label>
                        <input type="date" class="form-control" id="fin-date">
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <button class="btn btn-danger flex-fill" id="btn-save-fin" onclick="app.saveExpense()">
                        <i class="bi bi-arrow-down-circle"></i> LANÇAR DESPESA
                    </button>
                    <button class="btn btn-secondary d-none" id="btn-cancel-fin" onclick="app.cancelEdit('finance')">
                        <i class="bi bi-x-circle"></i> Cancelar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- SETTINGS SCREEN -->
    <div id="settings-screen" class="screen">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                <h2><i class="bi bi-gear"></i> Backup e Dados</h2>
                <button class="btn btn-outline-primary" onclick="app.nav('main-screen')">
                    <i class="bi bi-arrow-left"></i> Voltar
                </button>
            </div>

            <div class="form-section bg-success bg-opacity-10 border border-success">
                <h5><i class="bi bi-shield-check"></i> Segurança dos Dados</h5>
                <p class="text-muted">Os dados são salvos no banco de dados SQLite. Faça backup regularmente.</p>

                <button class="btn btn-info w-100 mb-3" onclick="app.exportData()">
                    <i class="bi bi-download"></i> BAIXAR BACKUP
                </button>

                <hr>

                <label class="form-label fw-bold"><i class="bi bi-upload"></i> Restaurar Backup</label>
                <input type="file" class="form-control" id="import-file" accept=".json" onchange="app.importData(this)">
            </div>

            <div class="form-section bg-danger bg-opacity-10 border border-danger mt-4">
                <h5 class="text-danger"><i class="bi bi-exclamation-triangle"></i> Zona de Perigo</h5>
                <p class="text-muted">Esta ação não pode ser desfeita.</p>
                <button class="btn btn-danger w-100" onclick="app.clearAllData()">
                    <i class="bi bi-trash"></i> APAGAR TODOS OS DADOS
                </button>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- App JavaScript -->
    <script src="app.js"></script>
</body>
</html>
