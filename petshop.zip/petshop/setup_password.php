<?php
// Script para configurar senha do admin no primeiro uso
$password = 'admin123'; // Senha padrão - MUDE DEPOIS!
$hash = password_hash($password, PASSWORD_BCRYPT);

$pdo = new PDO('sqlite:database/petshop.db');

// Verificar se já existe admin
$stmt = $pdo->query("SELECT COUNT(*) FROM stores WHERE name = 'admin'");
$count = $stmt->fetchColumn();

if ($count == 0) {
    // Criar admin
    $stmt = $pdo->prepare("INSERT INTO stores (name, password, display_name) VALUES (?, ?, ?)");
    $stmt->execute(['admin', $hash, 'Pet Shop']);
    echo "✓ Usuário 'admin' criado com senha: admin123\n";
    echo "⚠️  IMPORTANTE: Altere essa senha após o primeiro login!\n";
} else {
    // Atualizar senha
    $stmt = $pdo->prepare("UPDATE stores SET password = ? WHERE name = 'admin'");
    $stmt->execute([$hash]);
    echo "✓ Senha do admin redefinida para: admin123\n";
}
?>
